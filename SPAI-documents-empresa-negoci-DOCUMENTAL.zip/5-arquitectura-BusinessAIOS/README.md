# SolutionPartner Business AI OS v1.0
## Production Milestone 1 — First Real Tenant Acceptance

This package preserves the Phase 21 architecture and adds a **read-only production acceptance gate** for the first real tenant. It does not create a new architectural phase or bypass any existing governance.

The gate validates evidence for governed onboarding, commercial entitlement, licensing/mTLS, Business Pulse, n8n, ERP runtime access, runtime sync, health, approved deployment, AI Service Management/SLO coverage, backup, recovery point, restore rehearsal, rollback rehearsal and critical-incident clearance.

### Milestone files

- `control_plane/production_acceptance.py` — read-only acceptance evaluator.
- `scripts/production_acceptance.py` — CLI with PASS/FAIL exit code.
- `config/production-acceptance.first-tenant.example.json` — strict first-tenant profile.
- `contracts/production-acceptance-report.schema.json` — report contract.
- `docs/production-milestone-1-first-real-tenant.md` — operational runbook and acceptance model.
- `tests/test_production_milestone1.py` — 7 milestone tests.

Run:

```bash
python scripts/production_acceptance.py TENANT_ID \
  --db data/control_plane.db \
  --profile config/production-acceptance.first-tenant.example.json \
  --out acceptance-TENANT_ID.json
```

Current full regression: **244 / 244 passed**.

---

## Architecture history — Phase 20
### Contract & Legal Lifecycle / Trust Provider Gateway

Phase 20 extends the Phase 19 Business AI OS with a governed contract lifecycle that can block billing/onboarding/deployment until the required legal documents are configured and signed.

The design is intentionally **not** a home-built qualified trust service. SolutionPartner owns the portal, contracts workflow, hashes, evidence registry and legal gate; a selected external eIDAS trust/signature provider performs the signature/trust service required by the use case.

## What this phase adds

- Versioned, immutable contract-template registry.
- Contract envelopes with exact document SHA-256 and signer set.
- Legal requirements by customer/tenant and document type.
- `Legal Gate` with fail-closed semantics: no configured requirements = not READY.
- Trust-provider dispatch contract and provider transaction binding.
- Authenticated HMAC webhook reference implementation.
- Idempotent provider event ingestion.
- Append-only chained-hash signature/audit events.
- Evidence manifest with its own SHA-256.
- Evidence verification endpoint.
- RBAC scope family `contracts.*` and dedicated `legal_admin` role.
- Optional strict integration with Phase 10 onboarding via `SP_REQUIRE_LEGAL_GATE=1`.
- Review-required legal drafting skeletons for MSA, DPA, AI Schedule, SLA and connector authorisation.

## Architecture

```text
CRM / Proposal
     |
     v
Contract templates + Legal Requirement Matrix
     |
     v
Rendered immutable PDF + SHA-256
     |
     v
SolutionPartner Contract Envelope
     |
     v
Trust Provider Gateway / Adapter
     |
     v
External eIDAS signature/trust provider
     |
     v
Authenticated provider webhook
     |
     +--> signed artifact / provider evidence reference
     +--> chained event log
     +--> evidence manifest + SHA-256
     |
     v
LEGAL GATE = READY
     |
     +--> Billing / licensing
     +--> Automated onboarding
     +--> Tenant deployment
```

## Core API

### Templates and requirements
- `GET /contracts/templates`
- `POST /contracts/templates`
- `POST /contracts/requirements`
- `GET /contracts/customers/{customer_ref}/gate`

### Contract lifecycle
- `GET /contracts`
- `POST /contracts`
- `GET /contracts/{contract_id}`
- `POST /contracts/{contract_id}/dispatch`
- `POST /contracts/{contract_id}/provider-bind`
- `GET /contracts/{contract_id}/events`
- `GET /contracts/{contract_id}/evidence`

### Trust-provider callback
- `POST /trust/webhooks/{provider}` with `X-SP-Trust-Signature: sha256=<hmac>` reference authentication.

The actual provider adapter must follow the selected provider's strongest callback/authentication scheme; HMAC is the included generic reference mechanism.

## Production legal boundary

This package does not certify that any particular signature method is adequate for a specific contract. Counsel must choose the signature level/formality and approve the contract wording. Where a qualified service is required or marketed, verify the **provider and the specific service** in the EU/national Trusted List.

The system is designed around:

- Spanish LSSI electronic contracting rules;
- eIDAS legal effects and advanced/qualified signature framework;
- Spain Law 6/2020 on trust services;
- GDPR data minimisation/security for signer and evidence data;
- AI Act obligations only where applicable to the actual role/use case.

See `docs/contract-legal-lifecycle.md`.

## Configuration

```env
SP_REQUIRE_LEGAL_GATE=1
SP_TRUST_WEBHOOK_SECRET=<secret-store injected value>
SP_TRUST_PROVIDER=<selected adapter>
```

Provider API credentials belong in Vault/Secret Manager, never in templates, payloads, logs or the Control Plane database.

## Main files

- `control_plane/contracts_lifecycle.py` — templates, envelopes, requirements, state transitions, event chain, evidence.
- `control_plane/db.py` — additive `PHASE20_SCHEMA`.
- `control_plane/app.py` — REST API and onboarding gate.
- `control_plane/rbac.py` — `contracts.*` scopes and `legal_admin`.
- `handlers/trust_provider_adapter_template.py` — adapter interface skeleton.
- `contracts/contract-*.schema.json` — JSON contracts.
- `legal-templates/*` — counsel-review drafting skeletons.
- `docs/phase20-production-acceptance.md` — PAT.
- `tests/test_phase20_contracts.py` and `tests/test_api_phase20.py` — new automated tests.

## Tests

```bash
python -m pytest -q
```

Current Phase 20 package result: **229 passed** (220 inherited regression tests + 9 Phase 20 tests).

## Deployment sequence

1. Deploy with `SP_REQUIRE_LEGAL_GATE=0`.
2. Select and security-review the trust/signature provider.
3. Implement provider adapter and secret refs.
4. Register counsel-approved immutable template versions.
5. Configure legal requirements for staging customer.
6. Complete an end-to-end signature and evidence verification.
7. Run Phase 20 PAT.
8. Enable `SP_REQUIRE_LEGAL_GATE=1` in production.

Phase 20 is additive and preserves the existing Phase 6–19 API/health version contracts.

## Phase 21 - AI Service Management & service governance

Phase 21 introduces a lightweight, auditable service-management layer for SolutionPartner and tenant Business AI OS instances. It is designed around recognised service-management practices and is **not** a claim of ITIL, PeopleCert or ISO certification.

Key API prefix: `/service-management/*`.

See `docs/ai-service-management-governance.md` and `docs/phase21-production-acceptance.md`.
