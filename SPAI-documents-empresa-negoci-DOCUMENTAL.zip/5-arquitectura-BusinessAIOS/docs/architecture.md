# SolutionPartner Control Plane — Architecture after Phase 7

```text
                      SOLUTIONPARTNER.AI
                             │
                    ┌────────▼────────┐
                    │  SP Supervisor  │
                    │ future LLM/UI   │
                    └────────┬────────┘
                             │ safe APIs only
              ┌──────────────▼──────────────┐
              │       CONTROL PLANE         │
              │ Tenant Registry             │
              │ Component Registry          │
              │ Deployment Registry         │
              │ Health + Metric Store       │
              │ Incident Engine             │
              │ Observability API           │
              │ Dashboard                   │
              └──────────────┬──────────────┘
                             │
       ┌─────────────────────┼─────────────────────┐
       ▼                     ▼                     ▼
  Client A VPS          Client B VPS          Client C VPS
  Business OS           Business OS           Business OS
  heartbeat push        heartbeat push        heartbeat push
```

## Trust boundary

El Control Plane no rep credencials d'ERP/CRM del client. Cada tenant conserva els seus secrets al seu entorn. La client key només autentica heartbeat/telemetria cap al Control Plane.

## Future supervisor

Hermes/OpenAI/altres agents poden consumir `/observability/*`, `/tenants/*`, `/registry/*` i `/deployments/*` com a tools. No necessiten accés SSH root als VPS dels clients.
