# Production security checklist

- [ ] Control Plane backend port is not publicly published.
- [ ] Public access goes through TLS edge only.
- [ ] `SP_ALLOW_LEGACY_ADMIN_KEY=0`.
- [ ] `SP_CLIENT_AUTH_MODE=key+mtls`.
- [ ] `SP_TRUSTED_PROXY_TOKEN` is long, random and private to edge/backend.
- [ ] Separate service accounts exist for operations, releases and security.
- [ ] Owner credentials are not used for routine automation.
- [ ] Every tenant has a unique active client credential.
- [ ] Every tenant has its own unique mTLS private key/certificate.
- [ ] Release private key is outside Control Plane and tenant VPSs.
- [ ] Break-glass private key is offline.
- [ ] Client CA private key is offline/HSM-controlled.
- [ ] ERP/CRM/API secret values are absent from Control Plane DB and manifests.
- [ ] `/security/posture` has no unresolved high findings.
- [ ] Security audit is backed up/exported according to retention policy.
- [ ] Database and `/data` volume are backed up and filesystem permissions restricted.
