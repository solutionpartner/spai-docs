# Commercial plans and entitlements

Plans are versioned and immutable. A tenant is assigned one active plan version at a time.

Example:

```text
Starter v1
  - Business Pulse >=1,<2

Growth v1
  - Business Pulse >=1,<2
  - Sales Agent >=1,<2

Enterprise v1
  - Finance Agent >=1,<3
  - Sales Agent >=1,<3
  - Operations Agent >=1,<3
```

Packages marked `commercial` require a matching entitlement for direct activation. Packages marked `internal` are technical infrastructure and do not require a commercial entitlement.

Dependencies are resolved technically from the entitled root package. The plan remains the commercial boundary; dependency packages do not become separately customer-selectable merely because they were installed as technical prerequisites.

Changing a customer's plan does not silently install or remove packages. Package activation remains a separate approved lifecycle action.
