# Credential rotation runbook

## Tenant key

1. Call `POST /security/tenants/{tenant}/credentials/rotate` with a short grace window.
2. Save the new key immediately in the tenant's local secret store.
3. Restart/reload the heartbeat and deployment worker.
4. Verify a successful heartbeat with the new key.
5. Let the old credential expire or revoke it immediately.
6. Review security events.

For suspected compromise use `grace_seconds: 0` and revoke immediately.

## Service Account

1. Call `POST /security/service-accounts/{id}/rotate`.
2. Update the calling system/password manager.
3. Verify with a low-risk read endpoint.
4. Revoke the old credential or wait for the grace expiry.

Never send generated tokens through ordinary logs, tickets or deployment manifests.
