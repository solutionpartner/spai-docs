# Migration - Phase 20 to Phase 21

Phase 21 is additive. Existing Phase 20 tables and APIs remain intact.

1. Deploy the Phase 21 package; database startup creates the new service-management tables idempotently.
2. Create one platform service per major Control Plane capability and one tenant service per commercial capability that requires explicit operational ownership.
3. Link existing active incidents to the affected service where known.
4. Register high-value CIs: runtime, agents, workflows, connectors, model-routing policy, local AI runtime and critical external providers.
5. Define SLOs for production services. Start with availability, freshness, successful execution and recovery objectives.
6. Use change records for governed production changes and link deployment/rollout IDs.
7. Seed the knowledge base from runbooks already present in `/docs`.
8. Open continual-improvement items only with an owner and measurable outcome when practical.

No certification status is created by this migration.
