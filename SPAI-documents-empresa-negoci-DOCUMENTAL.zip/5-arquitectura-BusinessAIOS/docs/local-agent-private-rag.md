# Local Agent + Private RAG architecture

## Goal
Keep private documents and local-system access inside the tenant environment while exposing only a narrow, authenticated capability surface to Business AI OS.

```text
Web UI / Business AI OS
        |
Tenant Router + Approval Engine
        |
Local Agent capability request
        |
+---------------- tenant LAN / PC ----------------+
| Local Agent                                     |
|  - signed installation / license lease          |
|  - allowlisted roots                            |
|  - Private RAG index (SQLite FTS5)              |
|  - local connectors                             |
|  - telemetry only -> Control Plane              |
+-------------------------------------------------+
```

## Privacy boundaries
- Document bytes, extracted text and RAG chunks remain local by default.
- Control Plane receives health/metrics only, never document contents or user queries.
- Paths are allowlisted and resolved canonically; symlinks are ignored to prevent escaping configured roots.
- No arbitrary shell execution is part of the Local Agent protocol.
- Write-capable local connectors must still go through the tenant Approval Engine.
- Licensing is verified locally using the signed Phase 16 entitlement lease.

## Search
Phase 17 ships a zero-cloud lexical retrieval backend based on SQLite FTS5. PDF parsing uses optional `pypdf`; DOCX parsing is stdlib ZIP/XML. A later embedding backend can be added behind the same interface (local Ollama/llama.cpp/ONNX, etc.).

## Updates
The Local Agent is a normal signed catalog/deployment component. Phase 8 deployment and Phase 15.1 GitOps/DR apply to it; the installer never self-updates from an arbitrary URL.

## Privacy modes
- `strict_local`: retrieved chunks are not intended to leave the local machine. Pair with a local inference backend for fully private answer generation.
- `hybrid_retrieval`: retrieval remains local, but selected chunks may be passed to the tenant Business OS/model under tenant policy.

The shipped HTTP service binds to `127.0.0.1` by default and requires `SP_LOCAL_AGENT_TOKEN`; exposing it to a LAN requires an explicit deployment decision and network controls.
