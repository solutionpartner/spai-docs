# mTLS runbook

## Enrollment

1. Issue a unique client certificate for the tenant.
2. Keep its private key on that tenant VPS only.
3. Calculate SHA-256 fingerprint using `scripts/cert_fingerprint.py`.
4. Enroll the fingerprint in the Control Plane.
5. Configure client agent/deployer with `SP_MTLS_CLIENT_CERT` and `SP_MTLS_CLIENT_KEY`.
6. Test against the client mTLS hostname.
7. After all clients are enrolled, set `SP_CLIENT_AUTH_MODE=key+mtls`.

## Revocation

- Revoke the certificate in the Control Plane immediately.
- Revoke it in the CA/edge trust lifecycle as applicable.
- Issue a replacement keypair/certificate rather than reusing the compromised private key.

The Control Plane accepts TLS identity headers only with the internal `SP_TRUSTED_PROXY_TOKEN`, and the production Compose example does not publish the backend port.
