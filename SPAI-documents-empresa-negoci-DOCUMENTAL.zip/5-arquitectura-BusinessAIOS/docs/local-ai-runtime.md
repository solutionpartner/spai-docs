# Local AI Runtime — Phase 18

Phase 18 adds local model inference to the Phase 17 Local Agent. In `strict_local`, document extraction, retrieval, prompt construction and generation all happen inside the client machine/server.

## Supported backends

- `ollama`: native Ollama `/api/chat` and `/api/embed` APIs.
- `openai_compat`: local OpenAI-compatible endpoint intended for `llama-server` / llama.cpp.

Both are rejected unless `base_url` resolves to loopback (`localhost`, `127.0.0.1`, `::1`). Phase 18 does not automatically download models and does not accept a cloud URL as a local runtime.

## Flow

```text
Local files/NAS
   -> Private RAG (SQLite FTS5)
   -> selected chunks
   -> Local AI Runtime
   -> local answer
```

The Control Plane may receive operational telemetry (backend, health, model identifier, latency/error counts) but not questions, retrieved chunks, document content, prompts or generated answers.

## Endpoints

- `GET /v1/ai/health`
- `POST /v1/ai/chat`
- `POST /v1/ai/embed`
- `POST /v1/rag/answer`

All Phase 18 endpoints require the Local Agent bearer token. The Local Agent should bind to `127.0.0.1` unless a separately authenticated local reverse proxy is deliberately configured.

## Privacy modes

### strict_local
RAG and answer generation stay on the client host. Use a local chat model. This is the default for sensitive data.

### hybrid_retrieval
The Phase 17 retrieval policy may allow selected chunks to be forwarded to the tenant Business OS. Phase 18 still offers local generation, but hybrid forwarding must remain an explicit tenant policy.

## Production recommendations

Pin an approved model/version, restrict outbound egress from the Local Agent where practical, keep inference endpoints on loopback, monitor model/runtime health, and use signed Phase 8 deployments to update the Local Agent configuration/runtime components.
