# SolutionPartner Business AI OS — Phase 19
## AI FinOps, Token Metering & Model Router

Phase 19 extends the Phase 18 Local AI Runtime with deterministic AI cost governance across every tenant.

### What this phase adds

- AI model registry with classes: `local`, `free_tier`, `low_cost`, `premium`.
- Per-tenant monthly budgets, soft/hard thresholds and hard-limit actions.
- Routing modes: `economy_first`, `balanced`, `quality_first`.
- Privacy-aware routing (`strict_local` can never route to cloud).
- Capability-aware routing (chat/tools/json/etc.).
- Model fallback chains.
- Token metering by tenant, model, agent, workflow and task type.
- Server-computed estimated EUR cost from versioned price metadata.
- Month-to-date cost summaries and simple spend-anomaly detection.
- Billing entitlement enforcement before model routing.
- Read-only AI cost visibility for the SP Supervisor/Hermes.
- No prompt/response storage in FinOps telemetry.

### Recommended SME policy

Use `economy_first` from day one. Run deterministic workflows without an LLM, use Local AI or a genuine free tier for repetitive/simple work, low-cost cloud for normal work, and premium models only for tasks where their extra quality is justified. At the soft budget threshold, automatically become more conservative. At the hard threshold, switch to `local_only` or deny non-essential tasks.

> Important: “open-weight/local” and “free API” are not the same. A self-hosted model can have zero marginal API-token cost while still consuming hardware/electricity. A cloud API advertised as inexpensive can still be paid. Provider rates and free allowances must be refreshed in the model registry.

### Main flow

```text
Tenant request
    |
    v
Billing entitlement check
    |
    v
AI Model Router
    |-- privacy
    |-- required capabilities
    |-- task complexity
    |-- routing policy
    |-- month-to-date budget band
    v
Selected model + fallback chain
    |
    v
Provider/Local AI adapter
    |
    v
Usage report (tokens only)
    |
    v
AI FinOps ledger + cost dashboard/Supervisor
```

### API surface

- `GET/POST /ai/models`
- `GET/PUT /ai/tenants/{tenant_id}/budget`
- `GET/PUT /ai/tenants/{tenant_id}/routing`
- `POST /client/{tenant_id}/ai/route`
- `POST /client/{tenant_id}/ai/usage`
- `GET /ai/tenants/{tenant_id}/usage`
- `GET /ai/fleet/usage`

Administrative route/usage endpoints are also available with the appropriate `ai.*` RBAC scopes.

### Security and privacy

FinOps does not accept prompt text, generated text, RAG chunks, API keys or secret values. Model endpoints should be represented by references and provider credentials stay in the Secret Manager/Vault. `strict_local` routes only to models registered as `local`.

### Files

- `control_plane/ai_finops.py` — registry, budget, routing, metering, anomaly logic.
- `docs/ai-finops-model-routing.md` — architecture and operational policy.
- `contracts/ai-*.schema.json` — new Phase 19 contracts.
- `examples/ai-*.json` — sample budget/routing/local-model/usage payloads.
- `tests/test_phase19_ai_finops.py` — domain tests.
- `tests/test_api_phase19.py` — HTTP/RBAC/client-flow tests.

### Run tests

```bash
python -m pytest -q
```

Phase 19 remains additive and compatible with the Phase 18 database.
