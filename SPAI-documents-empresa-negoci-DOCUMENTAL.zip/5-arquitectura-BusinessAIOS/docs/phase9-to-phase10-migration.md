# Migració Fase 9 → Fase 10

La Fase 10 és additiva. `Database` crea automàticament tres taules noves:

- `onboarding_templates`
- `onboarding_jobs`
- `onboarding_steps`

No modifica ni elimina tenants, releases, deployments, incidents, service accounts, certificats o secret refs existents.

Els rols mantenen els permisos previs. S'afegeix `onboarding.read` als rols de lectura i `onboarding.*` a `platform_admin`; `owner` continua heretant `*`.
