# License operations runbook

## Key setup
1. Generate an Ed25519 license keypair with `scripts/generate_license_keys.py`.
2. Keep the private key on an isolated signer host/HSM. Never mount it into the Control Plane.
3. Configure `SP_LICENSE_PUBLIC_KEY_PEM` or `SP_LICENSE_PUBLIC_KEY_PATH` on the Control Plane.
4. Install the same public key on tenant runtimes for local lease verification.

## Signer
Create a service account with role `license_signer` and run `scripts/license_signer_worker.py` on the isolated signing host. In production use a timer/queue runner rather than sharing a general-purpose shell with Hermes.

## Tenant sync
The tenant VPS periodically runs `scripts/license_client_sync.py`. It registers/binds its installation, fetches the current valid lease, or requests a renewal. The saved lease is mode `0600`.

## Payment failure
`payment.failed` sets the subscription to `past_due` and starts a bounded grace period. After the grace timestamp, the next entitlement evaluation/lease renewal yields `restricted`. `payment.succeeded` returns the tenant to `active`.

## No destructive enforcement
Billing status never deletes databases, documents, workflows, backups or secrets. Suspension is access/enforcement state only.
