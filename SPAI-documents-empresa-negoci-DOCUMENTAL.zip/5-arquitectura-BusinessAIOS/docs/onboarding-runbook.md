# Runbook — donar d'alta un client nou

1. Registrar prèviament les versions de components que formaràn la plantilla.
2. Registrar una plantilla versionada a `POST /onboarding/templates`.
3. Fer `POST /onboarding/preview` per detectar prerequisits que falten.
4. Crear el job amb `POST /onboarding/jobs`.
5. Un `platform_admin` o `owner` aprova `POST /onboarding/jobs/{id}/approve`.
6. Executar `POST /onboarding/jobs/{id}/execute`.
7. Guardar immediatament el `client_key` retornat; no es pot recuperar després.
8. Al VPS del client, generar la clau privada/certificat o CSR localment. No enviar la clau privada al Control Plane.
9. Popular els valors reals als backends indicats per `secret_refs` (Vault/AWS/GCP/Azure/env/file).
10. Enrolar el certificat mTLS al Control Plane si la plantilla ho exigeix.
11. Aprovar i deixar completar els deployments inicials signats.
12. Arrencar client agent/deployer i verificar heartbeat saludable.
13. Consultar `GET /onboarding/jobs/{id}/readiness`.
14. Quan `ready=true`, finalitzar amb `POST /onboarding/jobs/{id}/finalize`.

## Si es perd el client_key

No es recupera. Cal rotar la credencial del tenant des de Fase 9 i instal·lar la nova al VPS.

## Si l'onboarding falla a mig camí

Corregir la causa i tornar a executar el mateix job. No crear un job nou amb el mateix `tenant_id`.

## Cancel·lació

`cancel` és deliberadament no destructiu. No elimina el tenant, secret refs o deployments ja creats. La neteja s'ha de fer explícitament i auditada.
