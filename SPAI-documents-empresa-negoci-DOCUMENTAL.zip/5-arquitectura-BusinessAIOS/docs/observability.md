# Observability model

## Objectiu

Separar **telemetria operativa** de **dades de negoci**. El Control Plane necessita saber si un Business OS funciona; no necessita conèixer el contingut del negoci del client.

## Telemetria permesa

- estat de components;
- latència;
- comptadors d'errors;
- versions;
- profunditat de cues;
- approvals pendents;
- jobs fallits;
- heartbeat timestamp;
- incidents i deployments.

## Telemetria que no s'ha de centralitzar en aquesta capa

- factures;
- imports de vendes per client final;
- contingut de correus;
- dades personals de contactes;
- tokens/API keys;
- payloads complets d'ERP/CRM;
- memòria conversacional del tenant.

## Flux

```text
Business OS client
    │
    │ authenticated heartbeat
    ▼
Health Snapshot ──► Metric Samples
    │                    │
    └──────────┬─────────┘
               ▼
        Incident Engine
               │
        ┌──────┴──────┐
        ▼             ▼
 Dashboard       SP Supervisor
```

## Incident lifecycle

```text
condition detected
      │
      ▼
     open ─────────► acknowledged
      │                  │
      └──────────┬───────┘
                 ▼
              resolved
```

Els incidents automàtics tenen fingerprint estable i `active_key` única. En recuperar-se el servei, `active_key` passa a NULL i l'incident queda a l'historial.

## Stale evaluation

La detecció de heartbeat stale no ha de dependre d'un GET del dashboard. Per això existeix un evaluator explícit que es pot cridar periòdicament. Això evita efectes laterals en endpoints read-only i facilita escalar a més d'una rèplica en fases futures.
