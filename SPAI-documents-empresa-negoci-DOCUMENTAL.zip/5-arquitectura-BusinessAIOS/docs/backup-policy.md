# Backup policy baseline

Production policy should define RPO/RTO per plan. A safe initial baseline is:
- Control Plane DB: encrypted backup at least daily plus transaction/volume snapshots as supported by the production DB.
- Tenant critical DB/data: encrypted daily backup; higher frequency for higher-SLA plans.
- Git tenant snapshot: on every approved configuration/workflow/deployment change and at least daily reconciliation.
- Release artifacts: immutable object storage with checksums and retention independent from GitHub.
- Secrets: provider-native replication/versioning; never export secret values to Git backups.

Backups are not considered healthy until restore tests are performed. Schedule periodic restore drills into an isolated environment and record evidence/results.
