# Local Agent installation

1. Create/register a tenant installation and obtain a valid signed entitlement lease.
2. Install the signed `local-agent` release through the Deployment Engine.
3. Configure one or more RAG roots locally. Use least privilege: read-only service account where possible.
4. Register the Local Agent with the Control Plane and report health metrics only.
5. Create a RAG profile in the Control Plane for desired-state/audit visibility; the actual file paths are interpreted only on the tenant machine.
6. Run an initial scan and verify that no roots can be escaped through symlinks.
7. Enable scheduled incremental scans.

Never put Holded/ERP/API credentials or document contents in the Control Plane profile.
