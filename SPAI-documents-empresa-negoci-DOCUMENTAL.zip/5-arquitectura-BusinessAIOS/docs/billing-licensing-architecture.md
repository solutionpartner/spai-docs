# Phase 16 — Billing, Licensing & Entitlement Enforcement

## Objective
A tenant may run Business AI OS on its own VPS/PC, but commercial authorization is issued by SolutionPartner.ai. Runtime availability must not depend on a network round-trip for every user request.

## Chain
```text
Billing provider
   ↓ provider webhook adapter (verifies provider signature)
Normalized billing event
   ↓
Subscription state
   ↓
Entitlement state
(active / grace / restricted / suspended)
   ↓
Unsigned license lease job
   ↓ isolated Ed25519 signer
Signed lease
   ↓
Tenant Business OS
   ↓ local signature + expiry + installation check
RuntimeOrchestrator enforcement
```

## Provider boundary
The Control Plane endpoint `/billing/events/normalized` intentionally does **not** accept raw Stripe/Adyen/etc. webhook secrets. A provider adapter verifies the vendor's signature and sends only normalized events using a `billing_adapter` service account.

Raw payment-card data must never enter Business AI OS or the Control Plane.

## State model
- `active`: normal service.
- `grace`: payment issue, normal service continues with warning for a bounded period.
- `restricted`: grace expired. Read/export remain available; AI execution, write actions, deployments and new automations are disabled.
- `suspended`: cancelled/suspended/no authorized subscription. AI and mutations are disabled; data is not deleted.

Repeated payment-failure events do not extend an existing grace window.

## Lease model
A lease contains:
- tenant ID;
- installation ID;
- installation public-key hash;
- environment;
- plan ID/version;
- entitlement status and enforcement flags;
- plan entitlements and currently active packages;
- issued/not-before/expires timestamps.

The lease is signed with Ed25519. The Control Plane stores only the public verification key. The private signing key belongs to a separate signer/HSM/secret-isolated worker.

Default lease duration is 72h, capped at 7 days. Restricted/suspended leases are shorter.

## Offline behavior
The runtime keeps the last valid signed lease and can operate until it expires. A Control Plane/network outage therefore does not immediately stop the company. Once the lease expires, the local runtime must deny licensed AI/mutation functions until a new valid lease is obtained.

## Deployment enforcement
Phase 16 also blocks new deployments/package activations for tenants whose entitlement is `restricted` or `suspended`. Set `SP_REQUIRE_BILLING=1` in production if tenants with no billing record must also be blocked.

## Installation binding caveat
The current installation binding prevents accidental reuse and binds the lease to an installation identifier + public-key hash. A file-based private key is **not hardware attestation**. For strict anti-clone guarantees, use a TPM/HSM/cloud instance identity with a non-exportable key and a proof-of-possession/attestation flow.
