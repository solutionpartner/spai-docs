# Phase 19 — AI FinOps & Model Router

## Goal

Control AI spend per tenant without turning every request into a premium-model call. The router is deterministic and provider-neutral. It chooses an eligible model from a registry based on privacy, capabilities, complexity, tenant routing policy, and current budget band.

## Model classes

- `local`: self-hosted via Local AI Runtime. API marginal token cost is recorded as 0; hardware/electricity are separate infrastructure costs.
- `free_tier`: a cloud allowance that is actually free only while the provider allowance/credits remain available. The registry must be updated when that allowance is exhausted.
- `low_cost`: paid cloud models optimized for cost/throughput.
- `premium`: higher-cost models reserved for tasks where quality/complexity justify it.

Do not label a paid API as `free_tier`. DeepSeek's API, for example, is token-billed; it can be registered as `low_cost`, while an approved self-hosted open-weight model can be `local`.

## Default routing

`economy_first` is the recommended default for SMEs:

1. simple work -> local/free tier first;
2. standard work -> cheapest eligible model according to policy;
3. complex work -> still starts from the configured economy policy unless a task override asks for `balanced` or `quality_first`;
4. `strict_local` -> local models only, regardless of quality score;
5. soft budget band -> force `economy_first`;
6. hard budget band -> policy chooses `local_only`, `block_nonessential`, or `block_all`.

A tenant can override selected task types, e.g. executive strategic analysis can use `quality_first` while email classification stays `economy_first`.

## Cost model

Usage events contain only:

- tenant;
- model/provider/class;
- agent/workflow/task type;
- input, cached-input and output tokens;
- server-computed estimated EUR cost;
- timestamp/request id.

No prompt, retrieved RAG chunk, model response, API key or secret is accepted by the usage schema.

The cost is computed from the registry price snapshot. Pricing is mutable metadata and must be refreshed when providers change prices. `pricing_source` and `pricing_as_of` make that update auditable.

## Budget bands

A budget policy defines:

- monthly EUR budget;
- soft threshold (default 80%);
- hard threshold (default 100%);
- hard action.

Recommended behavior:

- normal: configured routing mode;
- soft: economy-first plus alert;
- hard/local_only: only local inference;
- hard/block_nonessential: deny optional AI tasks but keep essential ones routable;
- hard/block_all: no new model calls until policy/budget changes.

This is independent from billing entitlement. A tenant in Billing `restricted/suspended` is denied AI before budget routing.

## Provider strategy

The registry is intentionally provider-neutral. Typical classes can include:

- Ollama / llama.cpp local models -> `local`;
- genuine provider free allowance -> `free_tier` while available;
- DeepSeek API or other inexpensive paid APIs -> `low_cost` when their current rates justify it;
- frontier/premium APIs -> `premium`.

Never hard-code a provider as permanently free or cheap. Prices, free allowances, model names and rate limits change.

## Supervisor

Hermes/SP Supervisor gets read-only tools:

- `tenant_ai_usage(tenant_id)`;
- `fleet_ai_usage()`.

It can diagnose high spend or anomalous usage. It cannot alter usage records, provider pricing or budgets through MCP in this phase.

## Production follow-up

The next production step is an execution gateway/provider adapter layer that consumes the selected route and invokes the provider using secret references. Provider adapters should report actual token usage back to `/client/{tenant}/ai/usage`, and circuit-break/fallback on 429/5xx errors without bypassing privacy/budget policy.
