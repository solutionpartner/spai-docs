# Production Milestone 1 — First Real Tenant

## Objective

Validate the existing Business AI OS v1.0 architecture against one real production tenant without creating a new architectural phase. The milestone is an operational acceptance gate: the system must prove that onboarding, commercial entitlement, runtime delivery, governed deployment, health, service governance, backup/recovery and rollback are all evidenced in the Control Plane.

## Acceptance principle

The gate is **read-only**. It never fixes or mutates a tenant. A failed check produces a blocker and a remediation instruction. Human operators retain the decision and execute any required change through the existing governed paths.

## Canonical acceptance path

1. Governed onboarding reaches `ready`.
2. Tenant has an active commercial plan and billing entitlement.
3. Production installation is registered, licensed and protected with mTLS.
4. Business Pulse and the n8n base workflow are active.
5. Runtime desired state exposes `business.pulse` and at least one governed ERP read tool.
6. Client reports the current desired-state revision/hash as `applied`.
7. Latest health snapshot is `healthy`.
8. At least one completed deployment retains `approved_by` evidence.
9. Managed service records exist and each high/critical service has an active SLO.
10. An encrypted completed backup and a ready recovery point exist.
11. A controlled restore rehearsal has completed successfully and is recorded as `dr.restore.rehearsal` / `success` in Security Audit.
12. A controlled rollback rehearsal has completed successfully.
13. No unresolved critical incident remains open.

## Run

```bash
python scripts/production_acceptance.py TENANT_ID \
  --db data/control_plane.db \
  --profile config/production-acceptance.first-tenant.example.json \
  --out acceptance-TENANT_ID.json
```

Exit code `0` means the acceptance report passes. Exit code `2` means one or more production blockers remain.

## Why rollback rehearsal is mandatory

A backup is not the same as recoverability and a signed release is not the same as rollback readiness. The first real tenant milestone therefore requires a ready recovery point, a successfully audited restore rehearsal, and evidence of one successfully completed rollback deployment referencing its original deployment through `rollback_of`.

## Scope boundary

This milestone does not add a bypass, a new approver, a second deployment engine or autonomous repair. It only evaluates evidence already produced by onboarding, billing/licensing, runtime sync, deployments, observability, GitOps/DR and Service Governance.
