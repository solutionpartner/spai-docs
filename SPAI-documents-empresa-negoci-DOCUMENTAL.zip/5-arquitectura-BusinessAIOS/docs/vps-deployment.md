# VPS deployment — Phase 9

For development, the original `docker-compose.yml` can still expose the Control Plane on loopback only.

For production use `docker-compose.secure.yml` and the TLS edge.

## Required production properties

- Control Plane container is not directly published to the Internet.
- Human/automation API uses `Authorization: Bearer sp_sa...`.
- Tenant API uses a separate hostname with mTLS.
- `SP_CLIENT_AUTH_MODE=key+mtls` after enrollment is complete.
- `SP_ALLOW_LEGACY_ADMIN_KEY=0` after migration.
- Only public release and break-glass verification keys are mounted.
- Tenant/API secret values remain outside the central Control Plane.

See `production-security-checklist.md`, `mtls-runbook.md` and `phase8-to-phase9-migration.md`.
