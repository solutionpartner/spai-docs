# Model de seguretat de l'onboarding

- **Aprovació separada:** crear un onboarding i aprovar-lo són permisos diferents.
- **Release gate separat:** els deployments inicials continuen exigint l'aprovació definida a Fase 8.
- **One-time credential:** la credencial del tenant només apareix a la resposta del primer `execute` que crea el tenant.
- **No secret values:** les plantilles només poden contenir localitzadors de secrets; camps com `api_key`, `password`, `token` o `private_key` són rebutjats.
- **mTLS client-side:** la clau privada del certificat es genera al client i no s'envia al Control Plane.
- **Sense SSH/root:** el Control Plane no necessita credencials root del VPS. El client reclama jobs aprovats amb pull-based deployment.
- **Readiness gate:** el tenant no passa a `ready` fins que compleix credencial, mTLS si aplica, deployments i heartbeat saludable.
- **Plantilles immutables per versió:** un canvi de configuració exigeix publicar una nova versió de plantilla.
