# Package lifecycle

## Package lifecycle

`draft -> published -> deprecated -> retired`

A retired package cannot return to service. A deprecated package may be republished if necessary, but new activations only resolve packages currently marked `published`.

## Version lifecycle

`draft -> published -> deprecated -> retired`

Package versions are immutable. Changes require a new version. The resolver only selects versions in `published` state for new activations.

## Dependency resolution

Dependencies use PEP 440-compatible version ranges such as `>=1.0,<2.0`. Resolution is recursive and deterministic:

1. filter to published versions;
2. filter by requested/dependency version constraint;
3. filter by tenant Business OS compatibility;
4. choose the highest remaining version;
5. resolve dependencies before the root package;
6. reject cycles or incompatible constraints.

Optional dependencies may be skipped if they cannot be resolved.

## Safe deactivation

Phase 11 deactivation is deliberately non-destructive. It revokes the catalog activation and disables the component in tenant inventory; it does not delete tenant data, secrets or historical audit records. A future package-specific uninstall workflow may be modeled as a separately approved signed deployment.
