# Install SP Supervisor in Hermes

1. Create a dedicated Hermes profile (recommended name: `sp-supervisor`). Do not reuse a general-purpose profile.
2. Copy `hermes-profile/SOUL.md`, `.hermes.md`, `knowledge/` and `skills/` into that profile, or run `scripts/bootstrap_hermes_supervisor.py`.
3. Merge `hermes-profile/config.yaml.example` into the profile `config.yaml`.
4. Put `SP_PHASE14_ROOT`, `SP_CONTROL_PLANE_URL` and `SP_SUPERVISOR_TOKEN` in the profile `.env`; never commit the real token.
5. Create the Control Plane service account with role `supervisor_operator`. It can read, request governed actions, execute AUTO actions, and execute already-approved actions, but it cannot approve its own requests.
6. Install MCP SDK v2 into the environment that launches the stdio server: `pip install -r requirements-hermes.txt`.
7. Reload MCP or start a new Hermes session.
8. Test with: “Show fleet health and identify any tenant requiring attention.” Then inspect `action_policies` before testing a low-risk AUTO action.

## Recommended capability surface

The example profile enables only `skills`, `memory`, and the `mcp-sp_control_plane` toolset. Keep terminal, browser, generic code execution and connection-management disabled for this profile.

## Token rotation

Rotate the Control Plane service-account token using the Phase 9 security workflow. Update the Hermes profile `.env`, then reload MCP. Do not store the token in SOUL.md, memory, skills, project context or git.
