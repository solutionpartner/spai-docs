# Release signing runbook

## 1. Generate keys once

```bash
python scripts/generate_release_keys.py \
  --private /secure/offline/release-private.pem \
  --public ./secrets/release-public.pem
```

Keep the private key in a CI secret manager or offline signing environment. Distribute only the public key to the Control Plane and client VPSs.

## 2. Build and hash the artifact

The artifact must be immutable. Store the digest as `sha256:<64 hex>` in the manifest. For OCI/Docker artifacts, prefer immutable digests in the actual release pipeline.

## 3. Sign offline

```bash
python scripts/sign_release_manifest.py examples/release-manifest.json \
  --private-key /secure/offline/release-private.pem \
  --output /tmp/signed-release.json
```

## 4. Register

POST the envelope to `/releases/manifests` using the SolutionPartner admin credential. The Control Plane verifies the signature with `SP_RELEASE_PUBLIC_KEY_PATH` or `SP_RELEASE_PUBLIC_KEY_PEM` before accepting it.

## 5. Revoke when necessary

`POST /releases/manifests/{manifest_id}/revoke` blocks the corresponding component version for new assignments/rollouts. Existing running software is not forcibly removed; remediation/rollback remains an explicit controlled action.
