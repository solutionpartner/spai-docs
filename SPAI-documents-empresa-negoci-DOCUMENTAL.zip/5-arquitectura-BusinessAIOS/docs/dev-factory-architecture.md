# Dev Factory architecture

## Trust boundaries

```text
Hermes / Product request
        |
        | governed request only
        v
Control Plane Dev Factory
        |
        | persistent jobs, no shell
        v
Isolated worker pool / CI
  architect | coding | automation | testing | security | packager
        |
        v
artifact + evidence
        |
        v
Control Plane gates
        |
        v
unsigned release candidate
        |
        v
protected signer / release registry
        |
        v
Phase 8 rollout + Phase 14 governance
```

The Control Plane stores metadata, status, evidence summaries and artifact digests. Source credentials, model credentials, signing keys and repository write credentials belong in the worker/CI secret boundary, not the Control Plane database.

## Why workers are separate

A coding agent needs filesystem/repository/build tools. Those capabilities are too broad for the fleet Supervisor. Workers therefore receive one narrow job, in an isolated workspace, and return structured results. The Control Plane never accepts a model-generated shell command as a job definition.
