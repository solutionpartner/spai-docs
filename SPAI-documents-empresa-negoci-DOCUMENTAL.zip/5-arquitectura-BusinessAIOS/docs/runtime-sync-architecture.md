# Fase 12 — Tenant Runtime Sync & Agent Orchestrator

## Objectiu

Connectar el **desired state** del Control Plane amb el runtime real de cada tenant. El Business OS local no descobreix agents o tools de manera oberta: només carrega allò que el Control Plane ha reconciliat a partir del Catalog, activacions i polítiques.

```text
Control Plane
  Catalog + active activations + tenant inventory + runtime policy
                         |
                         v
              Runtime Desired State (revision N)
                         |
                    TLS + mTLS/key
                         v
Tenant VPS      runtime_sync_worker -> atomic state store
                         |
                         v
               Router / RuntimeOrchestrator
                 |                  |
                 v                  v
            active routes      granted tools
                                 |
                          write -> Approval Engine
```

## Principis

1. **Deny-by-default**: el que no apareix a desired state no existeix per al Router.
2. **No secrets**: només `config_ref` i metadades no sensibles.
3. **No write-on-read**: el client GET no reconcilia automàticament. Si el Catalog ha canviat, el Control Plane respon `stale; reconcile required`.
4. **Atomic apply**: el client valida el hash abans de substituir l'estat local i conserva `last_good`.
5. **No arbitrary code**: el desired state referencia handlers locals allowlisted; no conté Python, shell ni URLs executables arbitràries.
6. **Writes require Approval Engine**: una tool `mode=write` retorna una proposta, no una execució directa.

## Font de veritat

El desired state es deriva de:

- `tenant_package_activations` en estat `active`;
- la versió publicada del Package Catalog;
- el component realment instal·lat i `enabled=true` al tenant inventory;
- `metadata.runtime` de la package version;
- `tenant_runtime_policy`.

Una activació comercial que encara no s'ha desplegat no entra al runtime.

## Revisions i stale detection

Cada reconciliació que modifica la font genera una nova `revision`. Si no canvia res, reconciliar és idempotent i conserva la revisió. El GET de client compara el `source_hash` actual amb el de la darrera revisió; si divergeixen, bloqueja la sincronització fins que un operador/scheduler reconcilia.

`state_hash` garanteix consistència del payload. La seva autenticitat depèn del canal HTTPS i, en producció, del mTLS definit a Fase 9; el hash no substitueix TLS/mTLS.

## Orchestrator

`tenant_runtime.RuntimeOrchestrator` és una frontera determinista que pot ser usada per Hermes, OpenAI Agents o qualsevol altre agent. L'agent no rep accés directe a handlers del sistema: demana executar un intent o una tool i l'Orchestrator comprova desired state i policy.

No és un framework LLM. És el **policy enforcement point** del Business OS local.
