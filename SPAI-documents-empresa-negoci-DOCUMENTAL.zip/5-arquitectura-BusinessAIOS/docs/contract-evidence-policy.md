# Contract Evidence Policy

The evidence package is a technical index, not a replacement for the trust provider's original evidence.

Each signed contract stores/references:

- exact unsigned PDF URI + SHA-256;
- exact signed PDF URI + SHA-256 when supplied;
- template ID/version and document type;
- provider and provider transaction ID;
- provider evidence reference;
- signed timestamp returned by provider;
- append-only event chain root and event count;
- evidence manifest SHA-256;
- Security Audit events for administrative actions.

The chain detects mutation inside the Control Plane database. Production storage should additionally use immutable/WORM-capable object retention where appropriate and backups/DR.

Signer IP, user agent, authentication events or identity attributes may be personal data. Collect only what the selected provider and counsel determine is necessary, document the purpose/retention and restrict access.
