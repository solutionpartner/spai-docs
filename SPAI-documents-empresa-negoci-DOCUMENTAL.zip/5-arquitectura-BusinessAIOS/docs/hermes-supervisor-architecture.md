# Phase 14 — SP Supervisor / Hermes architecture

Hermes is the operator-facing reasoning/orchestration layer. It is **not** the security authority and it does not receive root infrastructure access.

## Context layers

- `SOUL.md`: stable identity and governance behavior.
- `.hermes.md`: SolutionPartner project rules and authority workflow.
- `knowledge/`: architecture, phases, glossary and authority model.
- `skills/`: on-demand operating procedures.
- MCP: live Control Plane state and the governed Action Gateway.

## Tool surface

Read-only tools expose fleet, tenant, incident, deployment, runtime and catalog state.

Phase 14 additionally exposes:

- `action_policies`
- `propose_action`
- `action_status`
- `execute_approved_action`

No approval tool is exposed to Hermes.

## Authority path

```text
Hermes service account: supervisor_operator
   |
   +-- READ --------------------------> live state
   +-- AUTO --------------------------> bounded deterministic adapter
   +-- APPROVAL -> pending ----------> human owner/platform_admin approval
   |                                      |
   |                                      +-> Hermes execute-approved
   +-- FORBIDDEN ---------------------> denied
```

The Action Gateway is the only model-facing mutation boundary in this phase. Unknown actions are denied by default. Payloads are hash-bound and approval windows expire.
