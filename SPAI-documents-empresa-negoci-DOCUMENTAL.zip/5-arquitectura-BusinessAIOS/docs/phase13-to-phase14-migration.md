# Phase 13 → Phase 14 migration

1. Back up the Control Plane database.
2. Deploy the Phase 14 code. Database initialization creates `supervisor_action_requests` and `supervisor_action_events`; existing tables are preserved.
3. Create a new service account with role `supervisor_operator` for the Hermes SP Supervisor. Do not reuse an owner token.
4. Replace `SP_SUPERVISOR_TOKEN` in the dedicated Hermes profile `.env` and reload the MCP server.
5. Replace/merge `SOUL.md`, `.hermes.md`, `knowledge/`, `skills/` and `config.yaml.example` from Phase 14.
6. Verify `action_policies`, then test `observability.evaluate_fleet` as an AUTO action.
7. Test an APPROVAL action (`runtime.reconcile`) and confirm Hermes receives `pending_approval`, a human owner/platform_admin approves it, and Hermes can only then execute it.

No existing tenant runtime state, catalog activation, deployment, onboarding or observability data is deleted by this migration.
