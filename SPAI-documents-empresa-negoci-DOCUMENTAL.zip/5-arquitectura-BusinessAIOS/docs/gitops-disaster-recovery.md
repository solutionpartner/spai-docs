# Phase 15.1 — GitOps & Disaster Recovery

## Goal
No tenant-specific deployable state should exist only on a client VPS. A tenant can be reconstructed from independent sources without copying secrets into Git.

## Four backup planes
1. **Git repository (recommended: private GitHub repository)** — declarative tenant state, runtime policy, package activations, component versions and versioned n8n workflow JSON.
2. **Object storage** — signed release artifacts and encrypted database/data backups.
3. **Secret manager** — secret values. Git and the Control Plane store references only.
4. **Control Plane database** — operational indexes, audit, health and recovery metadata. It also needs encrypted backups.

## Git layout
```text
tenants/
  acme/
    tenant-state.json
```
The snapshot contains no inline secret values. `secret_references` point to Vault/Secret Manager/env locations.

## Worker trust boundary
The Control Plane creates a sync job containing a repo reference and a credential reference. A dedicated `gitops_worker` claims the job. The worker host/CI environment resolves credentials; the credential value is never returned by the Control Plane.

Recommended GitHub setup:
- private repository;
- protected `main` branch;
- dedicated deploy key or fine-grained machine credential with access only to that repository;
- required review for manual edits;
- immutable tags/releases for product artifacts;
- repository credential injected into the worker by a secret manager/CI environment.

## Recovery point
A recovery point is created only when:
- the tenant snapshot has been successfully synced to Git;
- every referenced backup has completed;
- hashes are known.

The recovery manifest records Git commit, snapshot hash, encrypted backup locations/hashes and deployment fingerprint.

## Restore principle
`GET /recovery-points/{id}/plan` returns a plan only. The Control Plane does not automatically run destructive restore/cutover operations.

Suggested sequence:
1. provision clean host;
2. restore exact Git commit;
3. restore encrypted backups;
4. resolve secret references from the secret manager;
5. deploy locked component versions;
6. pass health/runtime sync gates;
7. human approval for cutover.

## n8n
Workflows that are unique to a tenant should be registered as `n8n_workflow` GitOps objects before/with deployment. That JSON then becomes part of the tenant snapshot and can be rolled back/versioned in Git.
