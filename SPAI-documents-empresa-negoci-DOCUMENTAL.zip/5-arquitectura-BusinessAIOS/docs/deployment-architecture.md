# Phase 8 — Deployment & Update Architecture

## Goal

Deploy versioned Business OS components to many client tenants without giving the central AI agent SSH/root access to client infrastructure.

## Trust boundary

```text
Release/CI pipeline                 SolutionPartner Control Plane                 Client VPS
-------------------                 -----------------------------                 ----------
Ed25519 PRIVATE key                 Ed25519 PUBLIC key                            Ed25519 PUBLIC key
build artifact  ────> signed manifest ────> registry/approval/rollout ────> pull deployment job
                                                                                   |
                                                                                   v
                                                                          local allowlisted handler
                                                                                   |
                                                                                   v
                                                                          Docker/systemd/etc.
```

The private signing key must never be copied to a client VPS or stored in a deployment manifest.

## Release manifest

A release manifest binds a component/version to:

- immutable artifact URI;
- SHA-256 artifact digest;
- minimum Business OS version;
- allowed environments;
- component dependencies;
- metadata and signing key ID.

The Ed25519 signature covers a canonical JSON representation. Any change to version, artifact, digest, dependency or policy invalidates the signature.

## Deployment strategies

- `single`: all selected tenants are batch 0.
- `canary`: a deterministic subset is batch 0; remaining tenants are batch 1.
- `staged`: development, then staging, then production.
- `batch`: fixed-size batches.

Promotion is explicit. A batch can only be promoted when all deployments in the current batch completed and those tenants currently report `healthy`.

## Pull model

The Control Plane never SSHs into client servers. Each client runs `client_deploy_worker.py` on a timer/systemd unit. It authenticates using the tenant-specific client key, claims only its own approved job, verifies the signed manifest locally, and runs a locally configured handler.

The manifest cannot contain shell commands. The mapping from `component_type:component_name` to executable handler lives on the client VPS in `deployment-map.json`.

## Failure model

A deployment failure:

1. marks the deployment `failed`;
2. records an immutable deployment event;
3. marks the rollout target `failed`;
4. pauses the rollout;
5. prevents later batches from being claimed.

## Rollback

Rollback is a new deployment to the previous version. It requires:

- a previously completed deployment with `from_version`;
- an active signed manifest for that previous version;
- a fresh approval before execution.

This makes rollback auditable and prevents an operator/agent from installing an unsigned historical artifact.
