# Hermes / SP Supervisor — Contract Operations Policy

Hermes may reason about contract state but must not become a signer or trust-service provider.

## Allowed by default

- Read legal gate status and missing requirements.
- Read contract metadata, evidence verification and provider state.
- Explain which document blocks onboarding.
- Prepare a draft envelope/request for human review.
- Recommend operational remediation when a webhook/provider request fails.

## Approval-gated

- Registering a new legal template version.
- Sending a contract/signature request.
- Voiding/cancelling a pending signature request.
- Changing the required-document matrix for a customer/plan.
- Importing historical contract evidence.

These actions should use the Phase 14 Supervisor Action Gateway rather than direct database mutation.

## Never delegated to Hermes

- Signing/accepting a contract on behalf of a customer or SolutionPartner representative.
- Claiming that a person has authority to bind a legal entity without verified business process evidence.
- Altering a published template version or signed document.
- Fabricating provider evidence, timestamps, signatures or identity-verification results.
- Downgrading a signature level solely to make onboarding pass.

Production design target: Hermes sees **status and policy**, while regulated signing remains between the authorised human signer and the external trust/signature provider.
