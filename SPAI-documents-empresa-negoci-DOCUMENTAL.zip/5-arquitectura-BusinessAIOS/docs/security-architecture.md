# Phase 9 security architecture

## Trust boundaries

1. **SolutionPartner operator boundary** — humans, CI and SP Supervisor authenticate using scoped Service Accounts.
2. **Control Plane boundary** — deterministic API; no private release/break-glass keys; no ERP/CRM secrets.
3. **TLS edge boundary** — public ingress; tenant hostname requires a verified client certificate.
4. **Tenant boundary** — each Business OS has its own rotating client credential and private key.
5. **External systems boundary** — ERP/CRM secrets stay at the tenant runtime/secret backend.

## Machine identity

Tenant requests should require both factors in production:

- possession of a rotating application credential;
- possession of the private key matching an enrolled mTLS certificate.

Compromise of only one does not satisfy `key+mtls`.

## Administrator identity

Service Account tokens contain a public credential identifier plus a random secret. The secret is never stored; only a salted scrypt derivation is persisted.

Authorization is scope-based. The server obtains the actor from the authenticated Principal and does not trust actor names submitted in mutable JSON bodies.

## Secrets

`secret_refs` are inventory/policy metadata. A record may say where a secret exists and which component may use it, but cannot contain the value itself.

## Emergency access

Break-glass uses a separate offline Ed25519 trust root. The Control Plane has the public key only. Tokens are short-lived, reason-bound, limited-use and audited.
