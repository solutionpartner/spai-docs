# Trust Provider Adapter Contract

## Objective

Provider-specific network/API code is isolated from the Contract Lifecycle domain. Swapping provider must not change template hashes, legal requirements, evidence schema or onboarding policy.

## Required adapter operations

### create_signature_request(dispatch)
Input: `contract_id`, title, immutable artifact URI, document SHA-256, requested signature level, signers, callback URL.

Return at minimum: provider transaction ID, provider status, optional signing URLs or provider metadata. The adapter must then bind the provider transaction ID to the envelope.

### cancel_signature_request(provider_transaction_id)
Cancels/voids a pending request when supported. Provider callback remains authoritative for final state.

### fetch_evidence(provider_transaction_id)
Returns signed document reference, signed-document SHA-256 when available, evidence/certificate/audit reference and timestamps.

## Security requirements

- Credentials from Vault/secret refs only.
- TLS certificate validation enabled.
- Strict outbound allowlist to provider API domains.
- Idempotency key = SolutionPartner `contract_id` where provider supports it.
- Webhook authenticity must follow the provider's strongest supported mechanism (signature/HMAC/mTLS/JWS etc.).
- Validate provider event ID and transaction binding before state transition.
- Never trust webhook-supplied tenant/customer identity over the server-side envelope binding.
- Do not place access tokens, OTPs, private keys or full signature credentials in logs.

## Qualified-service rule

If a workflow is sold/described as a qualified trust service, the chosen provider **and the specific service** must have qualified status in the applicable Trusted List at the time required. A vendor being present in a list for one qualified service does not imply every service it sells is qualified.
