# Phase 11 — Agent & Skill Catalog architecture

The catalog adds a commercial/product layer above the existing Component Registry and signed Release Registry.

```text
SolutionPartner Control Plane
        |
        +-- Component Registry      low-level installed component identities
        +-- Release Registry        signed deployable artifacts
        +-- Package Catalog         customer-facing products/modules
        +-- Commercial Plans        entitlements by tenant
        +-- Activation Lifecycle    approval + deployment coordination
                |
                v
          Phase 8 Deployments
                |
                v
          Tenant Business OS
```

## Separation of concerns

- **Component Registry**: technical identity (`skill/business-pulse@1.1.0`).
- **Release Manifest**: signed artifact and compatibility envelope.
- **Catalog Package**: product identity, description, category and commercial/internal classification.
- **Package Version**: immutable version metadata, dependencies and mapping to a component/release.
- **Commercial Plan**: immutable plan version containing package entitlements.
- **Activation**: tenant-specific request to enable, suspend or deactivate a package.

The AI supervisor can propose catalog actions, but cannot bypass RBAC, plan entitlement, activation approval or deployment approval.
