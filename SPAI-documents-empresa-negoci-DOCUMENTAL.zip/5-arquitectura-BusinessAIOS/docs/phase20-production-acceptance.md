# Phase 20 Production Acceptance Test (PAT)

A tenant/customer may pass the legal milestone only when all applicable checks succeed.

- [ ] Counsel-approved templates registered with immutable version and SHA-256.
- [ ] Required document matrix configured for customer/plan/use case.
- [ ] Provider adapter creates request and binds transaction ID.
- [ ] Signer receives and completes provider flow.
- [ ] Invalid webhook authentication is rejected.
- [ ] Duplicate webhook is idempotent.
- [ ] Final status cannot be rewritten to another final state.
- [ ] Signed artifact/evidence references are captured.
- [ ] Event-chain and evidence-manifest verification returns valid.
- [ ] Legal Gate remains false if any required document is pending.
- [ ] Legal Gate is false when nothing is configured.
- [ ] Legal Gate becomes true only after all required documents are signed.
- [ ] Strict onboarding blocks on legal gate and opens only after READY.
- [ ] Audit users can read evidence but cannot send/modify contracts.
- [ ] Provider credentials/secrets do not appear in DB payloads/logs.
- [ ] Backup/restore retains contract/evidence integrity.
- [ ] Retention/legal-hold policy is approved and configured.
- [ ] Vendor/QTSP status and required trust service verified for production use.
