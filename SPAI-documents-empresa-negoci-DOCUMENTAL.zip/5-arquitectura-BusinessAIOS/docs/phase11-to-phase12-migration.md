# Migració Fase 11 -> Fase 12

La migració és additiva. `Database` crea tres taules noves sense modificar les taules de Catalog, Onboarding o Deployment:

- `tenant_runtime_policies`
- `runtime_desired_states`
- `runtime_sync_reports`

Després d'actualitzar el Control Plane:

1. mantén les activacions actuals;
2. defineix opcionalment una runtime policy per tenant;
3. afegeix `metadata.runtime` a **noves versions** de packages (les versions existents són immutables);
4. reconcilia cada tenant (`POST /runtime/tenants/{tenant}/reconcile`);
5. instal·la `runtime_sync_worker.py` al VPS client;
6. valida el primer `applied` al Control Plane.

Els packages antics sense `metadata.runtime` continuen al desired state com a packages actius, però no exposen routes ni tools fins que es publiqui una nova versió amb runtime metadata.
