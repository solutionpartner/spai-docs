# Runtime Orchestrator Policy

## Routes

Les rutes són intents exactes, per exemple `business.pulse`. Una mateixa intent no pot pertànyer a dos packages: la reconciliació falla davant ambigüitat.

## Tools

Cada tool pertany a un package actiu. Un package no pot invocar la tool d'un altre package només perquè el nom existeixi.

Modes:

- `read`: pot executar-se si el handler local està carregat.
- `write`: `approval_required` per defecte. L'Orchestrator retorna una proposta perquè la Fase 5 Approval Engine governi l'acció.

## Policies

La primera versió suporta:

- `default_effect=deny` — immutable;
- `write_actions=approval_required|deny`;
- `max_agent_hops` — límit preparat per orchestration multi-agent;
- `denied_packages`;
- `denied_tools`.

No es permet configurar `allow-all`.
