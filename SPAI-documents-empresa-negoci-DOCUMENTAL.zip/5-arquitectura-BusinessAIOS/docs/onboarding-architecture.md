# Fase 10 — Arquitectura d'onboarding

```text
SolutionPartner operator
        |
        v
Onboarding Template Registry
        |
        v
Preview / prerequisite checks
        |
        v
Onboarding request --(RBAC approval)--> provisioning
        |                                  |
        |                                  +--> Tenant + one-time machine credential
        |                                  +--> Secret references (no values)
        |                                  +--> Base component inventory
        |                                  +--> Initial signed deployments (pending approval)
        |                                  +--> Bootstrap metadata
        v
   waiting_client
        |
        +--> client VPS stores credential
        +--> client generates private key + CSR locally
        +--> certificate is enrolled by Security Admin
        +--> external secret values are populated in the tenant secret backend
        +--> deployment worker executes approved releases
        +--> agent reports healthy heartbeat
        |
        v
   readiness gate
        |
        v
      READY
```

## Límit de confiança

El Control Plane automatitza l'orquestració i l'inventari. No conté la CA privada, claus privades de client, valors de secrets ERP/CRM ni accés SSH/root als VPS.

## Idempotència

Els passos queden persistits a `onboarding_steps`. Si el procés s'interromp, `execute` pot reprendre els passos ja completats sense crear un segon tenant ni tornar a revelar una credencial antiga.

## Desplegaments inicials

Els manifests signats indicats a la plantilla generen deployments de Fase 8 en estat `pending_approval`. L'aprovació de l'onboarding no elimina l'aprovació de release/deployment: són dos controls independents.
