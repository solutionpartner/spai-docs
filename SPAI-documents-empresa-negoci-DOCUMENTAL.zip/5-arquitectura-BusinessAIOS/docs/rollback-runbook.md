# Rollback runbook

1. Identify the completed deployment that introduced the problematic version.
2. Confirm an active signed release manifest exists for its `from_version`.
3. Call `POST /deployments/{deployment_id}/rollback` with the requesting operator.
4. Review the generated deployment. It must be `pending_approval`.
5. A human/admin approves the rollback deployment.
6. The client worker claims and executes it through the same signed pull channel.
7. Confirm tenant health and component version after completion.

A rollback is deliberately not an emergency shell command. For infrastructure emergencies that require direct VPS access, use a separate break-glass operational process outside the AI/Control Plane path.
