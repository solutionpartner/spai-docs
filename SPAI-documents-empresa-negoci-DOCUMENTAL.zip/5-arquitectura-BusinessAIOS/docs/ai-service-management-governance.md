# Phase 21 - AI Service Management & ITIL-informed Governance

## Purpose
Phase 21 adds a service-management operating layer above the existing Business AI OS controls. It treats platform and tenant capabilities as managed services with explicit ownership, criticality, objectives, incidents, problems, changes, configuration, knowledge and continual improvement.

## Positioning
This implementation is **ITIL-informed**, not an accreditation, certification or claim of formal conformance. It deliberately uses generic service-management objects and does not reproduce proprietary ITIL guidance. Commercial copy should prefer "recognised IT service management best practices" unless SolutionPartner has an explicit licence/accreditation basis for stronger use of the ITIL mark.

## Core operating loop
Observe -> Event -> Incident -> Problem (when recurring/systemic) -> Governed Change -> Release/Deployment -> Verification -> Knowledge -> Continual Improvement.

## Two levels
1. **SolutionPartner Control Plane**: full fleet-level service governance.
2. **Tenant Business AI OS**: scoped service catalogue, service health, incidents, requests, approved changes, configuration and SLO visibility.

## AI governance extension
AI-specific governance is not treated as separate from service management. Model routing, provider dependencies, AI budgets, RAG policies, approvals, agent/runtime versions and usage evidence are configuration and control inputs to the managed service.

## Guardrails
- AI/Hermes can observe, correlate and propose; approval boundaries remain deterministic.
- Changes do not bypass signed releases, deployment approval, RBAC, tenant isolation or Action Gateway.
- Incident closure does not erase evidence.
- A recurring incident should be promoted to a problem record where systemic investigation is justified.
- Continual improvement items require a measurable target when feasible.
