# Phase 14 — Supervisor Authority & Action Gateway

## Goal

Let Hermes operate the SolutionPartner fleet without making the language model the security authority. The Control Plane owns the policy and execution adapters.

## Authority classes

| Level | Meaning | Hermes |
|---|---|---|
| READ | no mutation | uses existing read-only MCP tools |
| AUTO | bounded, pre-authorized low-risk change | may request and execute automatically |
| APPROVAL | material operational change | may request; separate human must approve; Hermes may execute after approval |
| FORBIDDEN | outside Supervisor authority | denied, including unknown actions |

## Current AUTO actions

- `observability.evaluate_fleet`
- `incident.acknowledge`

## Current APPROVAL actions

- `incident.resolve`
- `runtime.reconcile`
- `deployment.request` (creates a deployment which still retains its own deployment approval)
- `rollout.pause`
- `rollout.resume`

## Current FORBIDDEN actions

- `shell.exec`
- `ssh.root`
- `secret.read_value`
- `release.sign`
- `tenant.delete`
- `rbac.grant_owner`
- `break_glass.issue`

Unknown actions are also forbidden.

## Separation of duties

The Hermes service account should use role `supervisor_operator`. It has `supervisor.request`, `supervisor.auto`, and `supervisor.execute_approved`, but **not** `supervisor.approve`.

Only an owner/platform administrator can approve a pending action through the Control Plane. The stored payload is SHA-256 bound, approval expires, and execution re-validates integrity.

## Flow

`Hermes diagnose -> propose -> Control Plane policy -> AUTO execute OR pending approval -> human approve -> Hermes execute approved -> verify -> audit`
