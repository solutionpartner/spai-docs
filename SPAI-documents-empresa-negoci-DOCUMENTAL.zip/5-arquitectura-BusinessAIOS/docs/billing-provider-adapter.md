# Billing provider adapter contract

A provider adapter has exactly two jobs:
1. verify the provider's webhook signature/replay rules using a secret stored outside the Control Plane;
2. map the event to the normalized Phase 16 event contract.

Supported normalized event types:
- `subscription.activated`
- `payment.succeeded`
- `payment.failed`
- `subscription.suspended`
- `subscription.cancelled`

The adapter authenticates to `POST /billing/events/normalized` with a dedicated `billing_adapter` Bearer token. Event IDs are idempotency keys. Reuse of an event ID with different content is rejected.

The normalized payload must contain only billing state required by SolutionPartner (plan reference, subscription reference, period end, optional grace days). Do not forward card/payment-instrument data.
