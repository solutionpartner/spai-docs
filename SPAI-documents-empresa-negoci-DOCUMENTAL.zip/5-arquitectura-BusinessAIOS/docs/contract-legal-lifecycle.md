# Phase 20 — Contract & Legal Lifecycle

## Purpose

Phase 20 makes legal readiness a first-class Control Plane state. It does **not** turn SolutionPartner into a qualified trust service provider. SolutionPartner owns the client experience, document lifecycle, versioning, workflow, evidence registry and onboarding gate; a selected external trust/signature provider performs the regulated signature/trust operations appropriate to the requested signature level.

## Canonical flow

```text
CRM / proposal
   -> customer_ref
   -> legal requirements (MSA, DPA, AI Schedule, SLA, connector authorisation...)
   -> immutable template version
   -> rendered PDF + SHA-256
   -> contract envelope
   -> Trust Provider Gateway
   -> signer authentication/signature
   -> authenticated provider webhook
   -> signed artifact + provider evidence reference
   -> tamper-evident event chain
   -> immutable evidence manifest
   -> Legal Gate = READY
   -> billing / onboarding / tenant deployment
```

## Architectural boundary

**SolutionPartner does:** portal/UI, template/version lifecycle, hashes, routing, business approvals, HMAC-authenticated provider callbacks, storage references, audit/evidence manifest, legal requirements, onboarding gating.

**Trust provider does:** identity/signature operations, qualified or advanced trust functions as contracted, timestamps/certificates/evidence where applicable. Provider-specific secrets live in Vault/Secret Manager.

## Legal baseline for design (not legal advice)

- LSSI (Spain), Article 23: electronic contracts can have legal effect when consent and the other validity requirements are met; electronic form can satisfy a writing requirement, subject to specific exceptions/formalities.
- eIDAS Regulation, Article 25: an electronic signature cannot be denied legal effect solely because it is electronic or not qualified; a qualified electronic signature has the equivalent legal effect of a handwritten signature.
- eIDAS Article 26 defines requirements for advanced electronic signatures.
- Spain Law 6/2020 regulates certain aspects of trust services and distinguishes qualified/non-qualified trust-service regimes.
- Qualified status must be checked against the EU/national Trusted Lists for the **specific service**, not assumed from a vendor's marketing name.
- GDPR applies to signer/contact/evidence personal data; minimise the data captured and protect it according to risk.

Production counsel must decide the appropriate signature level and formalities per document/use case.

## Domain states

Template: `draft -> active -> deprecated -> retired` (version immutable once registered).

Envelope: `draft -> pending_signature -> signed | declined | expired | void`.

Legal requirement: `pending -> satisfied` based on a signed envelope of the required document type.

## Immutability

- A template version is never overwritten; publish version N+1.
- A contract stores the SHA-256 of the exact PDF sent for signature.
- Signature/provider events are appended into a chained hash log.
- When signed, the system creates one evidence manifest with its own SHA-256.
- The original provider evidence remains external/immutable; the Control Plane stores a reference and verifies its own evidence chain.

## Onboarding gate

`SP_REQUIRE_LEGAL_GATE=1` is required in production. `ready=false` if no requirements are configured or any required document remains unsigned. This is intentionally fail-closed.

## RBAC

- `legal_admin`: `contracts.*` plus read-only access to tenant/onboarding/security context.
- Platform/release administrators: full contract lifecycle as configured.
- Operators/auditors/viewers: `contracts.read` only.
- Trust-provider webhook: no human RBAC; HMAC-authenticated transport and idempotent provider event IDs.

## Production P0s before first real signature

1. Select provider and confirm its status/services in the EU Trusted List where qualified services are required.
2. Complete security/vendor/DPA/subprocessor review of the provider.
3. Implement and test provider adapter (create/cancel/fetch evidence).
4. Store provider credentials only in Vault/secret refs.
5. Finalise counsel-approved contract templates and signature-level matrix.
6. Use immutable/object storage with retention/hold policy for original and signed PDFs.
7. Verify webhook authentication method required by the chosen provider; HMAC is the reference implementation, not a substitute for provider-specific controls.
8. Define retention, deletion, legal hold and data-subject handling for evidence metadata.
9. Test signature cancellation, expiry, duplicate webhooks, provider outage and evidence retrieval.
10. Run the Phase 20 PAT before enabling `SP_REQUIRE_LEGAL_GATE=1` for production onboarding.

## Official legal references

- https://www.boe.es/buscar/act.php?id=BOE-A-2002-13758
- https://eur-lex.europa.eu/eli/reg/2014/910/
- https://www.boe.es/buscar/act.php?id=BOE-A-2020-14046
- https://eidas.ec.europa.eu/efda/trust-services/browse/eidas/tls
- https://eur-lex.europa.eu/eli/reg/2016/679/
