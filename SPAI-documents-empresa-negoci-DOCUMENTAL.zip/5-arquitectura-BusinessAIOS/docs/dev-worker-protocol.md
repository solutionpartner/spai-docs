# Dev worker protocol

Workers authenticate with a dedicated `dev_worker` service account.

1. Claim a job for one worker class:
   `POST /dev-factory/workers/claim?worker_class=testing`
2. The response contains a structured `input` object and an allowlisted `job_type`.
3. Run the appropriate adapter in an isolated workspace.
4. Submit structured output to `/complete` or `/fail`.
5. Never return secret values or raw credential material.

Worker classes: `architect`, `coding`, `automation`, `testing`, `security`, `packager`.

The worker implementation must map known `job_type` values to code. It must not evaluate a command string received from the Control Plane.

Test/security jobs return `{"passed": true|false, ...}`. Package jobs return:

```json
{
  "artifact_uri": "oci://registry.example/component:1.2.3",
  "artifact_digest": "<64 lowercase sha256 hex>",
  "manifest": {"...": "unsigned manifest draft"}
}
```

The factory rejects manifest signatures/private keys in package output. Signing is a later protected step.
