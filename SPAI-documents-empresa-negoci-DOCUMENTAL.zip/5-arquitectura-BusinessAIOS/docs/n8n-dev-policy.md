# n8n Dev Factory policy

n8n workflows are packageable artifacts, not ad-hoc tenant state.

Default static checks:
- JSON object with non-empty nodes array;
- every node has a unique name and a type;
- embedded secret-like fields are rejected;
- credentials must be references containing an `id`;
- `n8n-nodes-base.executeCommand` and `n8n-nodes-base.ssh` are forbidden in the default factory policy.

A production policy can add an organization-specific allowlist/denylist. Workflows that perform business writes should still route through tenant Approval Engine policy where applicable.
