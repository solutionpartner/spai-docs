# Break-glass runbook

Break-glass is for platform recovery when normal service-account access is unavailable.

1. Retrieve the offline break-glass private key under the organization's emergency procedure.
2. Issue a token with a named actor, explicit reason, <=15 minute lifetime and the minimum number of uses.
3. Use `X-SP-Break-Glass` only for required recovery calls.
4. Confirm `break_glass.use` events in the security audit.
5. Rotate/revoke the credentials that caused the emergency.
6. Conduct an incident review.

The break-glass private key must never be mounted into the running Control Plane.
