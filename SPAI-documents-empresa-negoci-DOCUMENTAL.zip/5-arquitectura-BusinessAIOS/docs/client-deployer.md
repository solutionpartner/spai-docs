# Client deployment worker

The client deployment worker is intentionally small and pull-based.

## Required environment

- `SP_CONTROL_PLANE_URL`
- `SP_TENANT_ID`
- `SP_CLIENT_KEY`
- `SP_RELEASE_PUBLIC_KEY_PATH`
- `SP_DEPLOYMENT_MAP`

Run one iteration with:

```bash
python scripts/client_deploy_worker.py --once
```

In production, invoke it from a systemd timer or similar scheduler every 30–60 seconds.

## Local handler contract

The local handler is invoked as:

```text
handler deploy <artifact_uri> <artifact_digest> <version>
```

The handler itself is installed and owned by SolutionPartner/client infrastructure administrators. It should:

1. verify/download the immutable artifact according to the local platform;
2. deploy only the mapped service/component;
3. run local health checks;
4. exit `0` on success and non-zero on failure.

The central Control Plane cannot choose the handler path and cannot send arbitrary command-line arguments beyond the signed release fields above.
