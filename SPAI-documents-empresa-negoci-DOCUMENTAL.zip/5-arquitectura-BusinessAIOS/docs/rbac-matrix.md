# RBAC matrix — Phase 14

The executable policy is `control_plane/rbac.py`; this document is explanatory.

| Capability | owner | platform_admin | operator | release_manager | security_admin | auditor | viewer | supervisor_operator |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Tenant read | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Tenant write | ✓ | ✓ |  |  |  |  |  |  |
| Observability read | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Direct incident actions | ✓ | ✓ | ✓ |  |  |  |  |  |
| Release/deployment write | ✓ | ✓ |  | ✓ |  |  |  |  |
| Deployment/rollout approval | ✓ | ✓ |  | ✓ |  |  |  |  |
| Security read | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |  | ✓ |
| Credential/certificate management | ✓ |  |  |  | ✓ |  |  |  |
| Secret reference management | ✓ | ✓ |  |  | ✓ |  |  |  |
| Supervisor action read/request | ✓ | ✓ | ✓ | ✓ |  |  |  | ✓ |
| Supervisor AUTO execution | ✓ | ✓ | ✓ |  |  |  |  | ✓ |
| Supervisor action approval | ✓ | ✓ |  |  |  |  |  |  |
| Execute already-approved Supervisor action | ✓ | ✓ | ✓ | ✓ |  |  |  | ✓ |

The dedicated Hermes credential should use **`supervisor_operator`**, not `owner` or `platform_admin`. The model can never approve its own request through that role.
