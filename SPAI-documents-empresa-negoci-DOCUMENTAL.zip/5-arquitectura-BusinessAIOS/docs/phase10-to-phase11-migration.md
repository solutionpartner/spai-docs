# Phase 10 -> Phase 11 migration

The migration is additive. Starting the Phase 11 Control Plane against a Phase 10 SQLite database creates the catalog, plan and activation tables without rewriting existing tenants, deployments, onboarding jobs, credentials or security events.

Recommended rollout:

1. back up the Phase 10 database;
2. deploy Phase 11 application code;
3. start once to create Phase 11 tables;
4. register packages corresponding to existing Component Registry entries;
5. register commercial plans;
6. assign plans to existing tenants;
7. optionally reconcile already-installed tenant components into catalog activations;
8. update onboarding templates to include `commercial_plan` for new customers.

Phase 11 does not automatically infer commercial entitlements from existing installed components. This is intentional: commercial state must be explicit and auditable.
