# Phase 14 -> Phase 15 migration

1. Back up the Control Plane database.
2. Deploy Phase 15 code with the same database path.
3. Startup runs `CREATE TABLE IF NOT EXISTS` for the new Dev Factory tables.
4. Existing tenants, catalog, runtime, security, deployments and Supervisor actions are preserved.
5. Create dedicated service accounts for developers and workers as needed.
6. Do not reuse the Hermes `supervisor_operator` credential as a worker credential.

New tables: `dev_change_requests`, `dev_builds`, `dev_build_jobs`, `dev_gate_results`.
