# Phase 19 -> Phase 20 Migration

Phase 20 is additive. The database creates five new tables through `PHASE20_SCHEMA`; existing Phase 6-19 tables are unchanged.

## Deployment order

1. Backup Control Plane DB and object-storage metadata.
2. Deploy Phase 20 code with `SP_REQUIRE_LEGAL_GATE=0`.
3. Run full regression tests and smoke APIs.
4. Select/configure Trust Provider Gateway and secret refs.
5. Register counsel-approved template versions.
6. Configure legal requirements for pilot customer(s).
7. Complete an end-to-end staging signature and verify evidence.
8. Enable `SP_REQUIRE_LEGAL_GATE=1` in production.
9. Confirm onboarding without configured/satisfied requirements fails closed.

No migration should retroactively mark historic customers READY. Historic contracts should be imported only with verified source documents/evidence and explicit migration tooling.
