# Phase 8 → Phase 9 migration

Phase 9 creates new tables automatically on first start and keeps the Phase 8 deployment schema.

Existing `client_key_hash` values remain readable only as a migration fallback. New tenants receive rotating `sp_client` credentials.

Recommended migration:

1. backup the SQLite DB;
2. deploy Phase 9 with `SP_ALLOW_LEGACY_ADMIN_KEY=1` and `SP_ALLOW_LEGACY_CLIENT_KEYS=1` temporarily enabled;
3. bootstrap owner/release/security service accounts;
4. update dashboards and automation to Bearer tokens;
5. rotate each tenant credential;
6. enroll mTLS certificates;
7. enable `key+mtls`;
8. disable legacy admin key;
9. remove legacy client key material after the migration window.

## Existing Docker volume ownership

Phase 9 runs the Control Plane as UID/GID `10001` instead of root. Before the first Phase 9 start, ensure an existing `/data` volume is writable by `10001:10001`. Perform this as a controlled one-time migration using your container/host volume tooling, then return to the non-root runtime. Back up the DB before changing ownership.
