# Generador: format exacte de sortida (genera-diagnostico.py)

## Estructura de la carpeta d'entrada
```
<carpeta>/
├── diagnostico-fase1.json        (resum: empresa, totales, procesos amb pasos/senales/huecos)
├── respuestas-unificadas.json    (còpia de les respostes originals)
├── bpmn/<CODI>-<slug>.bpmn       (un per procés)
├── sops/<CODI>-<slug>.md         (un per procés)
└── modelo/<CODI>-<slug>.json     (fitxes ficha-proceso/1 — CLAU per cobertura "completa")
```

## Fitxa ficha-proceso/1 (caminals)
`formato, codigo, area, nombre, id_formulario, organizacion, objetivo, propietario, disparador, frecuencia{veces,periodo,texto}, duracion, documentado, estado, carriles[{id,nombre,personas}], participantes[{id,nombre}], nodos[], flujos[{id,de,a}], mensajes[{id,de,a,nombre}], siguientes, huecos, fuente`

- `nodos`: inicio (tipo:inicio), tasques (tipo:tarea, subtipo: manual|usuario|envio|recepcion), decisions (tipo:decision, amb objecte decision{pregunta,si,no}), fin (tipo:fin). Cada node: id, nombre, carril (l1..lN per rol), opcional: herramientas[], tiempo_min, dolor.
- L'importador compta NOMÉS `tipo in ('tarea','subproceso')` com a activitats.

## BPMN generat
- Carrils per rol (`Carril_1..N`), la y de cada node segons el carril del seu rol.
- Decisions → `<bpmn:exclusiveGateway>` amb dues sortides (sí→seguent, no→fin).
- Externs → `<bpmn:participant>` + `<bpmn:messageFlow>` (enviar: cap a l'extern; rebre: de l'extern).
- Colors bioc: vermell `#b42318/#fde2e1` per a passos a mà; lila `#7c3aed/#ede9fe` per a decisions.
- Tipus de tasca: mano→manualTask, eina→userTask, enviar→sendTask, rebre→receiveTask.

## Traps d'equivalència (causen contradiccions si no es respecten)
1. Resum `pasos` ha de tenir el MATEIX nombre que nodes `tarea` de la fitxa (decisions EXCLOSES del resum).
2. Tasques del BPMN (match regex de l'importador) ha de ser igual als nodes `tarea` de la fitxa → els gateways no compten (el regex no inclou exclusiveGateway).
3. `nombre`, `frecuencia.veces/periodo`, `propietario` idèntics entre fitxa i resum (l'importador els compara).

## SOP generat (seccions)
Capçalera amb taula (Área/Empresa/Responsable/Versión/Estado/¿Estaba escrito?) → 1 Para qué sirve → 2 Alcance → 3 Disparador y frecuencia → 4 Quién interviene (taula rol→números de pas) → 5 Herramientas → 6 Procedimiento paso a pas (amb ⚠ dolors citats textualment, decisions amb SÍ/NO, externs).
