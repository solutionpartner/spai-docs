# Formulari web de diagnòstic: patró reutilitzable (diagnostic-processos v2)

Publicat a https://solutionpartner.github.io/diagnostic-processos/ (repo `solutionpartner/diagnostic-processos`, fitxer únic `index.html`). Aquest patró serveix per a QUALSEVOL formulari web de captura de l'agència (el següent client que necessiti un formulari): estil 1B, Web3Forms, taules dinàmiques.

## Components del patró (tots en un sol HTML, sense dependències)
- **Estil casa**: header degradat blau nit + daurat, barres de progrés sticky, targetes per secció, àrees A-E numerades (`.area-num`). Paleta: #0b1d32/#e7c47d/#14243a.
- **Enviamient**: Web3Forms (clau pública al JS) → contact@solutionpartner.ai. El JSON complet de respostes va dins el camp `datos` del FormData (subject = tipus + nom empresa). Així arriben dades ESTRUCTUREDES al correu, no text pla.
- **Autoguardat**: tots els inputs (estàtics i dinàmics) fan `saveLS()` a `localStorage` (clau amb versió, p. ex. `spai-diag-processos-v2`); `restaurar()` reconstrueix rols/eines/processos amb passos en carregar. Esborrar a l'enviar amb èxit.
- **Taules dinàmiques** (el cor): contenidor `#XDyn` + botons `dyn-add` que criden `addRol()/addTool()/addProc()`; cada fila té botó treure; els passos dins de cada procés són `addPaso(pasosList)` amb renumeració.
- **Datalists creuats**: rols de la secció B i eines de C alimenten `<datalist>` (id `dlRols`/`dlEines`) que els inputs de passos referencien amb `list=` → autocompletat coherent.
- **Camps condicionals per tipus de pas**: selector `tipo` que mostra/oculta camps amb `data-if="eina,enviar,..."` (eina→herramienta; enviar/rebre→externo; decidir→pregunta+SÍ/NO). Tag de color visible del tipus a cada pas (vermell=a mà, lila=decisió...).
- **Validació**: camps obligatoris marcats amb `.missing` (border vermell + hint), progrés = comptador d'obligatoris omplerts, missatges toast.

## Traps apresos
1. `renum()` després d'esborrar un pas (els números de pas han de seguir consecutius).
2. El JSON de sortida (`recollir()`) ha de coincidir EXACTAMENT amb el que espera el consumidor (generador/kit) — definir el format abans de programar el formulari, no després.
3. La mateixa clau pública Web3Forms per a tots els formularis de l'org funciona (és per destinaciari, no per formulari); es distingeixen per `subject`.
4. Un botó CTA a la web de venta (taronja #FF9900 estil Amazon) just sota la secció d'exemples de processos enllaça al formulari — el punt de conversió va DESPRÉS de mostrar exemples, no abans.
