# Traducció ES→CA d'un formulari JS gran (kit01) — tècnica, execució segura i pitfalls

Com es va portar el formulari del kit01 (127KB, en castellà) a català sense trencar el JS, i com evitar el pitfall que va deixar el fitxer a 0 bytes.

## Estratègia en dues capes
1. **A la FONT**: traduir directament les cadenes que són dades/etiquetes estàtiques del codi: `MARCA`, `AJUSTES`, el **catàleg de processos** (`CATALOGO.procesos` — noms, `alcance`, passos `que`/`pregunta`/`fin`...), les opcions `O.*` (format real: `['clau', 'valor']` AMB espai després de la coma!), i els textos llargs de `RENDER.*`.
2. **Overlay TreeWalker** (script afegit abans de `</body>`): un `const T = {ES:CA}` + `MutationObserver` sobre `#seccion` (childList+subtree+characterData) que tradueix les cadenes que el motor renderitza dinàmicament (títols dinàmics, botons generats). PATRÓ clau de la casa: mateix mecanisme que `business-ai-os` i els widgets dels dashboards.

## Com verificar un formulari multi-secció sense navegador interactiu
`--dump-dom` només captura la **secció inicial**. Per recollir el text de TOTES les seccions, un probe CDP que crida `window.CUESTIONARIO.ir(secció)` per a cada una i recull `label,.etiqueta` — però fer-ho com UNA sola `Runtime.evaluate` amb `(async()=>{...})()` millor que moltes round-trips (els probes per-secció propensos a penjar-se). La via més determinista: llegir el DOM d'un probe que SÍ va funcionar, i comprovar per regex que cap text ES residual quedi a la font o al dict.

## Pitfalls CRÍTICS
- **`re.subn` a Python retorna `(nou_string, comptador)`** — si l'assignació es fa invertida (`cnt, s = re.subn(...)` quan hauria de ser `s, cnt`), escrivint `s` (un int) buides el fitxer a 0 bytes. SEMPRE: llegir la font → transformar a una variable nova → escriure a un fitxer TEMP → validar (`node --check` de cada `<script>` + `wc -c` fitxer > 0) → només llavors `mv` sobre el destí. Tenir un commit git de la base per restaurar si passa res.
- **Apòstrofs catalans (l', d', s', n'...) dins de strings JS de cometes simples trenquen tot el script** (`'l''empresa'` → SyntaxError). Solució: usar **cometa tipogràfica** `’` (U+2019) — regex `([A-Za-zÀ-ÿ0-9])'([A-Za-zÀ-ÿ0-9])` → `\1’\2`. NO fa servir apòstrofs ASCII dins cadenes JS. Validar sempre amb `node --check`.
- El format real de les opcions `O.*` és `['clau', 'valor']` AMB espai (`'Vender más', 'Vender más'`), no `['clau','valor']` sense espai — els reemplaços per cadenes exactes fallen silenciosament si no coincideix l'espai.
- Moltes frases llargues viuen DINS d'etiquetes HTML (`<h3>...`, `<summary>...`, `title="..."`) o dins de concatenacions JS — cercar el text amb el context real del fitxer abans de reemplaçar, no la cadena sola.
- Les frases dinàmiques del motor (`conHuecos`, `BLOQUE_DATOS`) es construeixen per concatenació JS: traduir-les a la font, no esperar que les agafi l'overlay.

## Estat final del kit01 online
Commit `865dc32` a `solutionpartner/diagnostic-processos`: formulari complet en català, Web3Forms (clau `7bf49537-789a-492c-ab78-d14a79d0fe6e`, camp `datos`), dict overlay ~125+ claus. `genera-diagnostico.py` amb normalitzador de formats (vegeu SKILL.md).
