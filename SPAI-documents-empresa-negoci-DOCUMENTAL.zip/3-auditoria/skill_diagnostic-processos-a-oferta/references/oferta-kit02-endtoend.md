# Oferta kit02 end-to-end (provat amb la perruqueria de Mataró, 2026-10-26)

Flux complet per portar un client de la radiografia kit01 fins a l'oferta del kit02, verificat
de dalt a baix. Camins i estructures exactes que NO són obvis i que vaig haver de descobrir
per prova real (validarEsquema i validar.mjs són estrictes).

## Sequència completa (en ordre)

```bash
K=/opt/data/deliverables/kits
K2=$K/02-kit-oferta-soluciones
# 1. (opcional) adaptar el JSON BPMN propi a fitxes del kit — script reutilitzable:
/opt/data/.claude/audit-system/.venv/bin/python /opt/data/scripts/converteix-mataro-kit01.py \
  <json_bpmn_propi> "<client>/kit02-optimizacio/bpmn-radiografia"
# 2. dibuixar els diagrames REAL bpmn-js (NO Mermaid):
cd $K && node genera-diagramas.mjs "<client>/kit02-optimizacio/bpmn-radiografia"
# 3. radiografia HTML + PDF:
/opt/data/.claude/audit-system/.venv/bin/python genera-radiografia-v2.py <carpeta> --sortida <html>
PLAYWRIGHT_BROWSERS_PATH=/opt/data/tools/.pw-browsers /opt/data/tools/scrapling-env/bin/python \
  genera-radiografia-pdf.py <html> --sortida <pdf>
# 4. IMPORTAR al kit02 (crea workspace/clientes/<id>/):
cd $K2 && node herramientas/importar.mjs <carpeta> --cliente <id> --nombre "Empresa X"
#    esperar: "completa ×N" i "Contradicciones abiertas: 0". Els _svg es BLOQUEGEN i es
#    regeneren des del .bpmn; això és normal i correcte.
# 5. escriure model/areas.json · hallazgos.json · automatizaciones.json
#    (esquemes: esquemas/{areas,hallazgos,automatizaciones}.schema.json)
# 6. PAUSA OBLIGATÒRIA: mostrar la cartera a Josep; ell tria què entra (incluidas).
# 7. to-be/*.json + escandallo.json + oferta.json
# 8. validar → calcular → generar:
node herramientas/validar.mjs <id>      # esperar "✓ Análisis coherente" (43 avisos no blocs)
node herramientas/calcular.mjs <id>     # esperar "BORRADOR NO VINCULANTE" si tarifes buides
node herramientas/generar.mjs <id>      # fa comercial/*.pdf + interno/dossier*.pdf v1
```

## Estructures NO obvies (descúbertes per prova)

**hallazgos.json** — `evidencia[].fuente` ha de ser `SRC-###` del `procesos.json` →
`fuentes.ficha` (ex. `SRC-012`), MAI `SRC-VEN-01`. `cita` literal del camp (reescrit-la
llegint la fitxa, no teclejant-la). `categoria` dins la llista tancada. Cada dolor d'un
node → 1 hallazgo (referenciat `nodos:[<id>]` + `cita_ref:"CODI#<id>.dolor"`).

**to-be/<CODI>.json** — còpia de la fitxa as-is amb: `estado:"Propuesta pendiente de validación"`,
node problemàtic canviat a nom "després" + `propuesta:"AUT-XXX"` (i esborrar el `dolor`),
+ camp `cambios[]` amb `{tipo:"automatizado", nodo, antes, despues, automatizacion}` per cada
node canviat. L'esquema de `to-be` és la fitxa `ficha-proceso/1` (no té .schema.json propi).

**escandallo.json** — `{schema, estado:"estimacion_interna", aprobado_por:null, elementos:[{id,
horas:{consultoria,desarrollo,integracion,pruebas,documentacion,formacion,despliegue,estabilizacion},
externos_eur, contingencia_pct, justificacion_contingencia, notas}]}`. `horas` és un objecte lliure
(cap esquema intern). complexitat diferenciada per integració (TPV > agenda > CRM senzill).

**oferta.json** — `{schema, referencia, titulo, vigencia_dias, incluidas[], futuras[], base{modo,
precio_eur}, extras[], descuentos[], procesos_sin_to_be, resumen_ejecutivo{objetivos[],
propuesta_recomendada}, fases[], responsabilidades_cliente[], requisitos_cliente[],
limites_servicio[], siguientes_pasos[], meses_facturables_primer_ano, inicio_facturacion_texto,
ahorro_monetario}`. Els camps `base`, `resumen_ejecutivo`, `incluidas`, `futuras` són obligatoris.

**equipo / herramientas** del `diagnostico-fase1.json` → llistes d'OBJECTES (`{rol,personas}`,
`{nombre,categoria,uso}`), no strings; la radiografia els llegeix amb `.get()`.

## Regla de comptatge → contradiccions
L'importador compara `p1.pasos.length` (resum) vs nodes `tipo:"tarea"` vs tasques BPMN.
Les decisions (`tipo:"decidir"`) són gateways, NO tasques: exclou-les dels `pasos` del resum.
Cada procés ha de tenir un node `fin` (els que el motor trobava sense fin → "bucle sin salida").
Si el JSON BPMN propi no té pas fin als últims, l'adaptador n'afegeix un.

## Bloquejadors d'oferta "llesta per signar" (NO tocar, decisió d'SPAI)
- `config/tarifas.json` amb `precio_implantacion` i `cuota.base_mensual` a `null` → oferta
  BORRADOR, tots els imports "pendiente".
- `config/prestador.json` `razon_social`/`nif` a `null` → no es pot declarar "llesta per signar".
- Correcte deixar-ho com a borrador + dir-ho a Josep; MAI inventar números ni dades legals.

## Scripts reutilitzables (quedaran a /opt/data/scripts/)
- `converteix-mataro-kit01.py` — JSON BPMN propi → fitxes ficha-proceso/1 + diagnostico-fase1.json
- `gen_automatizaciones_mataro.py`, `gen_tobe_mataro.py`, `gen_escandallo_mataro.py`,
  `gen_oferta_mataro.py` — generadors d'anàlisi (valors d'exemple de la perruqueria; adaptar).
