# Brief d'Implementació Tècnica — Guía d'Us per a Claude

**Generat:** 26/10/2026  
**Font:** Oferta Global de Serveis (auditoria digital)  
**Destinatari:** Claude (AI developer) + Josep (planificador)

---

## Què és aquest document?

Aquest és un **document intern** que tradeix l'oferta de serveis (que veu el client) a instruccions tècniques (que veu el developer).

**Propòsit:**
- Especificar quines solucions tecnològiques crear
- Quin va ser el problema original (del client)
- Preguntes que Claude ha de fer per concretar
- Que Claude ha de cercar (documentació, referents)
- Com validar que cada solució funciona

---

## Estructura del Document

### 1. Resum Executiu
- Número de serveis
- Pressupost total
- Calendari estimat
- Dolors prioritaris a resoldre

### 2. Detall de cada Servei
Per a cada SVC-XXX (ex: SVC-DIG-02, SVC-BOT-01):
- **Problema que resol:** El dolor del client (ex: "Sense repartiment a domicili")
- **Solucions tècniques:** Quines tecnologies usar (ex: Next.js, Strapi, Calendly)
- **Preguntes per al client:** Que Claude ha de preguntar (ex: "Tenim contingut escrit?")
- **Que cercar:** Investigació a fer (ex: "Comparativa CMS 2026")
- **Criteris de validació:** Com validar que funciona (ex: "Lighthouse 85+")
- **Fases:** Breakdown per setmanes

### 3. Sequenciació del Projecte
- Fase 0: Anàlisi (1-2 setmanes)
- Fase 1-4: Desenvolupament (per categoria de servei)
- Fase 5: Testing i lliurament

### 4. Criteris de Recepció
Checklistos per a cada lliurable:
- Web: Lighthouse, SEO, mobile, formulari
- Bot WhatsApp: Latència, handoff, CRM integration
- Calendari: Sincronització, recordatoris, no-shows
- CRM: Dashboard, integracions, training

### 5. Riscos i Mitigacions
Taula de probabilitat × impacte + pla B

### 6. Preguntes Clau i Recursos
Contactes, documentació, enllaços

---

## Com Claude ha d'usar aquest document

### Pas 1: Primera lectura (1-2 hores)
```
1. Llegir Resum Executiu per entendre el context
2. Scroll a "Serveis a Desenvolupar"
3. Per a cada servei, llegir: Problema + Solucions tècniques
4. Revisar Sequenciació per veure dependencies
```

### Pas 2: Per a cada servei (3-5 dies per servei)
```
1. CERCAR (2-3 hores):
   - Buscar documentacio de tecnologies proposades
   - Buscar cases d'us del sector
   - Comparar alternatives (si hi ha vàries)
   
2. PREGUNTAR (1-2 hores):
   - Llegir "Preguntes per al client"
   - Enviar preguntes a Josep o client
   - Documentar respostes al brief
   
3. PROPOSAR (2-3 hores):
   - Proposar arquitectura especifica
   - Proposar stack de tecnologies
   - Proposar timeline revisat
   
4. IMPLEMENTAR + VALIDAR (1-2 setmanes per servei):
   - Crear repo, setup inicial
   - Implementar funcionalitats
   - Test vs. "Criteris de validació"
   - Documentar per al client
   - Marcar com "COMPLET" quan tots els criteris passen
```

### Pas 3: Actualitzar el Brief
```
- Afegir respuestas del client a cada servei
- Marcar decisions tècniques (ex: "Escollim Strapi perquè...")
- Revisar calendari (si s'atrasa, documenta per què)
- Marcar cambis de scope
```

---

## Exemples de Treball

### Exemple 1: SVC-DIG-02 (Web de 4-8 pàgines)

**Claude llegeix al brief:**
```
Solucions tècniques: Next.js / React, CMS (Strapi, Markdown, Webflow)
Preguntes per al client:
  - Quines pàgines són imprescindibles?
  - Tenim contingut escrit?
  - Cal gestionar un blog?
```

**Claude fa:**
1. Cercar: "Comparativa CMS 2026" → Strapi vs. Sanity vs. Payload
2. Preguntar: "Vols blog actualitzable? Integració amb Calendly?"
3. Proposar: "Next.js + Strapi + Calendly + Vercel per a hosting"
4. Implementar: Repo, pàgines template, formulari, SEO, deploy
5. Validar: Lighthouse 85+, mobile OK, formulari email OK, indexació Google

### Exemple 2: SVC-BOT-01 (Bot WhatsApp)

**Claude llegeix al brief:**
```
Solucions tècniques: Twilio WhatsApp API, LLM (OpenAI/Claude/local)
Preguntes per al client:
  - Quins tipus de preguntes ha de respondre?
  - Cal integrar amb CRM per a leads?
  - Budget: cloud LLM o model local?
```

**Claude fa:**
1. Cercar: "Twilio WhatsApp 2026", "LLM comparison per a bots"
2. Preguntar: "Quines preguntes freqüents? CRM: HubSpot, Salesforce?"
3. Proposar: "N8N (visual) + Twilio + Claude API + HubSpot"
4. Implementar: Flow de bot, training LLM, integracions CRM
5. Validar: Latència <3s, handoff OK, leads capturats, test amb usuaris

---

## Criteris de "Fet"

Cada servei es marca com a "COMPLET" quan:
- [ ] Tots els criteris de validació passen
- [ ] Documentacio pel client actualitzada
- [ ] Test amb usuaris reals (si aplica)
- [ ] No hi ha més tasques pendents
- [ ] Client aprovació (feedback)

---

## Si Claude queda bloquejat

1. **No sé per on començar:** Llegir "Resum executiu" + Sequenciació
2. **No sé quina tecnologia usar:** Llegir "Que cercar" + fer investigació
3. **No sé quines preguntes fer:** Llegir "Preguntes per al client" al servei
4. **No sé com validar:** Llegir "Criteris de validació" del servei
5. **Obstacle no resolt:** Documentar al brief + demanar a Josep

---

## Arxius relacionats

- **Oferta de serveis (PDF):** `oferta_global_[client].pdf` (veu del client)
- **Auditoria global (JSON):** `templates/[client].json` (dades crus)
- **Brief d'implementació (MD):** `brief_implementacio_[client].md` (instruccions per a Claude)
- **Documentacio tecnica generat:** Cada servei crea README, API docs, howto

---

## Calendari Total

**12-16 setmanes (3-4 mesos)**
- Setmana 1-2: Anàlisi i especificació
- Setmana 3-6: Presència digital (webs)
- Setmana 5-12: Bots i automatitzacions
- Setmana 10-14: CRM i SaaS
- Setmana 12-15: RAG i IA local
- Setmana 15-16: Testing i lliurament

---

**Generat automàticament des de l'oferta de serveis.**  
**Última actualització:** 26/10/2026  
**Responsable:** Claude (implementació) + Josep (planificació)
