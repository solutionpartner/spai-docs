---
name: generacio-oferta-comercial
description: "Use when generar ofertes comercials o canviar-ne el layout."
version: 1.0.0
author: Hermes Agent (curador)
license: MIT
metadata:
  hermes:
    tags: [oferta, kit02, layout, bpmn, pdf, html, mesures]
    related_skills: [multi-circuit-audit-pipeline, reporting-engine, diagnostic-processos-a-oferta]
---

# Generació i edició d'ofertes comercials (kit02 oferta-soluciones)

El kit genera els dos entregables d'un client: **oferta comercial** (`comercial/oferta-<cliente>-v<N>.{html,pdf}`) i **dossier intern** (`interno/dossier-interno-...`). Motor a `/opt/data/deliverables/kits/02-kit-oferta-soluciones/`. És feina recurrent: qualsevol client nou (estudi-aiguaviva, clínica, supermercat...) passa per aquí.

## Comanda de generació

```bash
cd /opt/data/deliverables/kits/02-kit-oferta-soluciones && node herramientas/generar.mjs <id-client>
```

- `id-client` = carpetes a `workspace/clientes/` (ex: `estudi-aiguaviva`). NO duplica la versió: **un document emès no se sobrescriu**, cada execució suma `v<N+1>`.
- Les versions surten com a **BORRADOR NO VINCULANTE** si les tarifes/dades jurídiques no estan aprovades (normal al kit local: `Borrador porque: Las tarifas no están aprobadas...`). És el comportament esperat, no un error.
- Després de generar, revisa les **pàgines del PDF** abans de donar-la per bona (`Falta: revisar las páginas...`).

## Layout per procés — el definitiu (triat per l'usuari, no canviar)

Cada `article.proceso` porta **diagrames a dalt (2 columnes) + text a sota**, tot a la mateixa pàgina quan el contingut hi cap:

1. **Dalt (`div.diagramas-fila`, grid 2 columnes)**: diagrama AS-IS (esq) i TO-BE/proposta (dreta) com a **`vista()` en miniatura** — `svg.vista` amb `max-height: 62mm` (CSS a `plantillas/oferta.html`). El peu ja diu que el detall es llegeix a l'annex.
2. **Sota (`div.proceso-cols`, grid 2 columnes)**: `col-izq` = **Problemas encontrados** (targetes compactes) + manuals; `col-dcha` = **Soluciones propuestas** (targetes compactes).
3. Problema i solució del mateix procés queden **sempre junts** a la mateixa pàgina (objectiu original de l'usuari: abans es partien entre pàgines).

L'usuari vol que el format sigui **llegible**: diagrames petits a dalt com a vista general (el detall va a les làmines de l'annex) i el text ample a sota. **No** tornar a posar els diagrames grans dins de la pàgina del procés: això era el que feia cada procés de 3-7 pàgines.

### Targetes compactes (ja aplicades al motor)

- **Problema** = títol + etiqueta + només `Como se resolvería` (classe `resol-linia`). *No* descripció llarga / consecuencia / dónde / cita (van al dossier).
- **Solució** = títol + descripció curta + `dl-2 slim` amb només `Para qué sirve` (beneficio) + `Inversión` (si inclosa). *No* cadena-flux, equipo, aprobación, fuera, aceptación, viabilidad, efecto cuota.

## Mesurar l'alçada per procés (pre/post qualsevol canvi de layout)

L'única manera objectiva de saber si un procés cap a una pàgina és **mesurar amb Playwright** (A4 ~ 182-190 mm útils; 1mm ≈ 3,78 CSS px):

```python
# /opt/data/measure_proc2.py (adaptar-html=fitxer vN) — PLAYWRIGHT_BROWSERS_PATH=/opt/data/tools/.pw-browsers /tmp/pilvenv/bin/python measure_proc2.py
# per cada article.proceso: getBoundingClientRect().height/3.78 → mm; i per blocs: .diagramas-fila, .proceso-cols
```

Valors de referència mesurats (client estudi-aiguaviva, motor original vs final):
- Original (tot vertical): VEN-01 569mm, FUL-01 1266mm, ADM-02 899mm — 3-7 pàgines per procés.
- Estructura final (diagrames dalt + text sota): diagrames 70-95mm dalt; text 206-277mm. Processos petits ≈ 1 full; els grans (5 problemes) es reparteixen en 2.

## Pitfalls d'edició del motor — CRÍTIC

`herramientas/oferta-html.mjs` és un sol template literal JS gegant amb sub-template literals niats (`${}`). **NO reescriure la funció amb índexs de línia via `execute_code`**: els desplaçaments d'índex causen errors silenciosos i corrupció (`Unexpected token '<'`, `</div></article>`;</article>`;`). Patró validat:

1. **Usar el tool `patch` amb anchors exactes i únics** (cadenes senceres, no línies).
2. Després de CADA canvi: `node --check herramientas/oferta-html.mjs` — l'import ESM (`import('./herramientas/oferta-html.mjs')`) també valida però és més lent.
3. El CSS NO és al mjs: viu a `plantillas/oferta.html` (ex. `.diagramas-fila`, `svg.vista max-height`). Els canvis de layout toquen DOS fitxers.
4. Si encara es fa substring-surgery amb Python: extreure per markers exactes (find d'anchors únics), concatenar en l'ordre nou, i **recomptar backticks parells** abans d'escriure.
5. L'escàner del kit bloqueja els **comentaris HTML `<!-- -->`** dins el template com a "terme tècnic" — no posar-ne de nous a les targetes.

## Altres

- Hi ha `herramientas/generar.mjs` (runner), `oferta-html.mjs` (layout comercial) i `dossier.mjs` (dossier intern). Els canvis de layout comercial van només a `oferta-html.mjs` + `plantillas/oferta.html`.
- Els clients utilitzen `tr('ES','CA','EN')` per idioma; fer servir els 3 paràmetres sempre en textos nous.
