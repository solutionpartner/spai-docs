# CLAUDE.md — Sistema d'Auditoria i Informes d'Empresa (replicable)

Aquest és un sistema **replicable** per generar informes complets d'empreses
(DAFO/SWOT, PESTLE, benchmarking, pla de millora) i vendre'ls com a consultoria.

**Principi clau:** no escriguis l'informe directament. Segueix el pipeline de
5 fases. Cada fase és un fitxer intermedi que pots inspeccionar abans de
continuar. Res no es lliura sense passar l'auto-auditoria (fase 4).

---

## Arquitectura del sistema (flux complet)

```
QÜESTIONARI (client)  →  FASE 0 CAPTURA  →  FASE 1 RECERCA  →  FASE 2 ANÀLISI  →  FASE 3 REDACCIÓ  →  FASE 4 AUTO-AUDITORIA  →  FASE 5 ENTREGA (PDF/Excel) + FASE 5b WEB
```

Cada fase escriu al seu fitxer. No saltes fases. Si una fase no té prou dades,
ho marques com a `TODO` i ho afegeixes a la llista de pendents — no t'inventis
dades com a fetes.

---

## FASE 0 — Captura d'entrada (abans de començar)

**Interfaces d'entrada acceptades:**
- Transcripció d'una trucada/entrevista (fitxer `.txt` o `.md`)
- Notes soltes del client (qualsevol text)
- URL de la web del client
- Dades numèriques (CSV, full de càlcul exportat a CSV)

**Prompt d'extracció** — passa-ho al model quan tinguis el text brut:

```text
Extraeix de l'entrada següent, de forma estructurada i sense inventar res:
1. EMPRESA: nom, sector, mida (empleats), ubicació, anys d'operació
2. QUÈ VENEN: productes/serveis principals (1 línia cadascun)
3. CLIENTS: qui són els seus clients ideals, quins problemes resolen
4. PROCESSOS: quines operacions/àrees tenen (ventes, suport, facturació, logística, producció, estocs, compres...). Per a CADA procés detectat, extrau per separat:
   - NOM del procés
   - FLUX PAS A PAS (els passos, encadenats: "1. rep comanda → 2. comprova existències → 3. ...")
   - QUÈ ES FA A MÀ / MANUAL (quins passos requereixen una persona escrivint, cridant, movent paper)
   - EINES USADES (quines serveixes fan servir en aquest procés)
   - VOLUM (freqüència: quantes vegades al dia/setmana es fa, si s'esmenta)
   - QUI HO FA (rol i quantes hores setmanals, si s'esmenta)
   - HORES que fa perdre (si s'esmenta "passo X hores fent")
5. PUNTS DE DOLOR: què els fa perdre temps o diners (textual del client)
6. EINES ACTUALS: quines eines/software fan servir globalment (si es mencionen)
7. MANUALS: quins passos encara fan a mà (resum global)
8. OBJECTIUS: què volen aconseguir (creixement, costos, temps...)
9. DADES NUMÈRIQUES: qualsevol xifra esmentada (ingressos, costos, temps, volum)
10. CHECKLIST DE PROCESSOS: marca amb SÍ/NO cada procés següent segons si l'empresa el té o n'ha parlat
    - Comandes / vendes / comandes de compra
    - Facturació i cobraments
    - Compres a proveïdors (PCR)
    - Producció / prestació del servei / elaboració
    - Gestió d'estocs / magatzem / inventari
    - Logística / entrega / enviament
    - Atenció al client / suport / reclamacions
    - Màrqueting / captures de leads / xarxes socials
    - Recursos humans / contractació (si escau)
    - Comptabilitat / tresoreria
    - Informes / reports periòdics / gestió de dades
    - Altres (especificar)
    Per a cadascun marcat SÍ, apunta el flux pas a pas i si es fa a mà (com al punt 4).

Formata la sortida com a llistes clares sota cada capçalera.
Si una dada no apareix, escriu "NO_PROVIDED" — no la dedueixis.
```

Desa el resultat a `input/[client]-extracted.md`.

---

## FASE 1 — Research (recerca de context)

Objectiu: entendre el sector i els competidors abans d'analitzar res.

1. Llegeix `input/[client]-extracted.md`.
2. Cerca informació del sector i competidors:
   - `web_search` amb el nom de l'empresa i el sector
   - `web_extract` de la web del client i 2-4 competidors
   - Skill `agent-reach` (si disponible) per fonts socials/públiques
3. Escriu `research/[client]-sector.md` amb:
   - Descripció del sector (tendències, mida, creixement)
   - Competidors principals (nom, què fan, com es diferencien)
   - Fonts consultades (URLs) — cada dada que entri a l'informe necessitarà cita
4. `TODO` qualsevol buit (p. ex. "mancar dades de preus del competidor X").

**Regla de dades:** separa SEMPRE "fet verificable" (amb font) de "judici
estratègic" (opinió). A l'informe final, marca la diferència.

---

## FASE 2 — Anàlisi (DAFO + PESTLE + benchmarking)

Objectiu: convertir la recerca en anàlisi estructurada.

1. Llegeix `research/[client]-sector.md` + `input/[client]-extracted.md`.
2. Genera:

**DAFO (4 quadrants):**
- **Fortaleses (S):** què fa l'empresa millor que els competidors (intern)
- **Debilitats (W):** què fa pitjor o què li falta (intern)
- **Oportunitats (O):** tendències externes que pot aprofitar
- **Amenaces (T):** riscos externs (competidors, regulació, mercat)

**PESTLE (6 dimensions, només si hi ha prou context):**
- Política, Econòmica, Social, Tecnològica, Legal, Ambiental

**Benchmarking (si tens dades numèriques):**
- Compara l'empresa amb 2-4 competidors en: preus, temps d'entrega, canals, presència digital, automatització

3. Escriu `analysis/[client]-analysis.md` amb les 3 seccions.
4. Cada punt DAFO ha de tenir: **afirmació + evidència** (d'on surt).

**Regla:** si el DAFO té menys de 3 punts per quadrant, fes més recerca o
marca-ho com "anàlisi preliminar" — no inflis amb punts genèrics.

---

## FASE 3 — Redacció (informe complet)

Objectiu: convertir l'anàlisi en un informe executable i professional.

1. Llegeix `analysis/[client]-analysis.md`.
2. Genera `reports/[client]-report.md` amb aquesta estructura:

```markdown
# Informe de Millora — [Nom empresa]
**Data:** [data] · **Preparat per:** [nom client] · **Per:** [el teu nom/agència]

## 1. Resum executiu (1 pàgina)
- Què ets bones, què et falta, 3 accions prioritàries

## 2. Anàlisi DAFO (taula 2x2 o 4 quadrants)

## 3. PESTLE (si escau)

## 4. Benchmarking (si escau, taula comparativa)

## 5. Pla de millora prioritzat
| Prioritat | Àrea | Problema | Acció proposada | Impacte | Esforç |
|-----------|------|----------|-----------------|---------|--------|

## 6. Automatitzacions recomanades (si apliquen)
- Quins processos poden automatitzar-se, amb quina eina, quin estalvi

## 7. KPIs de seguiment
- Mètriques concretes per mesurar la millora

## 8. Properes passes (llista numerada)
```

3. **Escriu en segona persona** ("la seva empresa", "vostè") i to professional.
4. **No utilitzis**:
   - Em-dash (—) — substituïu per ", " o ": "
   - Emojis als títols/body
   - Frases amb "not-X-but-Y", triades forçades, o clímax d'una línia
   - Paraules buides ("streamline", "optimize", "cutting-edge", "innovador")

**Eines opcionals per a qualitat:**
- Skill `humanizer` (si disponible): neteja els trets d'IA del text
- Skill `copywriting` (si disponible): millora la persuasió del resum executiu

---

## FASE 4 — Auto-auditoria (self-audit pass) — OBLIGATÒRIA

Abans d'entregar, revisa l'informe amb ulls crítics:

1. **Verificació de dades:**
   - Cada dada numèrica té font? Si no, marca-la "estimació" o treu-la.
   - Cada punt DAFO té evidència real? Si no, marca'l "judici".
   - Hi ha alguna dada inventada/redona? Corrigeix o elimina.

2. **Verificació de coherència:**
   - El resum executiu coincideix amb el pla de millora?
   - Les accions prioritàries apareixen desenvolupades a la secció 5?

3. **Neteja d'AI-tells:**
   - Cerca: em-dash (—), emojis, "not-X-but-Y", triades de 3, clímax d'una línia
   - Cerca paraules buides: "streamline, optimize, cutting-edge, innovative, leverage"
   - Reescriu qualsevol frase que soni "genèricament IA"

4. **Qualitat d'acció:**
   - Cada acció del pla té un "qui, què, quan" clar?
   - Els KPIs són mesurables (número + període)?

**Output:** `reports/[client]-report-audited.md` (versió final neta).
Escriu a `audit-log.md` què has corregit (1 línia per correcció).

**La regla absoluta:** l'informe NO es lliura mai sense passar aquesta fase.

---

## FASE 5 — Entrega (formats)

Genera els formats d'entrega segons el client:

1. **Markdown** (sempre): `reports/[client]-report-audited.md`
2. **Excel** (si hi ha benchmarking/KPIs): fitxer `.xlsx` amb:
   - Full "DAFO" (4 quadrants)
   - Full "Benchmark" (taula comparativa)
   - Full "Pla" (accions prioritzades amb impacte/esforç)
   - Full "KPIs" (mètriques de seguiment)
3. **PDF** (si ho demana el client): converteix el .md net a PDF

**Eines per a formats:**
- Excel/PDF: skill `pdf` (scripts `pdf_create.py`, `pdf_stamp.py`) i `xlsx`
- Pàgina de presentació: skill `docx` o `powerpoint` si cal

**Organització de fitxers:**
```
audit-system/
├── input/[client]-extracted.md
├── research/[client]-sector.md
├── analysis/[client]-analysis.md
├── reports/[client]-report.md
├── reports/[client]-report-audited.md   ← FINAL (aquest s'entrega)
├── deliverables/[client].xlsx
├── deliverables/[client].pdf
└── audit-log.md
```

---

## Pautes de vendes (recordatori)

- **Oferta d'entrada:** trucada de 45 min de mapeig de processos + informe en 24h
  a preu baix (~$500-999). Això genera confiança abans de vendre l'auditoria gran.
- **Projecte complet:** $3.000-7.000 (DAFO + benchmarking + PESTLE + pla + KPIs).
- **Retenció mensual:** $500-1.500/mes (dashboard KPIs + seguiment).
- **Primers clients:** 20 missatges/dia a LinkedIn a ops managers, CMOs i
  fundadors de 10-50 persones que fan servir "IA" però no tenen auditoria.

---

## Models recomanats (segons fase)

| Fase | Tasca | Model recomanat |
|------|-------|-----------------|
| Recerca | web_search, web_extract | qualsevol (no cal gaire raonament) |
| Anàlisi (DAFO) | raonament estructurat | model "reasoning"/gran (ex: claude-sonnet-4+, gpt-4o, deepseek-v4) |
| Redacció | escriptura + copy | model bo en llenguatge (claude-sonnet-4+) |
| Auto-auditoria | revisió crítica | model gran o diferent a l'escriptor (crida moment) |

**Consell de fluïdesa:** per a tasques de recerca/extracció (fases 0-1) un model
ràpid i barat va bé (estalvia tokens). Per anàlisi + redacció + auditoria
(fases 2-4) usa un model més capaç. No cal canviar-ho per a tot el pipeline;
canvia segons la fase si el teu entorn ho permet.
```

---

## Convencions tècniques

- Tots els fitxers en **clar** i **català** (o l'idioma del client).
- Noms de fitxer: `[client]-[tipus].ext` (sense espais, sense accents).
- Desa els fitxers intermedis SEMPRE (mai a memòria): el sistema és replicable
  perquè cada fase es pot reexecutar des del seu input.
- Si una fase falla o no té dades, escriu el fitxer igualment amb `TODO` i
  segueix — es poden emplenar després.