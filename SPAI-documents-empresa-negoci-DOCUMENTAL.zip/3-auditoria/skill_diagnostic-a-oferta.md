---
name: diagnostic-processos-a-oferta
description: Formulari web de diagnòstic a entrada del kit d'oferta.
---

# Diagnòstic de processos → Oferta (flux comercial SPAI)

Converteix les respostes del **formulari web de diagnòstic de processos** (https://solutionpartner.github.io/diagnostic-processos/, arriben per Web3Forms a contact@solutionpartner.ai com a JSON dins el camp `datos`) en la **carpeta d'entrada del kit 02 d'Oferta de Soluciones**, perquè "prepara la oferta de <client>" funcioni directament amb cobertura COMPLETA i 0 contradiccions.

## El flux complet
1. Client omple el formulari (Web3Forms → correu; el JSON va dins el camp `datos`). Revisar-lo manualment (regla de la casa: leads amb revisió de Josep).
2. Desar el JSON com a `respostes-<client>.json` i executar:
   `python3 /opt/data/deliverables/kits/genera-diagnostico.py <respostes.json> --sortida <carpeta-entrada>`
3. Copiar la carpeta a `entrada/<client>/` del kit 02 i demanar "prepara la oferta de <client>".

## Formats d'entrada acceptats (el normalitzador els unifica)
Des de gener del kit01 online, `genera-diagnostico.py` crida `normalitzar(d)` just després de carregar el JSON. Accepta els DOS formats:
- **`respuestas-unificadas/1`** (antic formulari web simplificat): `procesos` en llista plana, passos amb `tipo: mano/eina/enviar/rebre/decidir`.
- **`respuestas-diagnostico/1`** (el KIT01 complet, actual): processos **agrupats per àrea** a `areas.<area>.procesos`, passos amb `quien`/`con`/`comunicacion` com a **ids de rol/eina/extern** (no text), i decisions amb `opciones[]` en lloc de `si/no`. El normalitzador resol els ids → text (rols d'`equipo`, eines d'`herramientas`, externs d'`externos`), mapeja àrees (marketing/ventas/fulfillment/administracion → marketing/comercial/fabricacion/administracion), i converteix decision/espera/comunicacion als `tipo` del kit02. NO cal pre-normalitzar a mà.
- Simula el format del kit01 passant un JSON de mostra per `normalitzar()` o pel propi CLI abans de crear expedients al kit.

## El formulari online és ARA el kit01 complet (català)
`https://solutionpartner.github.io/diagnostic-processos/` serveix el **qüestionari sencer del kit01** (10 seccions: empresa, equip, eines, 4 àrees de processos amb **catàleg de 32 processos típics**, seguretat i IA) — NO la versió simplificada. Continua enviant per Web3Forms amb el camp `datos`. La traducció ES→CA es va fer a la **font** (catàleg, opcions O.*, etiquetes RENDER, MARCA/AJUSTES) + una **capa overlay TreeWalker** (script afegit abans de `</body>`) per a les cadenes que el motor renderitza dinàmicament. Si un futur canvi deixa text en castellà visible, amplia el diccionari de l'overlay (`const T = {...}`) o tradueix la font.

Treball de traducció ES→CA d'un formulari JS gran: tècnica, execució segura i pitfalls → `references/traduccio-es-ca-formulari.md`.

## Requisits del format d'entrada (descoberts per prova real — NO obvis)
- El kit 02 marca un procés "completa" NOMÉS si té **fitxa I BPMN**. Sense fitxa → "parcial (sin ficha de proceso (grafo completo))" i no rep solucions.
- Les **fitxes van a `modelo/<CODI>-<slug>.json`** (regex de l'importador: `modelo/[^/]+\.json$`), format `ficha-proceso/1` amb `nodos`/`flujos`/`mensajes`/`carriles`/`participantes`.
- **Regla de comptatge per evitar contradiccions**: l'importador compara `p1.pasos.length` (resum) vs nodes `tipo:"tarea"` de la fitxa vs tasques del BPMN. Les decisions (`tipo:"decidir"`) són gateways, NO tasques → **exclou-les dels `pasos` del resum** (consten a `senales.decisiones`) i usa `tipo:"decision"` a la fitxa. Si no, el kit obre contradiccions ("4 actividades vs 5 pasos") que bloquegen.
- Els codis d'àrea: ADM/VEN/FUL/MAR/GEN amb numeració per prefix; classificació automàtica per paraules clau del nom si el client no tria àrea.

## Passos amb tipus (el grau complet del kit 01)
Cada pas del formulari té: `tipo` (mano/eina/enviar/rebre/decidir), `rol` (autocompletat dels rols de la secció B), `herramienta` (autocompletat de C), `min`, `dolor`, i segons tipus: `externo` (qui participa de fora) o `decision` (pregunta + què passa amb SÍ i amb NO). Això permet generar BPMN amb carrils per rol, gateways exclusius i message flows d'externs — equivalent al que el kit 01 extreu amb entrevistes.

## Validació obligatòria abans d'importar
1. XML vàlid: `xml.dom.minidom.parse` de cada `.bpmn`.
2. JSON vàlid del `diagnostico-fase1.json`.
3. Importació de prova: `node herramientas/importar.mjs <carpeta> --client prova --nombre "X"` → esperar `✓ completa` a tots i `Contradicciones abiertas: 0`.
4. Netejar els expedients de prova del `workspace/clientes/` del kit després.

## PITFALL CRÍTIC: la radiografia BPMN es fa AMB EL KIT01, mai amb Mermaid/weasyprint
Quan Josep demana «el pdf dels processos bpmn amb les seves ineficiències» o «l'oferta resultat del kit02», la radiografia i els diagrames es generen EXCLUSIVAMENT amb el pipeline del kit (`/opt/data/deliverables/kits/`), NO dibuixant els fluxos a mà amb Mermaid ni weasyprint. L'he fet malament dues vegades i Josep ho va rebutjar: «Aixo esta fatal. No segueix el kit01, com els que es feien ahir». Els diagrames han de ser bpmn-js (pools, carrils, esdeveniments, tasques BPMN 2.0), no un flowchart de nodes.

Pipeline correcte (tot dins el kit):
1. **Fitxes** `ficha-proceso/1` → `modelo/<CODI>-<slug>.json` a la carpeta de diagnòstic del client (`kit02-optimizacio/bpmn-radiografia/`). Si les dades ja estan en un JSON BPMN propi, adaptar-les a aquest format (cada procés: area, codi ADM/VEN/FUL/MKT, carrils, participants, nodos amb `tipo/subtipo`, flujos, mensajes).
2. `node genera-diagramas.mjs <carpeta>` (a `/opt/data/deliverables/kits/`) → dibuixa amb bpmn-js els `.bpmn` + `.svg`. Usa el chromium_headless_shell de Playwright (ja configurat).
3. `/opt/data/.claude/audit-system/.venv/bin/python genera-radiografia-v2.py <carpeta> --sortida <radiografia.html>` → HTML amb els SVGs incrustats.
4. `PLAYWRIGHT_BROWSERS_PATH=/opt/data/tools/.pw-browsers && /opt/data/tools/scrapling-env/bin/python genera-radiografia-pdf.py <html> --sortida <pdf>` → PDF.

Guia del propi kit (formats, pitfalls, com fer-lo anar al servidor sense Edge/Chrome) → `references/analisis-oferta-kit02.md`. El `skill_view(name='diagnostic-processos-a-oferta', file_path='references/analisis-oferta-kit02.md')` té la secció «Fer funcionar el navegador del kit aquí».

## Números d'oferta: MAI fabricats (regla de Josep)
- El `genera_automatismes_ofertats.py` del catàleg pot estar **hardcoded amb un client anterior** (p. ex. la pizzeria: Pepperoni, direccions de NY, peu «CL-NYC-001», ROI 8997% fabricat). Abans de lliurar automatismes per a un sector nou, **comprovar que el contingut es deriva de les dades del JSON del client** (noms de processos, ineficiències), no d'un altre sector.
- **Economia basada en dades reals**: si el client factura X €/any, la recuperació potencial s'estima com un % conservador de X (p. ex. 3-6% per cites perdudes, no-shows, hores buides), no sumant «+175$/dia» arbitraris que acaben en ROI absurds. ROI inflat i beneficis diaris inventats = Josep ho rebutja. `beneficio_diario` fabricat fora.
- Número correcte: ROI 70-277% amb amortització 0,4-1,4 anys per a una perruqueria (vs 8997% fabricat).

## Formats descoberts de l'anàlisi d'oferta (validarEsquema estricte)
- `hallazgos.json`: `evidencia[].fuente` ha de ser `SRC-###` (numèric, del `procesos.json` → `fuentes.ficha`), NO `SRC-VEN-01`. La `cita` ha de ser LITERAL del camp de la fitxa; `cita_ref` = `CODI#node.campo`. `categoria` ha de ser un dels valors tancats (`transcripcion`, `datos_incompletos`, `duplicados`, `esperas`, `cambios_de_manos`, `trazabilidad`, `documentos_dispersos`, `notificaciones`, `conciliacion`, `seguimiento`, `errores`, `dependencia_persona`, `control_necesario`, `otro`) — un valor inventat bloqueja.
- `automatizaciones.json`: `prioridad` 1-5 (mai 0), `prioridad_explicacion` ≥10 caràcters, `analysis_status`/`viabilidad`/`madurez_analisis` valors tancats, `internal.escalera` amb els 5 graons (`simplificacion/configuracion/determinista/asistencia_ia/agente`). Cada automatizació té `client{title,benefit,description,team_keeps_doing,acceptance_criteria,data_journey}` + `internal{pattern,systems,escalera}` + `baseline` + `assumptions` + `source_refs`.
- `areas.json`: cada procés → `primary_business_area_id` (13 àrees: MKT/VEN/CLI/OPE/LOG/TEC/FAC/COB/COM/ADM/PER/DIR/IT) + `related_area_ids` + `justificacion`.
- `equipo` i `herramientas` del diagnòstic han de ser **llistes d'objectes** (`{rol,personas}`, `{nombre,categoria,uso}`), no strings — la radiografia els llegeix amb `.get()`.


## L'anàlisi d'oferta en si (areas/hallazgos/automatizaciones)
Després d'importar, l'agent escriu l'anàlisi que el kit valida: `areas.json` + `hallazgos.json` + `automatizaciones.json` a `workspace/clientes/<id>/modelo/`, mostra la **cartera** a Josep perquè triï què entra (pausa obligatòria), i els bloquejadors reals (`tarifas.json` / `prestador.json` buits → oferta BORRADOR amb preus "pendiente"). Mètode de 10 passos, validació per parts amb `validarEsquema`, errors d'esquema freqüents (cita literal, prioritat 1-5), i el pitfall del bot de trucades → `references/analisis-oferta-kit02.md`.

Detalls del generador (format fitxa, layout BPMN, SOP) a `references/generador-format.md` · patró reutilitzable del formulari web (Web3Forms, taules dinàmiques, autoguardat) a `references/formulari-web-patro.md`.

Flux kit01→kit02 complet amb estructures exactes (to-be, escandallo, oferta, validar/calcular/generar) i scripts reutilitzables → `references/oferta-kit02-endtoend.md`.
