# Guia operativa — Audita una empresa nova (pas a pas)

**Sistema:** `/opt/data/.claude/audit-system/` · **Skill:** `auditoria-empreses` · `bpmn-diagram`
**Sortides principals:** Informe PDF (Typst) + Info-WEB + Excel + Model d'impacte jugable (web)

---

## Visió del flux

```
1. CAPTURA   → 2. JSON       → 3. PROCESSOS   → 4. IMPACTE    → 5. GENERA    → 6. ENTREGA
qüestionari/    quest_to_json  checklist→BPMN    model jugable    gen_pdf_typst  PDF+WEB+Excel
entrevista      + judici anal.                    (web tailwind)   + gen_*        + model web
```

---

## PAS 1 — Captura i JSON del client

**Si el client ha omplert el qüestionari web (1A/1B, port :8171):**

```bash
cd /opt/data/.claude/audit-system
./.venv/bin/python quest_to_json.py "<nom o part del nom>"
```

- Llegeix `questionari-web/respostes-questionari.xlsx` i escriu `templates/<acronim>.json`.
- **Ara inclou el camp `processos`** derivat del checklist Sí/No (manuals primer).

**Si l'entrada és una entrevista/notes/web:**
1. Dóna el text brut al model (skill `auditoria-empreses`, prompt d'extracció de la Fase 0 del CLAUDE.md).
2. Escriu `input/<client>-extracted.md` → (opcional) `research/`, `analysis/`, `reports/`.
3. D'altra manera, crea el JSON a partir de la plantilla base `templates/informe_schema.json`.

> ⚠️ No t'inventis dades. Tot el que no és confirmat va marcat com "estimació".

## PAS 2 — Completa el judici analític

`quest_to_json` omple les dades **factuals**. Els camps que requereixen **judici** es
completen a mà al JSON abans de generar:
- `dafo` (fortaleses/debilitats/oportunitats/amenaces)
- `findings` (6 troballes amb prioritat P1-P4 i termini)
- `roadmap` (3 fases), `governanca`, `riscos`, `kpis_seguiment`
- `opcions` (beneficis/inversió), `competidors`

## PAS 3 — Processos (BPMN) — S'activa NOMÉS si el JSON porta `processos`

Els procesos surten a la secció **9 «Processos i oportunitats de millora»** del PDF.

- Al JSON: `"processos": ["facturacio", "comandes", "compres", "estocs", ...]`
- IDs vàlids (catàleg `processos_referencia.py`): `facturacio · compres · comandes · estocs ·
  atencio · marketing · informes · produccio · comptabilitat · logistica`
- Cada un pinta: **diagrama BPMN** (SVG propi, sense Chrome) + **punts vermells** (manuals) +
  **oportunitats d'automatització n8n/IA**.
- Si el JSON **no** porta `processos`, la secció simplement no surt (no falla res).

Per revisar un diagrama sol → `bpmn_svg.py` (`save_all()` pintarà tots els SVGs a `deliverables/bpmn/`).

## PAS 4 — Model d'impacte jugable (substitueix l'Excel)

La web (`deliverables/impacte/index.html?client=<nom>`) és el model que el client mou per veure el ROI.

1. Afegeix el model a `gen_impacto_web.py` → dict `MODELS` (inputs amb min/max/step, resultats amb fórmula, `inversio`).
2. Genera el JSON:
   ```bash
   ./.venv/bin/python gen_impacto_web.py
   ```
   → escriu `deliverables/impacte/<nom>.json`
3. Regles de fórmula: **sólo usen ids de inputs**; el script ho valida i si hi ha un id desconegut salta un error.
4. Paleta: **blau nit `#0B1D32` + daurat `#E7C47D`** (NO teal/verd — l'excel antic n'era teal i està fora de marca).

### ⚠️ VALIDACIÓ DE COHERÈNCIA (obligatòria, automàtica)

`gen_impacto_web.py` llegeix el camp `xifres` de l'auditoria del client
(`retorn`, `roi`, `inversio`) i **comprova automàticament** que el total per
defecte del model cau dins del rang documentat. Si no, avisa:

```
[COHERÈNCIA <client>] ⚠ AVÍS: retorn 90,560€ fora del documentat 12,000-20,000€; ROI 30.2x fora del documentat 4-6x
```

**Si veus l'AVÍS, NO lliuris el model.** Calibra els valors per defecte dels
inputs (a `MODELS` o al model genèric) fins que digui:

```
[COHERÈNCIA <client>] ✓ total 17,760€ / ROI 5.9x coherent amb l'auditoria
```

> **Per què és obligatori:** un client que obri el model i vegi un ROI de 30×
> quan l'informe que li has lliurat parla de x4-x6 trenca tota la credibilitat
> de l'auditoria. El model ha de **ser coherent amb l'informe**, mai contradir-lo.
>
> Nota: si el `xifres` del client no té `retorn`/`roi` documentats (models que
> no venen de cap auditoria concreta), la validació no s'aplica — però sempre
> és millor documentar el rang a l'auditoria per poder validar.

> La web renderitza amb Tailwind (CDN) i calcula en temps real. Per veure-la localment:
> `cd /opt/data/.claude/audit-system/deliverables/impacte && python3 -m http.server 8901`
> → obre `http://localhost:8901/?client=veterfarm`

## PAS 5 — Genera les sortides

```bash
# PDF professional (Tipst) — el principal, amb processos/BPMN si el JSON els porta
./.venv/bin/python -c "import sys,json,gen_pdf_typst as g; sys.path.insert(0,'.'); \
c=json.load(open('templates/<acronim>.json')); \
g.build(c,'deliverables/<acronim>-informe.pdf', data_str='DD/MM/AAAA')"
```

Per a la resta de formats (depèn del que vulguis lliurar):
- **Informe web** — `gen_informe2.py` / `audita.py --tot`
- **Excel dades + Excel impacte**: ara l'impacte és la **web** (`deliverables/impacte/`), no l'excel.
  Les dades brutes poden anar en un xlsx si cal (`gen_excel.py`).
- **Deck / Onepager / Gràfics** — `gen_deck_*.py`, `gen_onepager_*.py`, `gen_charts.py`.

Tots escriuen a `deliverables/`.

## PAS 6 — Auto-auditoria i entrega

1. Verifica el PDF: cada dada numèrica té origen? Els processos reflecteixen el checklist del client?
   Els tags de marca (blau nit/daurat) són correctes? Cap teal?
2. Envia (skill `client-deliverables`, `email-smtp-himalaya-v2`, o puja a GitHub Pages/Cloudflare Access).
3. Deixa l'actiu reutilitzable (principi `reusable-assets`).

---

## Resum dels fitxers clau

| Fitxer | Rol |
|---|---|
| `quest_to_json.py` | qüestionari → JSON (+ camp `processos`) |
| `templates/<acronim>.json` | dades del client + judici analític + `processos` |
| `processos_referencia.py` | catàleg de 10 processos (BPMN + punts + oportunitats) |
| `bpmn_svg.py` | Mermaid → SVG (render sense Chrome) |
| `gen_pdf_typst.py` | PDF professional (Tipst) amb secció processos |
| `gen_impacto_web.py` | models d'impacte jugable (JSON) |
| `deliverables/impacte/index.html` | web jugable (Tailwind, temps real) |

## Comprova que tens paleta correcta
- Blau nit `#0B1D32`, daurat `#E7C47D`, tinta `#14243A`, cream `#F7F4EC`.
- **Prohibit**: teal/verd als deliverables. Si veus `0F766E` o `CCFBF1` (del vell excel d'impacte), substitueix-lo per la web amb paleta correcta.