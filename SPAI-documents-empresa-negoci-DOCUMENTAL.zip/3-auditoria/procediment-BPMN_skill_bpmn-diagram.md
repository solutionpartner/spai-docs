---
name: bpmn-diagram
description: "Diagrames BPMN de processos amb Mermaid i paleta de marca."
metadata:
  hermes:
    tags: [bpmn, processos, mermaid, diagrama, auditoria, automatitzacio]
    related_skills: [auditoria-empreses, report-website-generation]
---

# BPMN Diagram — diagrames de processos de negoci (Mermaid)

Genera diagrames **BPMN** (Business Process Model and Notation) dels processos d'una
empresa auditada, per documentar com funcionen i on hi ha oportunitat de millora.
S'usa principalment com a secció dels informes d'auditoria d'aquesta agència.

Fa servir **Mermaid** (sintaxi `flowchart`) perquè és local, gratuït i no depèn de cap
API de tercers. Es pot renderitzar: en un HTML senzill amb el CDN de Mermaid, o com a
SVG/PNG via l'CLI de Mermaid (`mmdc`) si està instal·lat.

**Paleta de marca (obligatòria):** blau nit `#0B1D32`, daurat `#E7C47D`, tinta `#14243A`,
cream `#F7F4EC`. NO usar la paleta dark-cyan del skill `architecture-diagram`.

## When to Use

- Una auditoria ha d'incloure el(l)s processos del client amb diagrama.
- S'ha d'explicar visualment com funciona un procés i quins passos es fan a mà.
- Es volen marcar els punts **no automatitzats / ineficients** per proposar millores.
- S'ha d'extreure la captura de processos (formulari o entrevista) cap a un diagrama net.

## Com deduïr els processos (psicologia inversa)

Si no tens els processos descrits encara, extreu-los amb preguntes indirectes (el client
no sap descriure el seu procés, però sí respondre a això):

- Què et fa perdre més temps a la setmana? → procés amb més dolor/feina
- Què reps o repeats cada dia que sembla que mai s'acaba? → flux amb volum
- On comes errors o torres a repetir feina? → punts manuals / ineficients
- Qui ho fa i quantes hores setmanals? → cost i oportunitat d'automatitzar
- Quines eines serves i estan connectades? → on encaixa n8n/IA

Cada resposta revela un procés (o un pas d'un procés) sense preguntar mai «explica'm
el teu procés» directament.

## Sintaxi Mermaid (BPMN amb estil)

```mermaid
flowchart LR
  A["Inici: rep petició"] --> B["Entra les dades a mà"]
  B --> C{"Correcte?"}
  C -- sí --> D["Genera document"]
  C -- no --> E["Torna a repetir"]
  E -.-> B
  D --> F["Envia per email"]
  style B fill:#c0392b,color:#fff
  style E fill:#c0392b,color:#fff
```

- **Nodis normals:** `A["text"]` — fons neutre (blau nit pàl·lid o blanc).
- **Punts vermells (ineficients / manuals / a millorar):** `style X fill:#c0392b,color:#fff`.
- **Decisions:** `C{"text"}` — rombe.
- **Fletxes amb retorn (re-treball):** `E -.-> B` (línia discontínua) per remarcar bucles manuals.
- Per posar paleta de tema global a tot el diagrama:
  `%%{init:{'theme':'base','themeVariables':{'primaryColor':'#0B1D32','lineColor':'#E7C47D','textColor':'#14243A','primaryBorderColor':'#E7C47D'}}}%%`

## Renderitzar

### Opció 1 — HTML amb CDN (més fàcil, sense instal·lar res)

```html
<!DOCTYPE html><html><head><meta charset="utf-8"><script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
<script>mermaid.initialize({startOnLoad:true});</script></head><body>
<pre class="mermaid">
flowchart LR
  A["Inici"] --> B["Executa"]
</pre>
</body></html>
```

Obre l'HTML en un navegador; Mermaid renderitza el diagrama. Per posar-lo a un PDF
(com a l'auditoria), obre'l i captura la imatge, o usa l'CLI.

### Opció 2 — CLI `mmdc` (SVG/PNG per al PDF de l'auditoria)

El CLI de Mermaid (`@mermaid-js/mermaid-cli`) necessita **Chrome** per renderitzar.
A l'ordinador del client/server (on hi hagi Chrome o es pugui instal·lar):

```bash
npm install --no-save @mermaid-js/mermaid-cli
npx mmdc -i diagrama.mmd -o diagrama.svg -b white --size 1200
npx mmdc -i diagrama.mmd -o diagrama.png -b white -s 2
# si Chrome no està al PATH, apunta'l:
export PUPPETEER_EXECUTABLE_PATH="/cami/al/chrome"
```

> ⚠️ En un contenidor SENSE Chrome (com el servidor d'aquesta agència), `mmdc` FALLA.
> Llavors usa l'Opció 1 (HTML + CDN) i renderitza des del navegador de l'usuari, o
> genera el SVG a l'ordinador del client on sí que hi ha Chrome/navegador.

## Procedure per a una auditoria

1. **Recull processos** (formulari o entrevista — psicologia inversa).
2. **Selecciona els processos més rellevants** (els de més dolor/volum primer).
3. **Per a cada procés**, descriu el flux pas a pas en Mermaid i marca en vermell:
   - passes manuals / que s'escriuen a mà
   - passes amb retreballs o errors
   - passes que depenen d'una persona
   (aquests són els candidats a automatitzar)
4. **Rendering** (HTML/CDN per revisió, CLI per al PDF).
5. Al report d'auditoria, posa cada diagrama sota la seva secció de processos,
   amb una llista dels punts vermells i què es pot automatitzar amb n8n/IA.

## Pitfalls

- **Paleta**: NO usar dark-cyan de `architecture-diagram`. Sempre blau nit + daurat.
- **Mermaid v9 vs v10** canvien lleugerament `%%{init}%%`; provar la sintaxi abans de lliurar.
- **CDN al PDF**: en obrir l'HTML necessites connexió per renderitzar; per a entrega final
  sense depència d'internet, fes servir `mmdc` per generar SVG/PNG i inclou-los.
- **Nodis vermells**: no sobrecarreguis; vermell = acció de millora clara. Si tot el procés
  és vermell, el diagrama no comunica — agrupa els punts.
- **No documentis processos inventats**: dedueix només del que ha dit el client; si un
  procés no està confirmat, indica-ho.

## Verification

- [ ] El diagrama es renderitza sense errors (Mermaid no marca error de sintaxi).
- [ ] S'usa la paleta de marca (blau nit #0B1D32 / daurat #E7C47D).
- [ ] Punts a millorar en vermell, amb una llista al costat del diagrama.
- [ ] Els processos reflecteixen el que ha dit el client (res inventat).
- [ ] El diagrama es pot posar al PDF de l'auditoria (SVG/PNG generat).
