# Kit 02 · Generació de l'oferta per a un client NOU (recepta completa, provat 25/10/2026 amb el supermercat CL-0009)

Flux complet quan NO existeix encara el diagnòstic de processos del client però en tenim l'auditoria global (JSON de l'audit-system), i l'usuari demana "l'anàlisi BPMN + l'oferta d'automatitzacions". Tot executat de debò, no simulat.

## Ordre de generació (cada pas genera el següent)

```bash
# 1. JSON del formulari de processos (format respuestas-diagnostico/1, el que emet el web)
#    — construeix-lo a mà DES de l'auditoria del client (dolors/findings/àrees reals).
#    — passos amb `min: <nombre>` NUMÈRIC (mai `tiempo: "20min"` string → 0 h/mes, veure SKILL).
#    — 6-8 processos per àrees (marketing/ventas/fulfillment/administracion), cada pas amb
#      tipo (mano/eina/comunicacion/decision), quien (id de `equipo`), con (ids d'`herramientas`),
#      tiempo_comunicacion amb sentido envia/recibe + con extern (`externos`).
cp respostes.json /opt/data/cache/prova_client_respostes.json

# 2. Genera client + BPMN amb el motor
cd /opt/data/deliverables/kits
python3 clients-bd.py nou <respostes.json>   # → CL-XXXX + diagnostic/ + bpmn/ + svg/ + modelo/
# Espera: "8 processos · 27 passos · 25 automatitzables · N h/mes automatitzables" (N>0!)

# 3. Importa al kit 02
cd 02-kit-oferta-soluciones
mkdir -p entrada/<client>
cp -r /opt/data/deliverables/kits/clients/CL-XXXX-*/diagnostic/* entrada/<client>/
node herramientas/importar.mjs entrada/<client> --cliente <id> --nombre "..."
# Espera: "N processos ✓ completa · Pendientes: 0 · Contradicciones abiertas: 0"
# Els svg/*.svg es bloquegen per DOCTYPE (normal, es redibuixen) — no és un error.

# 4. Genera l'anàlisi (els 6 fitxers que importar NO crea): script Python propi, veure avall.
# 5. node herramientas/validar.mjs <id>   → 0 errors ✗ (els avisos ! d'estil no bloquejen).
# 6. node herramientas/calcular.mjs <id>   → tot "pendiente" sense tarifes (correcte).
# 7. node herramientas/genera-implementacion.mjs <id>   (PRIMER: `generar.mjs` no regenera implementacion.json)
# 8. node herramientas/generar.mjs <id>   → oferta v1 (BORRADOR NO VINCULANT) + dossier.
# 9. Verifica el PDF amb PyMuPDF abans de donar-lo per bo (veure verificació avall).
```

## El generador d'anàlisi (patró; els 6 fitxers els fa l'analista, no l'importador)

`generar.mjs` NO crea areas/hallazgos/automatizaciones/to-be/escandallo/oferta. Model de dades:
- **1 hallazgo = 1 node amb `dolor`** a la fitxa AS IS (llegir el `dolor` de `modelo/fichas-as-is/<PROC>.json`, NO del formulari — cites literals).
- **1 AUT = 1 capacitat** que resol els dolors d'un procés (pot ser 1 AUT per procés, o 2+ si els dolors són independents).

Campos OBLIGATORIS de cada fitxer (errors reals trobats a la validació del supermercat):

### automatizaciones.json
- Top-level per AUT: `id` (AUT-XXX-01), `process_ids`, `finding_ids`, `analysis_status:candidata`, `viabilidad:viable_por_verificar`, `madurez_analisis:analizada`, `prioridad` (1-5), `prioridad_explicacion` (>=10 chars), `fase`, `depende_de`, `client` (title/benefit/description/team_keeps_doing/out_of_scope/human_approval/acceptance_criteria/data_journey), `internal`, `baseline` (estado:pendiente + casos_mes/actividades/futuro), `assumptions`, `source_refs`, i recomanat `implementation_price_eur:null`, `price_source:'escandallo'`, `cuenta_en_cuota:true`.
- `internal` REQUEREIX: `pattern` (enum VÀLID: organizativo, configuracion_software, determinista, workflow_ia, rag_documental, agente, integracion_api, importacion_supervisada, rpa — **NO hi ha "asistencia_ia"**), `escalera` (objecte amb simplificacion/configuracion/determinista/asistencia_ia/agente), `autonomy` ('prepara_borrador'), `ai_fallback`, `systems` (llista), `dependencias`, i opcionals `candidate_orchestrator:null`, `mcp_required:false`, `risks`.

### hallazgos.json
- `evidencia[].fuente` HA de ser `^SRC-[0-9]{3}$` (SRC-001, SRC-002... progressiu per procés — **no** "SRC-0FUL-02").
- `categoria` dins l'enum: transcripcion, datos_incompletos, duplicados, esperas, cambios_de_manos, trazabilidad, documentos_dispersos, notificaciones, conciliacion, seguimiento, errores, dependencia_persona, control_necesario, otro (no "proceso_manual").
- `cita` = el `dolor` LITERAL de la fitxa AS IS; `cita_ref` = "PROC#node.dolor".

### areas.json
- REQUEREIX clau `pendientes: []` (a més de `schema:'areas/1'` + `procesos[]` amb codigo/primary_business_area_id/related_area_ids/justificacion/estado:'confirmada'/pregunta:null).

### to-be/<PROC>.json
- `estado` HA de ser EXACTAMENT `"Propuesta pendiente de validación"` (no heretar el de l'AS IS).
- Cada node millorat porta **`propuesta: "AUT-XXX-01"` DINS del node** (com la clínica). Si la propuesta va en un camp superior (ex. `propuesta_aut`), el validador avisa "ningún paso está marcado como propuesta" i l'oferta no pinta els canvis en blau. Esborrar el camp superior.
- `cambios[]` amb antes != despues per node (descripcions curtes: nom TO BE < 50 chars).

## Verificació del PDF de l'oferta — FALS NEGATIU per línies primes (clau!)

Els BPMN del kit es dibuixen amb línies d'1,5px. Rendering amb `pypdfium2` a escala baixa (0.3-1.5) amb llindar `<235`/`<220` marca les làmines de procés com a "0,0% tinta al centre" — **FALS NEGATIU**: el diagrama hi és, però les línies primes no arriben al llindar a baixa escala. No confiar-hi per decidir que el PDF està buit.

Mètode fiable (el que diu la skill): **PyMuPDF `get_drawings()` per pàgina** — cada làmina AS IS/TO BE ha de tenir desenes de dibuixos vectorials:

```python
import pymupdf
doc = pymupdf.open(pdf)
for i, pg in enumerate(doc):
    if "Cómo se trabaja hoy" in pg.get_text() or "Propuesta" in pg.get_text():
        n = len(pg.get_drawings())
        print(f"p{i+1}: {n} dibuixos")  # esperat: 20-47+ per làmina, no 0
```

Instal·lació (els venvs no tenen pip; usar uv amb python absolut):
```bash
uv pip install --python /opt/data/.claude/audit-system/.venv/bin/python pymupdf
```
Alternativa sense instal·lar res: pypdfium2 render a **scale=4.0** amb llindar `<245` mesurant la REGIÓ central (30-75% alçada) — línies primes SÍ apareixen (0.5-0.7% tinta, centenars de columnes amb traça) però la lectura és més ambigua que get_drawings().

## Sortida esperada de generar.mjs (característiques per disseny, no errors)

- `BORRADOR NO VINCULANTE` amb motius explícits: tarifes no aprovades (config/tarifas.json), dades fiscals buides (config/prestador.json), perfil jurídic no aprovat, condicions pendents, importes estimats. És el comportament correcte del kit (no inventa preus); Josep ha de validar la cartera i aprovar tarifes perquè surtin números.
- `calcular.mjs` → "total pendiente" / "sin coste/hora configurado" — esperat fins que tarifas.json tingui costos per rol.
- La ruta real dels PDFs és `workspace/clientes/<id>/comercial/oferta-<id>-v1.pdf` i `interno/dossier-...` (NO a l'arrel del kit).

## Lliçons d'operació

- **La cartera la valida Josep sempre** (quines AUT entren a `incluidas` i quines a `futuras`): el kit ho deixa a `oferta.json.incluidas` i el protocol diu "mostrar cartera i preguntar". No escollir per ell.
- `clients-bd.py nou` amb un JSON corregit: no hi ha "regenera" — esborrar el CL de la BD (`DELETE FROM clients/diagnostics WHERE id LIKE '%XXXX%'`) + `rm -rf clients/CL-XXXX-*/` i tornar a executar `nou`.
- El generador d'anàlisi (patró d'aquesta sessió) viu a `02-kit-oferta-soluciones/genera-diagnostic-oferta.py` — UN script consolidat que fa TOTS els passos d'anàlisi per a qualsevol client: el PAS 1 adapta el JSON BPMN a fitxes `ficha-proceso/1` + `diagnostico-fase1.json` (per a `genera-diagramas.mjs`/radiografia), i els PAS 2-5 generen `hallazgos.json` (1 per dolor, cita literal de la fitxa as-is), `areas.json`, `automatizaciones.json`, `to-be/*.json` i `escandallo.json`+`oferta.json` TOT dins del `modelo/` del client del kit02. El config per client viu a `02-kit-oferta-soluciones/configs-clientes/<id>.json` i conté TOTA la part intel·lectual específica (`automatizations` o `automatitzaciones` — accepta ambdues claus — amb title/benefit/desc/team/procs/prio/fase/pattern/systems/incluida, `area_negoci` amb primary/related/just per àrea de negoci del kit02, `aut_per_proces` + `despres_per_node` per al to-be, `escandallo` amb hores per AUT, `oferta` amb incluidas/fases/resumen). El config es crea una vegada per client (els contiguts AUT són judici de consultor); els passos 2-5 són mecànics i reexecutables (idempotents des de les fitxes as-is). Ús: `python3 genera-diagnostic-oferta.py --client <id> --bpmn <json> --config configs-clientes/<id>.json [--kit01-dir <dir>]`. **NO reescriure scripts _mataro.py per client**: el flux és genera-diagnostic-oferta.py + config del client. El cas Mataró (CL-MAT-001) és el primer exemple complet (27 dolors → 5 AUT, config a `configs-clientes/cl-mat-001.json`) i la Forneria del Barri de prova (`cl-prova-forneria.json`) el segon patró.
  **GOTCHAS APRESOS PROVANT EL CIRCUIT AMB UN CLIENT ALIÈ (26/10)** (prova real de cap a cap amb una fleca de 3 processos, corregits al generador):
  1. **Ordre correcte per a un client NOU**: PAS 1 amb `--kit01-dir <dir>` → `importar.mjs <dir> --cliente <id>` → PAS 2-5 SENSE `--kit01-dir`. Així l'expedient del kit02 neix de l'importador (estructura completa), no de l'auto-import del generador.
  2. **`areas.json` faltava** — ara el PAS 3 el genera des de `area_negoci` del config (13 àrees del kit02: MKT/VEN/CLI/OPE/LOG/TEC/FAC/COB/COM/ADM/PER/DIR/IT). Abans es feia a mà.
  3. **Clau del config**: l'script llegeix `automatizaciones` o `automatitzaciones` (accepta les dues; un config escrit en català no ha de fallar en buit). Verificar que el config té `automatitzaciones` i NO `automatizaciones` com a nom de clau al seu JSON.
  4. **Pas 4 requereix neteja dels to-be antics** — esborra el directori `to-be/` abans de regenerar (si un procés surt del config, el seu to-be vell quedava referenciant una AUT que ja no existeix → validar cridava «TO BE ... cita AUT-XXX, que no existe»). Ara `shutil.rmtree` abans de reescriure.
  5. **Els codis de procés del kit01 han de coincidir amb els del config**: si l'`area_de` del config genera VEN-02 però les AUT apunten a ADM-01, `validar.mjs` crida «AUT apunta al proceso X, que no existe». El config i l'`area_de` s'han de revisar junts perquè la numeració de processos sigui coherent (la prova va fallar 2 cops fins a alinear-los).
  6. **Un circuit de prova NET requereix esborrar l'expedient anterior** del kit02 (`rm -rf workspace/clientes/<id>`) i la carpeta kit01 abans de reimportar, si s'ha provat amb un altre config. Els fitxers vells no es sobreescriuen sols.
