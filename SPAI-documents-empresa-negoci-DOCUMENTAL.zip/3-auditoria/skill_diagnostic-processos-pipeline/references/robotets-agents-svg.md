# Dibuixar esquemes d'agents amb robotets simpàtics (SVG)

Quan un diagrama ha de representar AGENTS (Business AI OS: CEO AI + agents especialitzats), Josep vol dibuixets de robotets **simpàtics i professionals** — no cercle blau amb text. Funcions `robotet()` i `robotetCentrat()` a `02-kit-oferta-soluciones/herramientas/robot.mjs`.

## PITFALL crítica (corregit 13/10): els ulls han de ser GRANS i expressius a escala d'impressió

El disseny ANTIGU era geomètric mínim (cap blanc 34×27, ulls radi ~3px a escala 1). Al renderitzar dins l'oferta/dossier a mida d'impressió, **els ulls desapareixien** — Josep: "no semblen robotets (no se'ls veuen els ulls)". Mai redibuixar-lo petit i minimalista: a la mida final del PDF (agents a escala ~1.05, CEO ~1.7) qualsevol detall que no sigui robust es perd.

El disseny NOU (46×52, vectorial, marca blau nit+daurat) té ULLS GRANS i expressius: escleròtica blanca r=5.4 amb contorn accent + iris daurat + pupil·la accent + punt de brillantor blanc. A més: antena amb bola lluminosa (color + punt blanc), gloss al cap, cos tecnològic amb pantalla de leds, braços laterals (bales del color fosc), orelles, ombra de terra.

Firmes:
```js
export function robotetCentrat(cx, cy, opts = {})   // centres a (cx,cy); útil pels agents de columnes
export function robotet(x, y, { color = '#E7C47D', s = 1, accent = '#0B1D32' } = {})
```

Implementació: escala base 46×52; totes les coordenades es multipliquen per `s` (helpers locals `P/k/m` i `R/C/L`). Colors: `color` = cos/iris (daurat marca), `accent` = contorn (blau nit per defecte, o el mateix daurat sobre fons fosc). Ajudant `shade(hex, factor)` deriva versions clares/fosques del color. (El codi complet viu a `robot.mjs` — la funció és ESM i reutilitzable en qualsevol diagrama d'agents.)

Patró d'ús a `svgBusinessAIOS()` (`genera-implementacion.mjs`, camp `arquitectura.business_ai_os.svg` de `implementacion.json`):
- **CEO AI** (a dalt, dins banda blau nit #0B1D32): `robotet(cx - 150, 13, { color:'#E7C47D', s:1.7, accent:'#E7C47D' })`. Escala 1.7 (NO 1.9 — amb el robotet més gran, 1.9 surtia de la banda de 98px). `accent` = mateix daurat perquè el contorn es vegi sobre fons fosc. Text CEO a `cx+18` queda separat (el robotet acaba a `cx-72`).
- **Agents** (fila de targetes blanques): `robotetCentrat(ax, 176, { color:'#E7C47D', s:1.05 })` — centra cada agent dins la seva targeta.

## Robotet-en-el-mapa (fix 14/10): marcar els processos del Mapa general que ja tenen agent

Josep: «en els processos automàtics hi sorti un robotet indicant que un agent ia treballa». A les targetes del **Mapa general de l'oferta** (els `.mapa-proc`), afegir un robotet petit quan el procés té automatitzacions **incloses** (`s>0`).

PITFALL: `robotet()` retorna només primitives SVG (rects/circles/paths), **NO un `<svg>`**. Per incrustar-lo en HTML cal embolicar-lo en un `<svg viewBox>` amb dimensió explícita:
```js
import { robotet } from './robot.mjs';
function pipi() {
  const s = 0.26, W = 46*s, H = 52*s;
  const inner = robotet(0, 0, { color:'#E7C47D', s, accent:'#0B1D32' }).trim();
  return `<svg class="mapa-robotet" viewBox="0 0 ${W} ${H}" width="${W.toFixed(1)}" height="${H.toFixed(1)}" role="img" aria-hidden="true" style="width:${W.toFixed(1)}px;height:${H.toFixed(1)}px;display:inline-block;vertical-align:-4px">${inner}</svg>`;
}
```
Inserció a `oferta-html.mjs` (funció `tarjeta` dels `.mapa-proc`): `${s ? `<span class="mapa-robotet-wrap" title="Ya trabaja un agente aquí">${pipi()}</span>` : ''}` just abans de `<span class="codigo">`.

CSS (`plantillas/oferta.html`): posicionar el robotet a l'angle de la targeta sense trepitjar el codi, i fer la targeta prou ampla:
```css
.mapa-proc { padding-right: 26px; }
.mapa-robotet-wrap { position: absolute; top: 4px; right: 5px; display: inline-flex; }
.mapa-robotet-wrap .mapa-robotet { filter: drop-shadow(0 1px 1px rgba(11,29,50,.18)); }
```

## PITFALL: els comentaris HTML dins l'SVG fan FALLAR l'escàner comercial

`svgBusinessAIOS` i `robot.mjs` escriuen **SVG que va a l'OFFERA comercial** (el paquet que veu el client). L'escàner del kit (`escanearHTML` a `generar.mjs`) **rebutja qualsevol comentari HTML (`<!-- -->`)** al document comercial → `✗ El paquete comercial no pasa el escaneo (1 problemas): ✗ [comentario_html]`. Per tant cap `<!-- ... -->` pot quedar dins l'SVG que s'incrusta a l'oferta (caps d'apartat, notes internes...). **Tots els comentaris s'han de treure del génere SVG** (només es permeten les cadenes de codi JS que els generen, no al text final). El dossier intern sí ho suporta, però l'oferta no — ser prudent i no posar-ne a `robot.mjs`. (A més: `escaparHTML` no es diu `e` a `genera-implementacion.mjs` — importar-lo amb àlies si es vol fer servir; el text dels agents es passa per `partir2`, no per `e`.)

## PITFALL: canviar el diagrama NO es propaga amb només `generar.mjs` — cal reexecutar `genera-implementacion.mjs`

`generar.mjs` LLEGEIX `modelo/implementacion.json` tal com està al disc; NO el regenera. Si es toca `svgBusinessAIOS`, `robot.mjs` o qualsevol cosa que generi el diagrama, **cal reexecutar primer** `node herramientas/genera-implementacion.mjs <cliente>` (escriu el JSON) i DESPRÉS `node herramientas/generar.mjs <cliente>`. Si no, l'oferta/dossier nous surten amb l'SVG ANTIC (canvi invisible) i hom pot donar per bo un PDF que encara porta el dibuix vell. Seqüència correcta:
```bash
node herramientas/genera-implementacion.mjs <cliente>   # regenera implementacion.json
node herramientas/generar.mjs <cliente>                  # ara sí, llegeix el JSON nou
```

## PITFALL disseny: fletxes agent → sistemes desalineades (no 1 fletxa per quadradet)

Quan cada automatització toca **diversos sistemes** (ClinicSoft + Verifactu + WhatsApp + Gmail + Google Calendar + SMTP — el normal: ~3 per automat), dibuixar **una fletxa per quadradet de sistema** desalinea tot: hi ha 7 agents però només 1-5 quadradets, així que la majoria de fletxes cauen al buit (Josep: "les fletxes no apunten bé als cuadradets").

Fix correcte (verificat amb PyMuPDF): **un contenidor AMBLE de sistemes a baix de tot**, que cobreix tota la fila (x 60..W-60, y 338, h 54), i dins els **sistemes únics com a xips** etiqueta blaus (paleta clara `#EAF1F9`), amb textos de client abreujats (treure la jerga: `Verifactu / facturación electrónica` → `Verifactu`; `Correu SMTP/IMAP de SPAI...` → `Correu`; `Google Calendar del doctor` → `Google Calendar`...). Cada agent deixa caure la seva fletxa **vertical perpendicular cap al contenidor** — com que el contenidor cobra tota l'amplada, TOTA fletxa hi cau a dins, sempre alineada:
```js
const flexa = (x) => `<line x1="${x}" y1="288" x2="${x}" y2="${SYS_Y+1}" stroke="#cbd5e1" stroke-width="1.8"/><polygon points="${x-5},${SYS_Y+1} ${x+5},${SYS_Y+1} ${x},${SYS_Y+8}" fill="#cbd5e1"/>`; // SYS_Y=338
```
Verificació geomètrica (no visual — el host no té eina de visió): extreure l'SVG de l'HTML generat i comprovar que per a cada `<line>|<polygon>` amb `y>270`, el punt final cau dins d'un `<rect>` amb `y>=330`. Escriure-ho com a mini-script (regex) i executar-ho abans de dir "llest".

**Dada de venda per a Josep**: un procés NO equival a 1 flux n8n. Un client amb 6 processos pot portar 7 automatitzacions (el procés ADM-01 de facturació en té 2: factura + control d'impagats). El nombre de fluxos depèn dels hallazgos detectats, no és 1:1.

Cada robotet aporta molts elements SVG → al PDF la pàgina del Business AI OS té desenes de dibuixos vectorials (verificar amb PyMuPDF `fitz.get_drawings()` per comparar versions). Depuració visual: renderitzar la pàgina del PDF (110-120 dpi) i una ampliació de la zona CEO, i enviar a Josep per confirmar abans de declarar-ho fet — el host no té eina de visió.

**Render a PDF (chrome-headless-shell)**: MAI injectar l'SVG sencer amb width/height inline (no el rasteritza) — extreure només l'interior i posar el `viewBox` a l'SVG pare: `<svg viewBox="${vb}" style="width:100%;height:auto">${inner}</svg>`. Mateix patró que els BPMN del kit.

**No cal eina externa de generació d'imatges (nanobanana/IA) per als robotets** — SVG vectorial fet a mà amb la paleta de marca és la via professional, fiable i que escala al PDF. Els robotets van a l'oferta (secció «El sistema que lo sostiene: Business AI OS») I al dossier (secció 5bis «Integració amb el Business AI OS»).

## Catàleg d'icones d'AGENTS (12_agents_IA) com a badges als nodes del flux n8n

Josep va enviar un DOCX «Cataleg_12_agents_IA» amb **12 il·lustracions d'agents** (PNG 320×320 RGBA, fons transparent) per marcar les TASQUES AUTOMÀTIQUES als processos automatitzats. No són vectorials — incrustar-les com a imatges data-URI, mai reinventar-les a mà.

**Extracció**: el DOCX és un zip; les imatges viuen a `word/media/image1..12.png`. Extreure-les (amb `zipfile`) i desar-les a `02-kit-oferta-soluciones/assets/agent-icons/<NN>_<nom>.png` per al kit 02. Catàleg: `01_comptabilitat, 02_flux, 03_dades, 04_correu, 05_validacio, 06_espera, 07_xat, 08_extraccio, 09_arxius, 10_planificacio, 11_nuvol, 12_factures`.

**Assignació per pas** a `dissenyFlux()` (`genera-implementacion.mjs`): cada pas del flux rep un camp `icona_agent` (nom de fitxer sense extensió) segons el tipus de tasca:
- Disparador: `10_planificacio` (agenda) / `12_factures` (facturació/impagats) / `02_flux` (seguiment o genèric)
- Passos millorats (nodes reals del TO BE): `03_dades` si són IA, `08_extraccio` si són Code/dades
- Aprovació humana: `06_espera`
- Executar l'acció: `12_factures` (Verifactu) / `07_xat` (WhatsApp) / `04_correu` (correu) / `10_planificacio` (calendar) / `11_nuvol` (genèric)
- Registre i traça: `09_arxius`

**Incrusta al diagrama de flux n8n** (l'oficial: `svgFluxN8n` → cada node `nodeN8n`): passar `{ agent: p.icona_agent, uid: `${a.id}_${i}`, mode }` a `nodeN8n`.

**REGLA DE POSICIÓ (correcció FINAL de Josep 14/10, en DOS passos): el robotet va AL CENTRE del quadradet (NO a la cantonada) a TOTS els nodes de l'automatització — EXCEPTE el node d'Aprovació humana, que és una ACCIÓ HUMANA (no una tasca automàtica) i conserva la seva pròpia icona/glif.**
Història de la correcció (per no confondre-la): (1) primer es va posar el robotet a la CANTONADA del node; (2) Josep va dir «robotets a tots els cuadrats d'automatitzacions» → al centre de tots; (3) Josep va matisar «precisament en el d'aprovació humana no, perquè no és un procés automatitzat, és una acció humana». La interpretació intermèdia «només als nodes SENSE dibuix previ» queda SUPERADA — funciona per a tots els nodes automàtics.
```js
const esAprovacioHumana = /aprov/i.test(p.nom);
const mode = (p.icona_agent && !esAprovacioHumana) ? 'agent' : 'n8n';
// nodeN8n: si mode==='agent' → <image xlink:href="${data}" href="${data}" x= y= width= height= preserveAspectRatio="xMidYMid meet"/> AL CENTRE
//           sinó → <svg viewBox=...>${innerIcon}</svg>  (icona n8n real, o el glif _approve a l'aprovació humana)
```
**PITFALL RENDER (fix crític 14/10): `<image>` dins l'SVG NO es rasteritza al PDF si només porta `href`.** Chromium/chrome-headless-shell del kit necessita **`xlink:href` A MÉS de `href`**: `<image xlink:href="data:image/png;base64,..." href="data:image/png;base64,..." x= y= width= height= preserveAspectRatio="xMidYMid meet"/>`. Símptoma: el bloc «cómo lo automatizamos» d'una pàgina mostra NOMÉS 1 imatge en lloc de N (detectar amb PyMuPDF `page.get_images()` per pàgina: comptar-ne). A més **NO cal `clipPath`**: els PNG d'agent són quadrats 320×320 amb fons transparent → posar-los directes (`preserveAspectRatio="xMidYMid meet"`) és MÉS fiable que un `clipPath` dins `<g>` (que també trencava el render). Treure el clipPath i els `uid` de clip.
**MIDA dels robotets als nodes del flux (Josep: «es veuen petits», 14/10)**: icones 34→46→**56px** (iteratiu), caixa del node `w:132,h:94`, `NODE_W:140,H:142,cy:58` a `svgFluxN8n` perquè no se solapin. No quedar-se a 34px (massa petit a impressió).

**També a la cadena «Cómo funcionará»** (`oferta-html.mjs`, `solucionHTML`): incrustar la icona a cada `<li>` de la cadena davant del text del pas: `${agentIconaImg(p.icona_agent)}<span>${e(frasesPas(p.nom))}</span>`. Helper: `agentIconaData(icona)` llegeix l'asset com a data-URI (cache Map per no rellegir), `agentIconaImg` retorna `<img class="etapa-icona" src=...>`.

**MIDA de «Cómo funcionará» (Josep 14/10: «tot el com funciona podria ser una mica més gran i així es veurien bé els robotets»)**: les icones de 18px eren massa petites per veure-hi el robotet. Amb la cadena (i les icones) més grans es veuen bé. CSS: `.cadena { font-size:1rem }` (era .86rem), `.cadena li { padding:8px 16px }`, i `.cadena li .etapa-icona { width:28px; height:28px; object-fit:contain; margin-right:10px }` (era 18px). Ajustar aquesta mida JUNTAMENT amb el `@media print` (les icones grans poden fer que una cadena llarga no capi a la línia i s'emboliqui — acceptable, la cadena fa wrap).

**On busquen els robotets**: Josep els vol als DIAGRAMES DE FLUX dels processos (els nodes), no només a la cadeneta de text. Verificar que la pàgina de cada procés té imatges (PyMuPDF `get_images()`: cada node amb robotet hi aporta una imatge) i dibuixos vectorials dels nodes.

## PITFALL: la portada (portada blau nit) cap en UNA pàgina fins i tot amb el logo gran

Josep vol el logo GRAN a la portada («fes el logo més gran») però la portada ha de cabre en una fulla (66→65 pàg quan es va arreglar: el sello BORRADOR queia sol a la pàg 2). El logo gran (88px a pantalla) + títol llarg + fases + meta + sello NO capen amb el `@media print` estàndard.

Fix (a `@media print` de `plantillas/oferta.html`): reduir el `padding` de portada (16mm→8mm), el `h1` (`clamp(1.8rem,3.8vw,2.7rem)` en lloc del 3.2rem), i compactar `.fases`/`.portada-meta`/`.sello`, mantenint el logo TOT I AIXÍ gran però rebaixat perquè hi càpiga (76px en lloc de 88px a print):
```css
@media print {
  .portada { padding: 8mm 14mm; min-height: 0; break-after: page; }
  .portada .portada-in { max-width: 900px; }
  .portada-logo { height: 76px; margin: 0 auto 16px; max-width: 380px; }
  .portada h1 { font-size: clamp(1.8rem, 3.8vw, 2.7rem); margin-bottom: .3em; }
  .subtitulo { font-size: 1.02rem; }
  .fases { margin: 16px 0 18px; } .fases li { padding: 9px 12px; font-size: .85rem; }
  .portada-meta { gap: 10px 32px; } .sello { margin-top: 18px; }
}
```
Verificar: amb PyMuPDF la pàg 1 porta el sello BORRADOR i la pàg 2 ja té contingut real (>300 chars), no només el peu. La tallada de portada es detecta com a pàg 2 amb molt pocs chars (129) = el sello caient sol.