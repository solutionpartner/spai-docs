# Generar l'OFERTA completa amb el kit 02 AQUÍ (no només al PC de Josep)

Provat 2026-10-12 end-to-end amb la Clínica Dental (6 processos, 7 automatitzacions,
oferta de 54 pàgines + dossier de 26). El kit 02 (`02-kit-oferta-soluciones/`) es pot
pilotar SENZER des d'aquest host; no cal Claude Code al PC de Josep. El pas que requeria
Edge/Chrome s'ha resolt (vegeu fix del navegador avall).

## Ordre d'anàlisi (és la skill `oferta-soluciones` del kit, feta a mà aquí)

```
1. node herramientas/importar.mjs entrada/<client> --cliente <id> --nombre "..."
   → copia a workspace/clientes/<id>/ amb SHA256. Espera: 6 processos ✓ completa, 0 pendents,
     0 contradiccions. (Els .svg amb DOCTYPE es bloquegen per seguretat = normal, es redibuixen.)
2. model/areas.json        — codi→area de config/areas.json (MKT,VEN,CLI,OPE,LOG,TEC,FAC,COB,COM,ADM,PER,DIR,IT)
3. model/hallazgos.json    — un per `dolor` concret (categoria, tipus_afirmacion, evidencia {fuente,ref},
                             cita LITERAL + cita_ref "CODIGO#nodo.dolor").
4. model/automatizaciones.json — capacitats de negoci (una = un ID AUT-*, es cobra un cop).
                             process_ids, finding_ids, client.* (llenguatge negoci), internal.*
                             (pattern, escalera, autonomy), prioridad 1-5 + *_explicacion, baseline.
5. model/to-be/<codi>.json  — fitxa AS IS clonada, nodes canviats amb "propuesta":"AUT-xxx"
                             (surten en blau), sense `dolor` (el problema no s'arrossega).
6. model/escandallo.json    — hores per rol per automatització (estimació interna, SPAI revisa).
                             Sense tarifes aprovades → tot "pendiente_estudio".
7. model/oferta.json        — incluidas, fases, resumen_ejecutivo, responsabilidades_cliente, etc.
```

Després de cada fitxer: `node herramientas/validar.mjs <id>` (esquemes + cites literals +
referències). Cal `calcular.mjs` (tot "pendiente" sense tarifes — esperat) i `generar.mjs`.
Final: `generar.mjs revisado <id> --version N --paginas <n> --resultado ok --notas "..."`.

## Les 3 restriccions que mantenen l'oferta en BORRADOR (identiques sempre)

1. `config/tarifas.json` — estat `ejemplo_simulado`, tot null → cada preu "pendiente".
2. `config/prestador.json` — raó social + NIF null → no es pot "llesta per signar".
3. Condicions jurídiques pendents.
L'oferta surt "BORRADOR NO VINCULANT" i ho diu. La decisió comercial (quines AUT entren) és
SEMPRE de SPAI: mostrar la cartera en una taula (ID, títol, processos, prioritat) i preguntar
"quines entren / quines quedaran com a futura". Mai escollir per ell.

## FIX crític del navegador (navegador.mjs)

El kit busca Edge/Chrome i aquí només hi ha el chrome-headless-shell de Playwright. Dos passos:
1. `config/kit.json → navegador` = `/opt/data/tools/.pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell`.
2. AFEGIR a `ARGS_BASE` de `herramientas/navegador.mjs`: `--no-sandbox` i `--disable-software-rasterizer`.
   Sense aquests, el render bpmn-js penja (exit null, 0 bytes) amb la combinació de flags de xarxa
   (`--host-resolver-rules` + `--proxy-server`) del kit en contenidor sense GPU. Són flags innocents:
   no toquen seguretat ni càlculs. És un canvi de COMPATIBILITAT, no de lògica.

Després d'afegir-los, `diagramas.mjs` dibuixa els 12 diagrames (6 AS IS + 6 TO BE) sense problemes.

## "No bots de veu" (regla de producte)

Quan un procés té passos de "llamar/trucar/telefonar/parlar", la solució MAI és un bot de veu
(car, poc fiable, TTS/STT de tercers). Es proposa **missatgeria automàtica** (WhatsApp/correu —
recordatoris i seguiment). A la `millora_breu` de genera-diagnostico.py s'ha afegit una branca
abans del genèric `mano` que ho cobreix:

```python
if any(v in n for v in ["llamar","truc","truca","telef","parlar","hablar","crida a","llamad"]):
    return "Recordatoris i seguiment automatitzats per missatge (WhatsApp/correu), sense trucar un a un."
```

Josep ho va confirmar: "Deixemho així" — mai prometre bots que truquen; si en algun cas concret
cal, es decideix explícitament per client a l'oferta, no s'autogenera a la radiografia.
