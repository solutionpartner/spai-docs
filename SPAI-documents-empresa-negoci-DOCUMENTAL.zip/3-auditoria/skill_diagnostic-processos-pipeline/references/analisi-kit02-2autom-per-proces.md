# Construir l'anàlisi del kit 02 quan cada procés té 2+ automatitzacions

Anti-pattern clar: `node herramientas/importar.mjs` NOMÉS importa les fitxes/processos
(empresa, procesos, pendientes, equivalencias, herramientas, contradicciones). **NO genera
`areas.json`, `hallazgos.json`, `automatizaciones.json`, `to-be/*`, `escandallo.json` ni
`oferta.json`.** Aquests 6 fitxers els ha de construir l'analista (el "Claude" del kit / un
script generador), NO es deriven automàticament de les respostes.

## Model de dades real

- **1 `hallazgo` = 1 punt de dolor concret** (normalment un node amb `dolor` no buit).
- **1 `automatización` = 1 capacitat de negoci** (un ID `AUT-*`, es cobra un cop), que pot
  resoldre **1 o més hallazgos del MATEIX procés** (`process_ids` + `finding_ids`).
- **Per què un procés pot tenir 2+**: el mapeig va per dolors independents, no per processos.
  Un procés amb 3 punts de dolor independents → 3 automatitzacions (o 2, agrupant-los).
  Dada de venda per a Josep: NO és 1 procés = 1 flux; `ADM-01` facturació = factura + impagats.

## Recepta per a un client on CADA procés en té 2+ (provat 14/10, Ràpids Logistics CL-0004)

Un script Python que llegeix les fitxes AS IS i produeix els 6 fitxers de manera vàlida i
coherent (evita errors d'esquema i referències trencades en l'edició a mà). Patró a
`workspace/clientes/rapids-logistics/genera-analisi.py`.

Per procés: `mapping TODEF = { node_id: [aut_ids] }` assigna cada node millorat a la seva
automatització. Les AUT que toquen el mateix procés comparteixen nodes disjunts → cada
automatització té els seus propis `finding_ids`.

Ordre d'escriptura (i validar després de cada fitxer):
1. `areas.json` (schema areas/1) — codi→`primary_business_area_id` + `related_area_ids`
   (de `config/areas.json`: MKT,VEN,CLI,OPE,LOG,TEC,FAC,COB,COM,ADM,PER,DIR,IT).
2. `hallazgos.json` (schema hallazgos/1) — un per node amb `dolor`. Camp `cita` = el dolor
   LITERAL. `cita_ref` = `PROC#node.dolor`.
3. `automatizaciones.json` (schema automatizaciones/1) — `client.*` en llenguatge de negoci
   (sense jerga), `internal.*` (pattern/escalera/autonomy/systems), `prioridad` 1-5,
   `baseline.estado:'pendiente'`.
4. `to-be/<codi>.json` — clone de la ficha AS IS amb `propuesta:'AUT-x'` als nodes
   millorats + bloc `cambios[]` (`{tipo:'automatizado', nodo, antes, despues, automatizacion}`).
5. `escandallo.json` (schema escandallo/1) — hores per rol per AUT + BASE (0 preus → tot
   `pendiente_estudio`).
6. `oferta.json` (schema oferta/1) — `incluidas` (totes), `fases`, `resumen_ejecutivo`.

## Pitfalls verificats (no topar-hi)

- **Cites literal: llegir el `dolor` de la fitxa AS IS, NO del formulari original.** El
  formulari (respostes.json) pot tenir `idx` no alineat amb el codi del procés (VEN-01≠idx 1),
  i `validar.mjs` dóna `✗ HAL-xxx: la cita no aparece literal en PROC#node.dolor`. La font
  fiable és `modelo/fichas-as-is/PROC.json` → node `.dolor`.
- **`validar.mjs` només BLOQUEJA amb `✗`; els `!` (avisos)** — to de l'esdeveniment massa llarg,
  verb genèric "Gestionar..." — són estil, no impedeixen generar. No perseguir-los tots.
- **Cada hallazgo amb `decision:'automatizar'` ha d'estar resolt per alguna AUT** (quedaria
  un avís `HAL dice automatizar pero ninguna automatización lo resuelve`). El mapping TODEF
  ha de cobrir tots els nodes amb dolor; si un dolor no es vol automatitzar, canviar la
  `decision` (no deixar-lo penjant amb 'automatizar').
- **El `despues` dels canvis ha de ser DIFERENT del `antes` (bug 14/10)**: si el generador posa
  `despues = n.get('nombre')` (el mateix nom AS IS), la taula de canvis de l'oferta mostra
  columna «Hoy» i «Con la propuesta» IDÈNTIQUES i Josep ho nota ("he vist que els canvis hoy i
  con la propuesta diuen el mateix"). Fix: definir un mapa `TOBE_NOM = { proc: { node: '<nom><...>automatitzat' } }`
  per node i assignar-lo com a **nou `nombre` del node al TO BE** (`n['nombre'] = TOBE_NOM[proc][nid]`), de
  manera que el `despues` del canvi reflecteixi la millora real (ex. «Recibir pedidos por varias vías»
  → «Recibir los pedidos por un único canal»; «Avisar al conductor de su ruta» → «Avisar al conductor
  automáticamente»). Verificar amb el script de recompte: cap `cambios[]` amb `antes == despues`.
- **Comprova per procés el recompte**: llegir `automatizaciones.json`, agrupar per
  `process_ids[0]`, i confirmar que cada procés en té el nombre desitjat. `Ràpids: VEN-01:2,
  FUL-01:2, FUL-02:3, ADM-01:2, ADM-02:2 = 11 AUT / 5 processos`, 23/23 hallazgos resolts.

## clients-bd.py — bug d'IDs (fix 14/10)

L'ID nou es calculava com `COUNT(*) + 1`, que col·lisiona quan hi ha registres esborrats a
mig (CL-0001 i CL-0003 existents, COUNT=2 → CL-0003 duplicat). Fix: basar-se en el MÀXIM
numèric:

```sql
SELECT COALESCE(MAX(CAST(SUBSTR(id,4) AS INTEGER)),0) FROM clients
```

Si `nou` falla amb `UNIQUE constraint failed: clients.id`, esborrar la carpeta òrfena
`clients/CL-XXXX-.../` que l'intent fallit hagi pogut crear abans de l'INSERT.
