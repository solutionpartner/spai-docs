# Dibuixar diagrames BPMN amb el MOTOR del kit (regla d'or, 2026-10-12)

Regla de fons: **mai reinventar el layout BPMN.** El kit de diagnòstic (`02-kit-oferta-soluciones/`)
porta un motor de 687 línies (`herramientas/motor-bpmn/colocar.mjs`) amb enrutament A*, mesura
tipogràfica, subfiles de decisions i carrils. Reescriure això en Python produeix diagrames que el
client rebutja ("les línies no coordinen", "ningu pagaria un duro").

## Pipeline correcte (genera-diagramas.mjs)

```
ficha (modelo/<codi>.json, format ficha-proceso/1)
  → normalizarFicha()      (motor-bpmn/modelo.mjs)
  → comprobarFicha()       (rebutja fitxes invàlides abans de dibuixar)
  → colocar()              (motor-bpmn/colocar.mjs — layout)
  → generarXML()           (motor-bpmn/bpmn.mjs — BPMN 2.0 amb DI correcte)
  → render bpmn-js         (plantillas/render-bpmn.html + visor-bpmn/)
  → svg/<codi>.svg         (vectorial, llest per web i PDF)
```

Els mòduls del motor s'importen per ruta `file://` (depenen entre si per imports relatius,
que es resolen correctament). bpmn.mjs depèn de TIPOS/VERSION_KIT/claseErrorKit dels seus
`./*.mjs` veïns — importar-los TODS del mateix directori.

## Format de fitxa VÀLID (el que exigeix comprobarFicha)

- **àrees**: `marketing`, `ventas`, `fulfillment`, `administracion` (els kits de SPAI usen
  aquestes; `comercial`/`fabricacion` NO existeixen → mapejar-les a ventas/fulfillment).
- **subtipo d'inici/fin**: `ninguno` (no `evento`).
- **decisió**: tipus `exclusiva` (compuerta exclusiva), NO una tasca amb `tipo:"decision"`.
  Modelar així: node `d{j}` amb la pregunta + un flujo `nombre:"No"` → fin alternatiu + el
  flux següent porta `nombre:"Sí"`.
- **participants**: únics (sense duplicats del mateix extern).
- **missatges**: sempre entre un node i un participant extern (mai node↔node; mai entre dos
  participants). `enviar` → node→extern; `rebre` → extern→node.
- **carrils** `l1,l2,…` referenciats correctament per cada node.

## Render a SVG (chrome-headless-shell)

El chromium FULL (`chrome-linux64/chrome`) retorna stdout buit amb `--dump-dom`; el
**`chrome-headless-shell`** és el binari correcte per al render bpmn-js → SVG:

```bash
/opt/data/tools/.pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell \
  --headless=new --disable-gpu --no-sandbox --user-data-dir=<tmp> \
  --virtual-time-budget=15000 --dump-dom "file://<render-bpmn.html>"
```

El resultat ve al `<pre id="salida">...</pre>` (JSON), cal desescapar `&lt;/&gt;/&quot;/&#39;/&amp;`.
Els logs DBus/GLib/CSP/font són soroll esperat al contenidor — ignorar-los (sortida per stderr).

## PDF (no reportlab)

El kit imprimeix un HTML de impresión amb el navegador invisible (`--print-to-pdf`). Reproduir
amb Playwright (`scrapling-env`): `chromium.launch(args=["--no-sandbox"])` → `goto(file://…)` →
`page.pdf(format="A4", print_background=True)`. L'HTML ja porta els SVG incrustats → el PDF surt
amb els diagrames vectorials. Verificar amb PyMuPDF `get_drawings()`: ~80-90 dibuixos vectorials
per làmina de procés = correcte.

## Trampes

- `--with-deps` de playwright install intenta sudo i falla al contenidor → instal·lar **sense**
  `--with-deps`, només `PLAYWRIGHT_BROWSERS_PATH=/opt/data/tools/.pw-browsers`.
- Els SVG de bpmn-js porten hits/outlines invisibles (`djs-hit`, `djs-outline`): prescindibles;
  si s'incrusten a HTML no molesten perquè ja són transparents.
- `comprobarFicha` retorna `errores` (atura) i `avisos` (estil, p. ex. verb genèric); els avisos
  no bloquejen el dibuix però s'han de tenir vistos.
