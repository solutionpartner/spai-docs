# Encaix kit → Business AI OS (desplegament governat)

Còpia condensada de SPAI-KP-DEPLOY-001 (orig a `/opt/data/spai-knowledge/kit-deploy-encaix/`).

## Les 5 capes (diagrama mapa-encaix-kit-buildpack.svg)

1. **Cicle comercial** (fet) — kit01 (auditoria BPMN) → kit02 (oferta + dossier intern).
2. **Model del tenant** (fet, sortida del kit) — `implementacion.json`, skills de l'Hermes, MCPs,
   JSON n8n nets, prompt "Implementa això", ordre de desplegament.
3. **Pont** (A CONSTRUIR) — onboarding del tenant alimentat pel model del kit.
4. **SPAI central** (dissenyat) — OPTIMUS governa, Signer Ed25519, Action Gateway, aprovació humana.
5. **Tenant del client** (dissenyat) — Hermes del client (Argon), n8n, Business OS, runtime-sync,
   heartbeat, deploy worker.

## Decisions preses (no re-obrir sense motiu)

| Tema | Decisió | Font |
|---|---|---|
| Orquestració | **Docker Compose. NO Kubernetes** | Build Pack 03 |
| Autoritat de seguretat | Hermes NO és autoritat ni té root | Phase 14 |
| Credencials ERP/CRM | Al domini del **tenant**, només secret_ref central | Build Pack 03 |
| Accés producció | `SP_CLIENT_AUTH_MODE=key+mtls` després d'enrolament | Runbook 04 |
| Topologia | **A confirmar** — no canviar en silenci | Build Pack 03 |

## Flux de deploy governat

```
CI construeix → signer signa (Ed25519) → Control Plane registra
→ aprovador humà autoritza → deploy worker del tenant fa pull i valida
→ handler local aplica → health + stat "applied" verificats
```

Mutacions via `propose_action` → aprovació → `execute_approved_action`. Rollback:
`POST /deployments/{id}/rollback`. Un rollback de codi NO desfà un efecte extern.

## Ubicacions

- Mapa: `/opt/data/spai-knowledge/kit-deploy-encaix/` (README + d2 + svg + png), ID SPAI-KP-DEPLOY-001.
- Disseny canònic: `/opt/data/spai-build-pack/SPAI_Hermes_Build_Pack_v1_1/` (runbooks 00-08 +
  `referencia_baseline/docs/`).
- Fases: `/opt/data/spai-fases-historic/` (1-21, zips).
- Deploy n8n self-hosted: `/opt/data/recursos/n8n-deploy/` (get-n8n.sh + compose oficial).

## PONT FET (2026-10-16) — `onboarding.mjs`

`herramientas/onboarding.mjs <cliente>` llegeix `implementacion.json` i genera a `modelo/`:
- `onboarding-manifest.json` — document intern (components, workflows, MCPs, secret_refs, ordre).
- `onboarding-template.json` — ✅ VÀLID contra `onboarding-template.schema.json` real: `spec.base_components[]` amb
  `component_type` (agent/skill/connector/runtime/workflow), `secret_requirements[]`, `require_mtls`, `approval_policy`.
- `onboarding-request.json` — payload 1:1 amb l'exemple oficial (`tenant_id`, `tenant_name`, `template_id`,
  `template_version`, `environment`, `base_url`) per a `POST /onboarding/preview` i `/onboarding/jobs`.

**Validació contra el Control Plane REAL** (no només la doc): desempaquetat a
`/opt/data/spai-baseline-milestone/business_ai_os_production_milestone_1/` (control_plane/, tenant_runtime/,
contracts/ ×58, scripts/, handlers/, supervisor_mcp/, docker-compose). Els contracts es validen amb jsonschema
`Draft202012Validator`. `client_deploy_worker.py` és pull + handler local amb `secret_refs` (MAI valor al Control Plane).
Els JSON n8n nets del kit passen la `n8n-dev-policy` (nodes únics, type present, sense secrets incrustats,
sense `executeCommand`/`ssh`). El template d'onboarding mapeja: skill→`skill`, automatisme→`workflow`, MCP→`connector`,
Argon→`agent`, runtime→`runtime`.

## Què falta per desplegament automàtic

1. ✅ ~~Pont kit→onboarding~~ FET (`onboarding.mjs` + validat contra contracts reals).
2. Artefactes reproduïbles (imatges central/tenant, Compose amb health/egress explícit).
3. Claus i CA amb custòdia separada.
4. Provar en staging (`docker compose` + `seed_onboarding_template.py` amb el nostre template).
5. Primer tenant real: enrolament mTLS, components signats, secrets locals, health + read-only ERP.

## Regenerar el diagrama

```bash
/opt/data/tools/d2/bin/d2 --layout elk --pad 24 --theme 0 \
  --font-regular <kit>/assets/fonts/Roboto-Regular.ttf \
  --font-bold    <kit>/assets/fonts/Roboto-Bold.ttf \
  mapa-encaix-kit-buildpack.d2 mapa-encaix-kit-buildpack.svg
```
