# Sistema d'Arxius per Client — SOBRE RAILS

**Data:** 26/10/2026  
**Estat:** ✅ Operatiu — Generació automàtica integrada

---

## Estructura Estàndard per Client

```
/opt/data/clients/CL-XXXX-[nom-client]/
│
├── auditoria/                          # Origine auditoria digital
│   ├── empresa.json                    ← Guardat automàticament (auditoria global)
│   ├── report-web/                     ← Per a reports web (Kit02)
│   └── report-pdf/                     ← Per a reports PDF (Kit02)
│
├── kit02-optimizacio/                  # Processos BPMN + sindicacions (ANTERIOR)
│   ├── bpmn-radiografia/               ← Sindicacions BPMN dels processos
│   ├── sindicacions-procesos/          ← MD dels processos (generat Kit02)
│   └── automatismes-kit02/             ← Específicacions dels automatismes
│
├── implementacio/                      # Solucions tècniques (NOVA CARPETA)
│   ├── briefs/
│   │   └── brief_global.md             ← Guardat automàticament (oferta → brief)
│   ├── sindicacions-bpmn/              ← Linked from kit02 si aplica
│   ├── automatismes-ofertats/          ← Especificacions (si s'ofereixen)
│   └── progres/                        ← Claude actualitza conforme avanç
│
└── deliverables/                       # Lliurables finals
    ├── pdfs/
    │   └── oferta_global.pdf           ← Guardat automàticament (WeasyPrint)
    └── html/
        └── oferta_global.html          ← Guardat automàticament (si --html)
```

---

## Motor: Com Funciona "Sobre Rails"

### Comando (una sola comanda, autòmata tot):

```bash
cd /opt/data/.claude/audit-system
.venv/bin/python cataleg/avalua-oferta-global.py \
    templates/supermercat_barri.json \
    --html /tmp/oferta.html \
    --pdf /tmp/oferta.pdf \
    --client-id "CL-0001"
```

### Automàticamente es fa:

1. ✅ Crea estructura de directoris per al client
2. ✅ Genera brief d'implementació (MD)
3. ✅ Guarda empresa.json (auditoria)
4. ✅ Guarda PDF d'oferta
5. ✅ Mostra path final

### Output al terminal:

```
✓ Estructura creada: /opt/data/clients/CL-0001-supermercat-barri-de-lleida
✓ Brief guardat: .../implementacio/briefs/brief_global.md
✓ Empresa JSON guardat: .../auditoria/empresa.json
✓ PDF oferta guardat: .../deliverables/pdfs/oferta_global.pdf

✓ Documentació guardada sobre rails per a CL-0001
  - Brief: /opt/data/clients/CL-0001-supermercat-barri-de-lleida/implementacio/briefs
  - Empresa JSON: /opt/data/clients/CL-0001-supermercat-barri-de-lleida/auditoria/empresa.json
  - PDF: /opt/data/clients/CL-0001-supermercat-barri-de-lleida/deliverables/pdfs
```

---

## Mòdul Integrador: `ClientDocumentsManager`

**Arxiu:** `/opt/data/.claude/audit-system/cataleg/client_documents_manager.py`

### Funcions públiques:

```python
from cataleg.client_documents_manager import ClientDocumentsManager

# Crear gestor per a client
mgr = ClientDocumentsManager("CL-0001", "Supermercat Barri de Lleida")

# Crear estructura (idempotent)
mgr.crear_estructura()

# Guardar documents
mgr.guardar_brief_global(brief_md_content)
mgr.guardar_sindicacio_bpmn(sindicacio_md, "process_name")
mgr.guardar_automatismes_ofertats(automatismes_md)
mgr.guardar_empresa_json(empresa_json)
mgr.guardar_oferta_pdf(pdf_bytes)

# Llistar tots els documents
docs = mgr.llistar_tots_documents()
```

### Propietats (directoris):

```python
mgr.dir_briefs                    # .../implementacio/briefs/
mgr.dir_sindicacions_bpmn         # .../implementacio/sindicacions-bpmn/
mgr.dir_automatismes_ofertats     # .../implementacio/automatismes-ofertats/
mgr.dir_deliverables_pdf          # .../deliverables/pdfs/
mgr.dir_auditoria_web             # .../auditoria/report-web/
mgr.dir_auditoria_pdf             # .../auditoria/report-pdf/
```

---

## Integració al Motor Principal

**Arxiu:** `/opt/data/.claude/audit-system/cataleg/avalua-oferta-global.py`

Quan es pasa `--client-id CL-XXXX`:

```python
if client_id:
    from client_documents_manager import ClientDocumentsManager
    mgr = ClientDocumentsManager(client_id, nom_client)
    mgr.crear_estructura()
    
    # Genera brief automàticament
    brief_md = generar_brief_implementacio(d, proposats_serveis, nom_client, ...)
    mgr.guardar_brief_global(brief_md)
    
    # Guarda empresa JSON
    mgr.guardar_empresa_json(json.dumps(d, indent=2))
    
    # Guarda PDF d'oferta
    mgr.guardar_oferta_pdf(pdf_bytes)
```

---

## Exemple Real: Supermercat

**Comanda:**
```bash
cd /opt/data/.claude/audit-system
.venv/bin/python cataleg/avalua-oferta-global.py \
    templates/supermercat_barri.json \
    --html /tmp/oferta.html \
    --pdf /tmp/oferta.pdf \
    --client-id "CL-0001"
```

**Resultat:**
```
/opt/data/clients/CL-0001-supermercat-barri-de-lleida/
├── auditoria/empresa.json
├── deliverables/pdfs/oferta_global.pdf
└── implementacio/briefs/brief_global.md
```

---

## Exemple Real: Clínica

**Comanda:**
```bash
.venv/bin/python cataleg/avalua-oferta-global.py \
    templates/clinica_dental_ponent.json \
    --html /tmp/clinica.html \
    --pdf /tmp/clinica.pdf \
    --client-id "CL-0002"
```

**Resultat:**
```
/opt/data/clients/CL-0002-clínica-dental-ponent/
├── auditoria/empresa.json
├── deliverables/pdfs/oferta_global.pdf
└── implementacio/briefs/brief_global.md
```

---

## Flux de Treball per a Josep

### Pas 1: Generar oferta + guardar
```bash
cd /opt/data/.claude/audit-system
.venv/bin/python cataleg/avalua-oferta-global.py \
    [client.json] \
    --html /tmp/oferta.html \
    --pdf /tmp/oferta.pdf \
    --client-id "CL-XXXX"
```

### Pas 2: Verificar que s'ha creat
```bash
ls -R /opt/data/clients/CL-XXXX-[nom]/implementacio/
```

### Pas 3: Enviar brief a Claude
- Brief: `/opt/data/clients/CL-XXXX-[nom]/implementacio/briefs/brief_global.md`
- Guía: `/opt/data/.claude/audit-system/deliverables/GUIA_BRIEF_IMPLEMENTACIO.md`

### Pas 4: Claude llegeix i implementa
- Claude consulta el brief
- Fa preguntes al client
- Implementa solucions
- Actualitza `/implementacio/progres/` conforme avanç

---

## Flux de Treball per a Claude

### 1. Llegir el brief
```
/opt/data/clients/CL-XXXX-[nom]/implementacio/briefs/brief_global.md
```

### 2. Per a cada servei:
- Cercar documentació
- Fer preguntes al client
- Proposar arquitectura
- Implementar + test

### 3. Actualitzar l'estat
```bash
# Claude pot guardar progres
echo "## Servei SVC-DIG-02 implementat ✓" >> /opt/data/clients/CL-XXXX-[nom]/implementacio/progres/changelog.md
```

---

## Estructura de Directoris per Tipus d'Arxiu

| Arxiu | Generador | Guardat Automàticament | Ubicació |
|-------|-----------|------------------------|----------|
| Brief global (MD) | `genera_brief_implementacio.py` | ✅ Quan `--client-id` | `implementacio/briefs/brief_global.md` |
| Empresa JSON | `carrega_client()` | ✅ Quan `--client-id` | `auditoria/empresa.json` |
| PDF oferta | `avalua-oferta-global.py` | ✅ Quan `--client-id` + `--pdf` | `deliverables/pdfs/oferta_global.pdf` |
| Sindicacions BPMN | Kit02 (futur) | ❌ Manual (integrable) | `implementacio/sindicacions-bpmn/` |
| Automatismes ofertats | (futur) | ❌ Manual (integrable) | `implementacio/automatismes-ofertats/` |
| Progres Claude | Claude | ❌ Manual | `implementacio/progres/` |

---

## Verificació: Tot Sobre Rails ✅

- ✅ **Estructura:** Estàndard per tots els clients
- ✅ **Automàtica:** Generat sense intervencio manual
- ✅ **Escalable:** Funciona per a qualsevol client (multi-client)
- ✅ **Determinística:** Mateixa comanda = mateixa estructura
- ✅ **Integrada:** Tot el motor sap on guardar

---

## Pròxim: Integrar Kit02 + Sindicacions BPMN

Falta integrar les **sindicacions de BPMN** (dels processos diagnosticats) al directori `implementacio/sindicacions-bpmn/` automàticament des de Kit02.

```python
# Integrar sindicacions
from cataleg.client_documents_manager import integrar_sindicacio_bpmn_a_client

for process_name, sindicacio_md in kit02_results:
    integrar_sindicacio_bpmn_a_client("CL-XXXX", nom_client, process_name, sindicacio_md)
```

---

**Sistema complet i operatiu.**  
**Tots els clients guardan els seus documents en el mateix lloc.**  
**Sobre rails — sense hardcoding, sense intervencio manual.**
