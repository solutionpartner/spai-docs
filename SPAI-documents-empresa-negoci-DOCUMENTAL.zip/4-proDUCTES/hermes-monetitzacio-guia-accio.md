# Hermes Agent — monetització i ús avançat (guia accionable)

Versió 1.0 · SolutionPartner.AI · 2026-11

> Què és això: recull del coneixement d'Hermes Agent que anem acumulant, convertit en
> **accions** per monetitzar-lo i fer-lo servir avançat — no en teoria. Cada secció
> acaba amb "PRÒXIM PAS" concret.

---

## 0. Realitat de costos (abans de res)

**Hermes Agent (el programa) és GRATUÏT i MIT.** El que costa és els models i els
serveis allotjats. Dos camins:

| Camí | Cost | Què inclou |
|---|---|---|
| **BYO (portal propi)** | Només els models | OpenRouter / Groq / DeepSeek claus pròpies. **Això és el que fem ara al servidor.** |
| **Nous Portal** | $0 / $20 / $100 / $200 per mes | 300+ models, web search, imatges, TTS, cloud browser, hosting d'un agent al núvol: Free=0 / Plus=20 (4GB,25GB) / Super=100 (4GB,100GB) / Ultra=200 (8GB,100GB). |

**Decisió que ha de quedar escrita:** per a clients PIME (volum baix), **BYO surt
més barat** que subscriure cada client a Nous Portal. Nous Portal paga la pena per a
**el vostre propi agent com a producte** (cloud always-on) o per a un client gran amb
ús intensiu.

**PRÒXIM PAS:** calcular el cost real per client/mes del teu model (OpenRouter vs Groq
gratis) i decidir el marge. Fins llavors, segueix amb BYO.

---

## 1. Per què podeu cobrar més que per "una web"

El que distingeix Hermes (vs una web estàtica) és que és un **agent amb memòria,
skills i accés a eines** que funciona sincrònic (xat) i **asincrònic (cron, webhooks)**.
Per això un client PIME paga subscripció mensual, no una sola factura de construcció.

Eixos que es venen com a servei recurrent:
- **Assistent del client** (xat amb la seva informació: catàleg, preus, avisos).
- **Automatitzacions programades** (informes setmanals, recordatoris, backups).
- **Multi-canal amb un sol motor** (Telegram, WhatsApp, email, web) — un agent, moltes superfícies.
- **Memòria persistent per client**: el perfil/la memòria del client és el que fidelitza
  (no reinicia de zero cada sessió).

**PRÒXIM PAS:** al pack de client, oferir SEMPRE la subscripció "agent" (no només la web).
La web és l'aparador; l'agent és la subscripció.

---

## 2. Multi-client amb Profiles (clau de l'escala)

Hermes suporta **perfils independents** (`~/.hermes/profiles/<nom>/`) — cada un amb
config, sessions, skills i memòria separats. Això és EXACTAMENT el que necessites per
servir N clients sense barrejar dades.

- Un **perfil per client**: la seva memòria, les seves skills, el seu canal (Telegram/texts).
- Aïllament total: el client A no veu el client B.
- Un mateix motor, moltes instàncies aïllades.

**PRÒXIM PAS:** protocol intern "1 client = 1 perfil" (noms, on es guarden), quan et calgui
multi-client real. Ara mateix, amb uns pocs clients, n'hi ha prou amb la memòria del perfil
`default`.

---

## 3. Ús avançat que es pot vendre o fer servir internament

### a) Agents en segon pla i delegació
- **`delegate_task`**: llançar subtasques en paral·lel aïllades (investigar, construir),
  només en torna el resum final — no et crema el context. Per a pipelines de "treball multiplicat".
- **Spawning de processos independents** (`hermes chat -q '...'`, tmux per a interactius):
  missions llargues que corren hores/dies sols.
- **`cronjob`**: feina programada que surt sola (informes, briefings, seguiment de preus).

**Venda:** "un agent que treballa mentre tu dorms": cron + agents en segon pla = proposta
de valor clara per a PIME amb operació repetitiva.

### b) Cron i webhooks (automatització continuada)
- **Cron**: informes diaris/setmanals, comprovacions, digests — lliurats automàticament.
- **Webhooks**: esdeveniments externs disparen una execució (fer un registre o actualitzar
  un estat quan arriba un senyal).

**Venda:** "l'agent reacciona i treballa sol", sense que el client hagi de fer res cada dia.

### c) Gateway multi-canal
El mateix agent a Telegram, WhatsApp, email, web... tots amb accés complet a eines.
**Venda:** "un sol assistent a tots els canals del teu negoci".

### d) Mixture of Agents (MoA)
Combina diversos models que s'assessoren entre si per a tasques dures. **No per a tot**:
el cost recau en l'agregador. Ús puntual per a feines complexes de consultoria, no per default.

---

## 4. Catàleg de serveis que ja tens (lligat a això)

Conecta amb els teus productes existents (catàleg `products-catalog.md`):

- **#1 Xat comercial del client** → perfil per client + xat format amb els seus documents.
- **#2 Facturació/cobraments** → cron + agent que llegeix el gestor i envia recordatoris.
- **#5 Tendències/contingut 30 dies** → skill `last30days` (ja instal·lada) + cron setmanal.
- **#6 Informes KPI** → cron + motor d'informes (reporting/engine) + enviament per email.
- **#12 Pack web + IA** → la base: web (Strapi) + agent (Hermes) per sobre, quota mensual.

Hermes és el **motor d'agent** del "producte web + IA". La web és de Strapi/GitHub Pages;
l'agent que llegeix les dades i treballa és Hermes.

---

## 5. Costos i eines que ja tenim (evita pagar)

- **LLMs gratis/barats:** OpenRouter + Groq (claus a `/opt/data/.env`). DeepSeek via OpenRouter.
- **Imatges/veu/web search:** si no els pagues a Nous Portal, tens alternatives gratuïtes pròpies
  (piper per TTS, web search d'Hermes, etc.).
- **Regla de la casa:** escanejar tota eina/skill de tercers abans d'instal·lar-la
  (crides de xarxa, exec, credencials, fugides) — skill `third-party-kit-vetting`.

**PRÒXIM PAS:** mai pagar Nous Portal de res si la teva stack BYO cobreix el mateix per menys.
Nous Portal = només si el cloud always-on o els hosted tools justifiquen la subscripció.

---

## 6. Pla d'acció (ordre recomanat)

1. **Triar el primer client-pilot** — 1 negoci real que vulgui "assistent + automatització".
2. **Muntar perfil pilot**: canal (Telegram/correo), memòria del client, 2-3 skills seves,
   i 1 cron útil (informe setmanal o recordatori).
3. **Fixar preu subscripció** mínim que cobreixi models + el teu marge (creu als calculs de la secció 0).
4. **Documentar el cas** com a plantilla reutilitzable (el que aprens passa a skill/plantilla de client).
5. **Escalar a multi-client** amb un perfil per client quan el pilot ho validi.

**Indicador d'èxit:** el client pagan mensualment de forma recurrent (no només la construcció inicial).

---

## Fitxers i referències on trobar-ho

- `deliverables/products-catalog.md` — les 12 idees de productes SaaS.
- Skill `hermes-agent` (aquest entorn) — tot del framework i les seves referències.
- Docs oficials: `https://hermes-agent.nousresearch.com/docs/` (fiable, sempre al dia).
  L'índex complet: `.../docs/llms.txt`.
- `deliverables/` — on aterren les guies accionables com aquesta.

---

*Document viu: actualitza'l quan aprenguis quelcom nou d'Hermes (nous skills, nous
patrons de monetització, nous costos). Proposo revisar-lo cada cop que es tanqui un client.*