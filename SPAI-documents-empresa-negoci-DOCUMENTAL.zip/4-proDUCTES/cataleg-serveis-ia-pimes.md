# Serveïs per a PIMEs amb IA — Catàleg de Solució

Font d'inspiració: Insidr.ai (plataforma de consultoria IA per a PIMEs, posicionament
"automatitzar i escalar amb IA") + el nostre catàleg d'eines instal·lades/verificades.
Per a la carta de serveis de SolutionPartner (AI Strategy & Automation).
Llenguatge PLANER (no tècnic) per a clients.

---

## ⚙️ 1. Automatització de processos (el cor del negoci)

**Insidr ho ven com:** "AI Business Audit — identifica com la IA es pot implementar al teu negoci" +
"Automate your sales funnel".

**Els nostres serveis (del catàleg d'eines):**
- **Auditoria de processos IA** — quins processos del negoci es poden automatitzar i per on començar (ja el tenim: qüestionari 1B → BPMN → propostes).
- **Automatització de tasques repetitives** — facturació, comandes, compres, seguiment de cobros (n8n + agents; clients reals de l'auditoria: facturació, cobros, compres).
- **Agents que treballen sols** — dediqueuen la part repetitiva del dia a dia (gestió de correus, seguiment, avisos).
- **Recordatoris i cobros automàtics** — el sistema avisa i recupera pagaments sense perseguir-los a mà.
- **Integració amb les seves eines** (gestor, CRM, web) — enlloc de canviar de sistema.

## 🕸️ 2. Webs i presència digital

**Insidr:** (pretén clients que necessiten presència + escalar).

**Els nostres serveis:**
- **Web professional** per al negoci (una web que converteixi visites en clients), amb disseny fet a mida (UI/UX Pro Max + web-kit).
- **Renovació de la web existent** — modernitzar la web vella sense perdre el que ja funciona (cloner AI de webs).
- **Chatbot a la web** — un assistent que respon els clients a l'instant sobre els serveis, preus i horaris (Dify).

## 📅 3. Agenda i reserves

**Insidr:** "Appointment booking" (part de l'embut).

**Els nostres serveis:**
- **Reserva de cites en línia** — els clients reserven hora directament, sense missatges perduts (Cal.diy).
- Recordatoris automàtics de la cita (per reduir no-show).

## 🎙️ 4. Comunicació i documentació

**Insidr:** (la seva web és tota comunicació).

**Els nostres serveis:**
- **Transcripció de reunions i trucades** — totes les reunions resumides i ordenades, privades (Meetily).
- **Docàs i informes professionals** — documents, informes i presentacions amb imatge de marca (pdf, docx, ppt-master).
- **Textos que no sonin "a IA"** — comunicació amb la veu real de l'empresa (no-ai-slop, humanizer).

## 📈 5. Visibilitat i creixement

**Insidr:** "Generate leads, nurture prospects and increase sales".

**Els nostres serveis:**
- **Auditoria SEO + IA (AEO)** — que la web aparegui en els cercadors tradicionals i en les respostes de la IA (open-seo).
- **Recerca de competidors i del sector** — què fan els rivals i quines oportunitats hi ha (Firecrawl + Scrapling).
- **Monitorització** — avisar-te quan canviïn coses rellevants (web dels competidors, preus, notícies) (changedetection.io).

## 🎬 6. Vídeo i contingut

**Insidr:** (els seus programes venen claredat i escala).

**Els nostres serveis:**
- **Vídeo de marca** — vídeos d'empresa fets per codi, sense cost de producció (Remotion).
- **Presentador virtual** — un avatar que explica el teu producte o oferta (Duix-Avatar; requereix GPU).

## 🩺 7. Consultoria i estratègia (el que Insidr cobra per aprendre)

**Insidr:** "AI Consulting — identify how AI can benefit your business" + programes de pagament.

**Els nostres serveis:**
- **Consultoria d'estratègia IA** — què es pot automatitzar i què no, amb prioritats.
- **Full d'impacte / ROI jugable** — quants estalvis i ingressos et portaria cada automatització, amb xifres.
- **Kit d'automatitzacions a mida** — les teves automatitzacions amuntades i documentades.
- **Formació (futur)** — ensenyar l'equip del client a fer servir el que hem muntat.

---

## Explicació per al client (en 1 frase cadascuna)

- **Automatització de processos** → "el dia a dia es fa sol, sense errors ni hores perdudes".
- **Webs** → "una web que et converteix visites en clients".
- **Agenda** → "que et reservin hora sense missatges".
- **Comunicació/documentació** → "reunions i documents ordenats i amb la teva imatge".
- **Visibilitat (SEO/AEO)** → "que et trobin tant a Google com a la IA".
- **Vídeo** → "vídeos de marca sense cost de producció".
- **Consultoria** → "saber exactament què automatitzar i quant et rendeix".

---

## Nota d'estratègia (interna, no per al client)

- Aquest llistat **creua el que Insidr ven com a cursos** amb el que NOSALTRES
  **podem lliurar realment** (eines instal·lades i verificades).
- Insidr et ven "com APRENDRE a fer-ho"; nosaltres **ho fem per tu** → avantatge
  clau al nostre posicionament: entreguem, no ensenyem (a menys que ho demanin).
- Els serveis 1-3 (automatització, webs, agenda) són els més concrets i venibles
  ara; 4-7 els més comercials/escalables.
