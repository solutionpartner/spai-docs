# Catàleg de productes SaaS per subscripció (construïts amb Abacus.AI)

Versió 1.0 · Generat per SolutionPartner.AI · 2026-11

> **Nota important (franquesa):** Abacus.AI és el MOTOR, no el producte que el
> client paga. El producte venible és cadascun dels verticals següents, que tu
> construeixes sobre Abacus com a backend/hosting i cobres per quota mensual.
> Per a PIME amb volum baix, el teu stack propi (n8n + Strapi + OpenRouter/Groq)
> pot ser MÉS BARAT que els crèdits d'Abacus. Cada fitxa ho marca.

**Llegenda cost:** 🟢 baix crèdits (text) · 🟡 mitjà (agents/workflows) · 🔴 alt (vídeo/apps+DDBB)
**Llegenda Abacus vs propi:** 🔧 Abacus aporta valor real · 🏠 més barat amb el teu stack

---

## A. Assistents verticals de PIME (més fàcils de vendre)

### 1. Xat comercial del client (copilot de negoci)
- **Què fa:** xat format amb els documents del client (catàleg, preus, FAQs, avisos).
- **Qui el compra:** comerços, serveis, clíniques.
- **Preu:** 30–80 €/mes.
- **Cost Abacus:** 🟢 · **Qui construeix:** DeepAgent + Knowledge Base + app.
- **Alternativa:** 🏠 n8n + Strapi + chat OpenRouter (recomanable per PIME).

### 2. Agent de facturació i cobraments
- **Què fa:** llegeix el gestor, recordatoris de cobrament escalonats, actualitza estat.
- **Qui:** gestories, autònoms, tallers.
- **Preu:** 60–150 €/mes.
- **Cost Abacus:** 🟡 · workflow + connectors + cron (SuperComputer).
- **Alternativa:** 🏠 ja ho fem amb n8n local.

### 3. CRM lleuger amb intel·ligència de client
- **Què fa:** fitxa de client, captura notes de trucades, categoritza, suggereix acció.
- **Qui:** PIME sense CRM.
- **Preu:** 50–100 €/mes.
- **Cost Abacus:** 🟡 · app full-stack + DDBB allotjada.
- **Alternativa:** ⚠️ hi ha molts CRMs barats; el valor és la part d'IA.

### 4. Assistent de terminis legals / administratius
- **Què fa:** rep la petició, vigila terminis, genera resposta esborrany, ho registra tot.
- **Qui:** procuradors, gestories, fornícules.
- **Preu:** 100–250 €/mes (valor alt: terminis).
- **Cost Abacus:** 🟡 · agent + workflow + supervisió humana abans d'enviar.

## B. Generació de contingut i màrqueting (SMB)

### 5. Gestor de tendències + contingut de xarxes (30 dies)
- **Què fa:** investiga el sector (X/Reddit/YT), genera calendari + esborranys, programa posts.
- **Qui:** consultores, agències, marques.
- **Preu:** 80–200 €/mes.
- **Cost Abacus:** 🟡 · agent recerca + generació + connector social.
- **Alternativa:** 🏠 la skill `last30days` (ja instal·lada) fa la recerca gratis.

### 6. Reporter d'impacte i KPI (informes mensuals automàtics)
- **Què fa:** munta informe mensual web/PDF i l'envia per correu.
- **Qui:** consultors, carteres de manteniment.
- **Preu:** 40–120 €/mes.
- **Cost Abacus:** 🟢 · agent + API.
- **Alternativa:** 🏠 tens motor propi (reporting/engine) — no cal Abacus.

## C. Dades i operacions (marge mitjà-alt)

### 7. Classificador d'entrades / intel·ligència de dades
- **Què fa:** estructura una fulla de dades, categoritza, marca incongruències.
- **Qui:** distribuïdors, fabricants, catàlegs.
- **Preu:** 100–300 €/mes.
- **Cost Abacus:** 🟡 · Structured ML + DeepAgent + dashboard de validació.

### 8. Resposta automàtica a pressupostos (llistats de preus)
- **Què fa:** consulta de client → pressupost estructurat (preus del catàleg), revisable.
- **Qui:** tallers, fornícules, serveis professionals.
- **Preu:** 60–200 €/mes.
- **Cost Abacus:** 🟡 · agent + taules preus + aprovació humana.

### 9. Triatge de queixes / reclamacions
- **Què fa:** classifica, prioritza i esborranya la resposta.
- **Qui:** empreses de serveis (atenció al client).
- **Preu:** 80–150 €/mes.
- **Cost Abacus:** 🟢 · agent.

## D. El que distingeix Abacus: apps i agents allotjats (SuperComputer)

### 10. Micro-app vertical allotjada (SaaS complet)
- **Què fa:** app web/mòbil allotjada per sector (reserves, seguiment de comanda) amb backend i DDBB.
- **Qui:** PIME que vol app sense equip tècnic.
- **Preu:** 150–500 €/mes.
- **Cost Abacus:** 🔴 · hosting integrat.
- **Abacus SÍ aporta valor real** (hosting+deploy integrat; amb el teu stack muntaries VPS/Strapi tu).

### 11. Agent sempre-actiu amb memòria (AutoBot / self-improving)
- **Què fa:** agent persistent (seguir leads, vigilar estocs, respondre WhatsApp) que millora amb el temps.
- **Qui:** negocis amb operació repetitiva.
- **Preu:** 200–600 €/mes.
- **Cost Abacus:** 🔴 · SuperComputer persistent.
- **Abacus SÍ aporta valor** · és la proposta de més marge però la menys "caixa negra": cal validar el comportament.

## E. Producte propi (no només per client)

### 12. Pack "web + IA" com a subscripció (model agència)
- **Què fa:** converteixes el model actual en producte: web amb Strapi + agent Abacus per sobre, tot en quota mensual (hosting+IA+manteniment).
- **Preu:** segons versió (baixa/mitjana/alta).
- **Cost Abacus:** 🟡 · segons versió.
- **Nota:** ja tens la demo web+Strapi construïda; Abacus afegeix el copilot/agent a les versions altes.

---

## Resum i recomanació d'inici

- **Validar i vendre ràpid:** #1, #2, #5 (els pots fer més barats amb el teu stack).
- **On Abacus realment paga:** #10 i #11 (app allotjada + agent persistent) — el
  SuperComputer t'estalvia muntar hosting tu.
- **Com a producte propi escalable:** #12 (el teu model d'agència com a subscripció).

**Pendent per a properes iteracions:** validar amb un pilot de cada idea, calcular
el cost real en crèdits Abacus per client/mes (per posar marge), i triar la primera
per construir i desplegar.