# Eines i repos revisats (notes de Josep)

Actualitzat: 2026-10-10

## SOS REPOS SERVEIS DE NEGOCI — clonats a /opt/data/tools-src/
- **Docuseal** (docusealco/docuseal) — alternativa open source a DocuSign:
  crea/emplena/signa documents PDF en línia, self-host (Docker), API/webhooks.
  **Servei: signatura de documents/contractes/propostes per a clients** sense
  DocuSign de pagament. Llicència AGPL+termes → verificar abans d'ús comercial.
- **Twenty** (twentyhq/twenty) — el CRM open source "pensat per a la IA"
  (alternativa a Salesforce, self-host, TypeScript/NestJS/Postgres), extensible
  "com a codi" i amb **skills oficials per a agents**. **Servei: CRM base per al
  Business AI OS / clients** (no substitueix el nostre erpsp; candidat quan un client
  necessiti CRM). AGPL.
- **Metabase** (metabase/metabase) — BI/analítica open source: preguntar a les dades
  i dashboards sense SQL (+ IA Metabot), self-host. **Servei: quadre de comandament/
  dashboards de KPIs per a clients** del Business AI OS. AGPL (open) + edició comercial.

## CANDIDAT PRIORITARI: every-app/open-seo (per a auditoria SEO + AEO)
- Alternativa open source (MIT) a Semrush/Ahrefs; self-host amb Docker o Cloudflare (recomanat).
- Workflows: keyword research, rank tracking, competitor insights, backlinks, site audits (SEO), i AI Visibility (AEO — prompts, competidors i citacions a Claude i Perplexity; encara en "prototype").
- MCP server + Agent Skills → connectable amb Hermes (ho diu el mateix README).
- **Cost**: OpenSEO gratis, però necessita API key de **DataForSEO** (de pagament, per ús). Hosted $10/mes.
- Rol: afegir a l'oferta una **auditoria SEO + AEO** que ara no tenim. Decidir cost DataForSEO i self-host abans d'instal·lar.
- **AEO** = Answer Engine Optimization / **GEO** = Generative Engine Optimization (el mateix). AIEO no és estàndard.

## Claude Code Kit — skills pel CLAUDE DE PROGRAMACIÓ (per passar-li)
- Directori: `/opt/data/claude-code-kit/` — README amb el propòsit de cadascuna.
- 10 skills: repomix (empaqueta repos en 1 fitxer), karpathy-skills (evita errors), beads (tracking entre sessions), graphify (graf codi+docs+SQL), archon (workflow repetible), awesome-claude-skills (directori comunitat), multica (assigna issues a agents), ECC (harness skills+memòria+checks), claude-code-router (enruta models), rtk (retalla sortida → estalvi tokens).
- Són per al CLAUDE DE PROGRAMACIÓ (no Hermes). **Escanejar seguretat per skill abans d'usar en projecte real** (regla de la casa).
- Font: newsletter Charlie Hills. Si el preguntem, recordar que existeix aquest kit.

## Eines RESERVADES (per al futur — enumerades aquí, l'estatus viu al fitxer)
- **impeccable** (pbakaus/impeccable, Apache 2.0, 78.9k★))— design language
  per audit de qualitat anti-slop de webs (23 comandaments: audit, critique, polish,
  distill, animate...; 46-59 regles deteccores deterministes). **PAS OBLIGATORI
  PRE-LLIURADA de webs**: la propera vegada que fem una web, instal·lar i usar
  (`npx impeccable install`, `/impeccable init` → `audit`), abans de lliurar[(complement)
  de ui-ux-pro-max: aquest dissenya, impeccable audita i poleix.).
  **ESTAT 2026-10-29: INSTAL·LADA i verificada** (v0.1.18 a .claude/skills/impeccable/
  + agents i hooks a .claude/; escaneig seguretat NET — només endpoints oficials
  github releases + impeccable.style; llegeix ANTHROPIC/OPENAI API key per al model).
  Ús: `/impeccable init` (una vegada) + `/impeccable audit` abans de lliurar.
- **Dify** (langgenius/dify) — plataforma open source d'apps LLM (RAG, chatbots,
  agents, workflows). **Servei: chatbots amb embed a les webs dels clients** (widget
  flotant sobre les seves dades). Docker Compose, self-host (VPS client o nostre),
  dashboard GUI. Llicència "Dify Open Source License" (base Apache 2.0 amb condicions
  addicionals) → **verificar termes abans de cada desplegament comercial**. No urgent;
  instal·lar quan un client demani un chatbot web.
- **Duix-Avatar** (duixcom/duix-avatar) — toolkit open-source d'avatars digitals /
  digital humans: vídeo d'una persona que parla amb veu clonada, offline, amb API oberta.
  **Servei: "vídeo amb avatar digital" per a clients** (presentador virtual, testimoni,
  agent). Requereix **GPU NVIDIA potent (RTX 4070, 32GB)** + Docker; NO és lleuger per
  VPS. Complementari a Remotion (aquest = vídeo per codi; Duix = persona digital que parla).
  No urgent; activar quan decidim oferir vídeos amb avatars (GPU pròpia o RunPod).
- **Presenton** (presenton/presenton, Apache 2.0, 11k★) — generador de presentacions
  AI open-source, alternativa a Gamma/Canva/Beautiful. App web + **API REST self-hosted**:
  POST amb `slides_markdown` → `.pptx`/`.pdf` amb templates visuals. Enfoc "templates
  bonics" ràpid. **Reservat/complementari**: ja tenim **ppt-master** (millor per a deks
  nadius editables de client). Presenton val la pena si volem presentacions estil-Gamma
  ràpides o una API de generació per a una app del Business AI OS.
- **Meetily** (Zackriya-Solutions/meetily, MIT, 31.5k★) — assistent de reunions
  AI **privacy-first**: transcripció en temps real (parla→text, Whisper/Parakeet) +
  resums amb IA, **tot local** (dades no surten de la màquina). App d'escriptori
  (Tauri, Rust+Next.js), mac/Win/Linux, AVX2 (no cal GPU), proveïdors d'IA: Ollama local,
  Claude, Groq, OpenRouter. **SERVEI PER A CLIENTS: "app de transcripció de reunions i
  trucades"** — instal·l-la a l'equip del client, les seves reunions transcrites i
  resumides localment (privadesa) → vendible com a servei. També útil per a ús INTERN
  nostre (resumir reunions amb client sense enviar dades al núvol). PRO (pagament) =
  funcions d'equip (self-hosted, speaker ID, GDPR). No urgent; activar quan el venguem
  o el facin servir internament.
- **OpenCode** (anomalyco/opencode, MIT, 212k★) — agent de codi IA open source  (terminal TUI + app d'escriptori), competidor obert de Claude Code/Codex. Lectura/
  escriptura de codi, execució, subagents, git. Suporta molts proveïdors. **Eina
  OPERATIVA INTERNA (no servei a client)**: és el nostre agent de codi. Avantatge clau:
  es pot autenticar amb **OpenRouter** (que tenim) → ens desbloqueja conduir tasques de
  codi (ppt-master, cloner de webs) sense pagar Claude. Ja tenim la skill `opencode`.
  Activar-lo connectat a OpenRouter quan necessitem un agent de codi.
- **AppFlowy** (AppFlowy-IO/AppFlowy, AGPL-3.0) — l'alternativa open source a Notion,
  workspace col·laboratiu (docs + bases de dades/kanban/taules + wikis + equip) amb IA
  integrada, self-hostable (control de dades). **Ús INTERN nostre**: el nostre workspace
  col·laboratiu self-hosted per gestionar projectes de clients i wikis de coneixement.
  Com a servei a client: potencial ("Notion privat al teu VPS") però **AGPL-3.0** — s'ha de
  verificar abans si és un servei al qual els clients accedeixin al nostre servidor.
  No urgent; activar com a workspace intern quan convingui.
- **Dograh** (dograh-hq/dograh) — plataforma de voice AI self-hosted (agents de veu,
  alternativa a proveïdors de pagament). **Servei potencial: assistents de veu per a
  clients** (atenció telefònica). Reservat; avaluar requisits (normalment GPU) abans.
- **gstack** (garrytan/gstack) — setup de 23 eines de Garry Tan (YC) per a Claude Code.
  Per al CLAUDE DE PROGRAMACIÓ (ja al claude-code-kit/gstack). No servei de client.
- **codex-plugin-cc** (openai/codex-plugin-cc) — usar Codex des de Claude Code per
  revisar/delegar (2 agents col·laboren). Per al CLAUDE DE PROGRAMACIÓ. Anotat, no cal
  instal·lar si no volem Codex actiu.
- **claude-hud** (jarrodwatts/claude-hud) — HUD de sessió (context/tools/agents en viu)
  per a Claude Code. Ús intern: monitoritzar el Claude mentre treballa. Al kit/al opcional.
- **Cal.diy / Caldiy** (calcom/cal.diy, **MIT**) — fork comunitari de Cal.com:
  infraestructura de **reserves/agendes ("scheduling")** open source. Els clients PIME
  que necessiten "reserva cita/trucada directa" a l'agenda (sense Calendly/Cal.com de
  pagament). **SERVEI PRIORITARI per a clients**: agenda de reserves en línia pròpia i de
  marca, self-host (Docker + PostgreSQL, VPS client o nostre), integrable amb la web
  (web-kit backend tipo reserva) i n8n (recordatoris). MIT = sense restriccions EE/AGPL
  (a diferència de Cal.com). Desplegament gran (Next.js+Postgres). No inclou funcions
  Enterprise (SSO/orgs) — no cal per a PIME. Instal·lar quan un client necessiti
  reserves/cites.
- **Coolify** (coollabsio/coolify) — PaaS open source self-hostable (alt. Vercel/
  Heroku/Netlify): desplega i gestiona apps, bases de dades i 280+ serveis d'1 clic
  al teu VPS (HTTPS automàtic, dominis, reverse proxy, backups, multi-servidor). **Eina
  OPERATIVA PRIORITàRIA**: la nostra capa de desplegament per gestionar tots els
  serveis de clients des d'un dashboard (web-kit, Cal.diy, Dify, n8n, bases de dades).
  **Repo clonat a /opt/data/coolify-src** (escaneig de seguretat NET: URLs oficials
  docker/coollabs, cap credencial real, cap eval). Instal·lador: scripts/install.sh
  (curl|bash a get.docker.com, coollabs CDN). Instal·lació real: quan toquem el
  desplegament multi-servei, al nostre VPS i replicable als de clients. free forever
  (auto-manteniment).
- **i-have-adhd** (ayghri/i-have-adhd, MIT, 56k★) — skill d'estil de RESPOSTA dels
  agents: acció primer, passos numerats, sense farciment ("no Hope this helps"),
  estàtercaç i una acció concreta al final. **Principi per als nostres agents** (Hermes,
  n8n) i com a **guia d'estil de sortida** per als chatbots/agents que muntem per a
  clients (directes, accionables, sense soroll. Instal·lada com a skill d'Hermes
  (productivity/i-have-adhd). Escaneig de seguretat NET (text de regles).
- **OmniRoute** (diegosouzapw/OmniRoute, MIT, 74.6k★) — AI gateway unificat: un endpoint,
  359+ providers. **UTIL NOMÉS configurat amb MODELS OFICIALMENT GRATUÏTS** (GLM-4.5 de
  Zhipu, Gemini free tier, Qwen, DeepSeek...) amb les NOSTRES claus. Mode "models de
  pagament gratis" (Claude/GPT "free") = ÀREA GRISA/frau → mai per a dades de clients.
  ⚠️ **REVISAR ABANS D'USAR**: verificar quina part del llistat "gratis" és oficial;
  configurar només amb models oficialment gratuïts; NO per a dades sensibles de clients
  (models de tercers, privadesa/retenció no garantida). Repo clonat a /opt/data/
  omniroute-src (910MB, escaneig NET: els os.system que surten son l'eina de seguretat
  del propi repo, no codi maliciós). No substituir OpenRouter per a tasques de qualitat/
  dades sensibles; complement per a tasques de baix cost (GLM/Gemini free) i estalvi.
- **Insidr.ai** (insidr.ai, WEB — no repo) — REFERÈNCIA COMERCIAL (no eina): plataforma  de formació/coaching en IA ("ajudem PIMEs a començar, automatitzar i escalar amb IA")
  amb programes de pagament, comunitat i un llistat de 500+ eines IA en 78 categories.
  **Ús: scrapejar-la per extreure idees de què oferir als clients** i com estructuren la
  seva oferta/venda (posicionament ~ al nostre: AI Strategy & Automation per PIMEs).
  Benchmark comercial per a la nostra carta de serveis i web de màrqueting. No aporta cap
  capacitat tècnica que no tinguem.
  ⭐ **AQUEST I LES ALTRES EINES = CATÀLEG DE SERVEIS POTENCIALS PER A CLIENTS** (llista
  completa al cap i al peu del fitxer: vídeo, chatbots, SEO+AEO, scraping, monitors, webs,
  decks, OCR, etc.).
- **Aceternity UI** (ui.aceternity.com — **WEB, NO repo de GitHub**) — biblioteca de
  **components web animats** (React+Tailwind+Motion) per a landing pages de qualitat.
  116+ components gratuïts (backgrounds, cards, text effects, 3D, carousels) + 180+ blocks/
  17 templates de pagament. Instal·lació: `npx shadcn@latest add https://ui.aceternity.com/registry/<component>.json`
  o copiar-enganxar. Té **MCP server** (perquè un agent d'IA cerqui i usi els components).
  **Font de components per a webs de clients** (complementa ui-ux-pro-max/motion-design/
  theme-factory). No es clona al kit (no hi ha repo); anotar com a font web, no com a repo.
  Free = els 116 components; blocks/templates = pagament. Ús comercial dels components:
  verificar llicència per component abans de lliurar a client.
- **transitions.dev** (Jakubantalik/transitions.dev, ★4.925, llicència pròpia: ús lliure personal
  i comercial, NO redistribuir la biblioteca com a producte) — 35 transicions CSS de producció
  (dropdown, modal, reveal, shimmer, hover tilt 3D, toast, skeleton, counters, accordion...). Ja
  **integrat a Hermes** com 3 skills `creative/`: transitions-dev (catàleg 35 + tokens motion +
  4 comandaments reveal/review/apply/refine), transitions-polish (puleix motion existent), i
  transitions-ui-generation (efecte "l'agent està generant la UI"). Escaneig NET. NOTA: té part
  "Pro" de pagament que NO s'ha tocat — només els snippets free del repo (els 35 del skill).
  ✓ **PROVA REALE (2026-10-11)**: reconstruït a mà (CSS+JS pur, adaptat a la marca blau nit+daurat)
  un efecte "aurora + particles" al hero de la web auditoria → publicat a solutionpartner.github.io/
  auditoria/ (commit 393b4dc). Patró: aurora rotativa (conic-gradient, blur clamp responsive) +
  espurnes flotants (canvas, ~30-70 punts) + shimmer a la paraula serif + spotlight de ratolí.
  Funciona en mòbil. Reversible (blocs marcats SP-AURORA/SP-PARTICLES).
- **Strix pentesting** (usestrix/strix, **Apache-2.0**, 67.9k★) — agents d'IA autònoms de
  **pentesting / hacking ètic**: recon → explotació → validació amb **PoC reals** (no falsos
  positius), multi-agent, auto-fix i reports de compliance. **SERVEI: proves de seguretat amb IA
  per a clients** ("auditem les vulnerabilitats del teu codi/app/web"). 2 maneres de córrer:
  (a) CLI self-hosted → `curl -sSL https://strix.ai/install | bash`, requereix **Docker + API LLM**
  (BYO key, ex. `STRIX_LLM="openrouter/z-ai/glm-5.3"`), escaneja local/GitHub/URL black-box;
  (b) núvol gestionat app.strix.ai → sense Docker/LLM, panells+reports PDF/DOCX, de pagament.
  ⚠️ El nostre host NO pot córrer Docker → usar-lo al VPS pare o PC de Josep (com Docuseal).
  **Escaneig NET** (el curl és l'instal·lador oficial; els api_key/password són paràmetres de
  funció d'adaptadors de LLM, no credencials; només escanejar allò que està autoritzat a provar).
  Descarregat a claude-code-kit/strix-pentest (15 MB). Complementa l'índex intern cybersecurity-skills.

## Kit 02 · OFERTA DE SOLUCIONES (desat 2026-10-12)
- **Què és**: segona peça de la sèrie SPAI — rep el **diagnòstic BPMN d'un client** (sortida del kit 01)
  i genera **l'oferta per al client** (PDF+HTML per àrees de negoci, mateixa marca i visor que el
  diagnòstic: com es treballa avui, problemes al pas exacte, solucions, economia) + **el dossier
  tècnic intern** (fonts amb huella, escandallo i marges, pla d'implantació, riscos).
- **On és**: `/opt/data/deliverables/kits/02-kit-oferta-soluciones/` (1.5 MB, escaneig NET:
  els "secrets" són fixtures de prova posats a propòsit; child_process = spawn local de Node/Chrome
  per als PDFs; cap exfiltració).
- **Com va**: Claude Code (VS Code, compte Pro) + Node ≥22.5 + Edge/Chrome. Comandaments `/setup
  /importar /oferta /estado /revisar` + skill oferta-solucions. "prepara la oferta de <client>".
- **Coses bones**: preus mai inventats (tot "pendiente" fins aprovar `tarifas.json` → "borrador no
  vinculante"); escàner de termes prohibits a l'oferta (cap jerga tècnica al client); "Business AI OS"
  com a base comuna; gestió d'estats completa (borrador→aprovada→enviada→negociació→signada) amb
  historial; BD SQLite local per client amb traçabilitat; exportació/restauració amb huella;
  35 tests (24 OK, 11 pendents de Fase B/C); parche opcional per igualar tinta amb kit 01.
- **PENDENT**: fer `/setup` al PC amb compte Claude i provar l'exemple de pràctica (Clima Moncayo).
- **Servei que habilita**: **ofertes d'automatització generades directament del diagBPMN del client**
  → el nostre motor comercial de sortida. Fase B = sync CRM; Fase C = implantació/facturació.

## Formulari web DIAGNÒSTIC DE PROCESSOS + generador (2026-10-12) — FLUX COMPLET MUNTAT
- **Web**: https://solutionpartner.github.io/diagnostic-processos/ (repo solutionpartner/diagnostic-processos).
  Estil 1B, mateixa clau Web3Forms → contact@solutionpartner.ai. Seccions: A empresa/contacte,
  B rols (dinàmic), C eines (dinàmic), **D processos amb PASSOS dinàmics** (nom/temps/a mà?/dolor),
  E seguretat/IA. Autoguardat localStorage. Genera `respuestas-unificadas/1` (format kit 01).
- **Botó a l'auditoria**: taronja estil Amazon, sota els exemples de mapres (commit 2288afa).
- **Generador**: `/opt/data/deliverables/kits/genera-diagnostico.py` (v2, GRAU COMPLET) — respostes
  JSON → carpeta entrada kit 02: diagnostico-fase1.json + BPMN (carrils per rol, gateways de decisions
  sí/no, message flows d'externs, colors: vermell=a mà, lila=decisió) + SOPs + **fitxes
  ficha-proceso/1 a modelo/** (nodes/flujos/mensajes — el que el kit vol per cobertura COMPLETA).
  Passos amb TIPUS (mano/eina/enviar/rebre/decidir), rol i eina per pas. PROVA FINAL: kit02 importa
  la sortida **✓ COMPLET × 2 processos, 0 contradiccions** (Fusta i Metall S.L. fictici, a _proves/).
- **RADIOGRAFIA** (entregable per vendre) — **CORREGIT 12/10**: el diagrama el dibuixa el MOTOR
  del kit, no dibuix a mà. Pipeline: `genera-diagnostico.py` (només fitxes vàlides `ficha-proceso/1`,
  àrees kit ventas/fulfillment) → `genera-diagramas.mjs` (colocar+generarXML → BPMN correcte →
  SVG vectorial via bpmn-js) → `genera-radiografia-v2.py` (HTML amb SVG incrustats) →
  `genera-radiografia-pdf.py` (PDF imprimeix l'HTML amb Playwright headless). Fitxa corregida:
  subtipo `ninguno`, decisió = `exclusiva` bifurcada Sí/No, participants únics, missatges
  node↔participant. PROVAT: CL-0001, 2 processos, PDF 4 pàgines amb 80-89 dibuixos vectorials/làmina.
- **REGISTRE CENTRAL DE CLIENTS**: `clients-bd.py` + `clients.db` (SQLite, SQL estàndard → fàcil
  de migrar a MySQL a la Fase B). Taules: `clients` (id CL-0001, nom, contacte, activitat, sector,
  estat) + `diagnostics` (processos, passos, a mà, hores/mes, rutes). Ordres: `nou <respostes.json>`
  (crea ID + carpeta + genera diagnòstic + radiografia + registra), `llista`, `mostra <id>`,
  `estat <id> <estat> [--nota]` (rebut|radiografia_feta|ofertat|client|descartat).
  Carpeta per client: `clients/<CL-XXXX>-<slug>/` amb respostes.json + diagnostic/ + radiografia.html.
  PROVAT: CL-0001 Fusta i Metall (2 processos, 81,2 h/mes, estat radiografia_feta).
- **FLUX COMERCIAL COMPLET**: client ompla formulari → ens arriba per Web3Forms → genera-diagnostico.py
  → **genera-radiografia.py (entregable al client)** → entrada kit 02 → "prepara la oferta de <client>"
  → oferta PDF + dossier intern. Proves a `_proves/entrada-test-v2` (Fusta i Metall S.L. fictici).

## FONTS D'INSPIRACIÓ DE WEBS (galeries curades — WEB, no repos)
Per al servei de webs: quan un client descriu l'estil que vol, consultar aquestes abans de dissenyar.
- **land-book.com** — inspiració de **pàgina sencera** (landing, portfolio, ecommerce, pricing, about),
  curada i actualitzada diàriament. Per definir l'estil global que vol el client.
- **navbar.gallery** — els millors **menús de navegació** (dropdowns, megamenu, sidebars, tabs,
  search, fullscreen). Quan el client diu "el menú el vull així".
- **cta.gallery** — els millors **call-to-action** (botons/CTAs conversió), filtrable per indústria.
  Per dissenyar el CTA "demana-ho".
- **footer.design** — la galeria de **footers** per excel·lència ("Editor's Choice").
Ús: treure PATRONS (no copiar codi aliena — copyright); alimenta design-dna / popular-web-designs /
web-kit + Aceternity per implementar. Cap s'instal·la: són webs de consulta.

## Eines INSTAL·LADES I VERIFICADES (2026-10-09)
- **UI/UX Pro Max** — skill d'intel·ligència de disseny (de nextlevelbuilder, MIT, escaneig de seguretat NET). Base de dades de estils/paletes/tipografia/UX + **Design System Generator**(genera sistema de disseny complet per a qualsevol projecte. Provat OK (genera sistema per a clínica dental amb patró, estil, paleta i tokens CSS). **Usar-la abans de construir qualsevol web de client** (o landing pròpia). Comandes: `python3 search.py "<query>" --domain <estil|color|tipografia|chart|ux|product>` i `python3 design_system.py "<projecte>"`, des del directori `skills/creative/ui-ux-pro-max/scripts/`.
- **ppt-master** — `/opt/data/ppt-master` (MIT v6.7.0, venv `tools/pptmaster-env`). Genera deks PPTX **nadius editables** (SVG → DrawingML): formes, taules/gràfics amb dades, transicions. Prova pilot OK (18 elements nadiu: 7 autoformes + 11 caixes de text). Flux: passar `attribution_guard.py` primer → `svg_quality_checker.py` → `svg_to_pptx.py`. Via "Quick" autònoma (la pot conduir Hermes). Amb Claude Code (no autenticat) es faria més disseny de qualitat. **Prioritari** per a deks de client.
- **Scrapling** — venv `tools/scrapling-env` (v0.4.15, BSD-3). Scraping Python amb stealth; complementa Firecrawl (llibreria pròpia vs API). Requereix eslint: `curl_cffi`, `playwright`, `patchright`, i extras. Fetcher no-JS provat OK (Fetched 200); per a navegador cal `playwright install` (Chromium). És la base de la skill `web-scraping`.
- **PaddleOCR** — venv `tools/paddleocr-env` (v3, models PP-OCRv6). OCR 100+ idiomes, PDFs escanejats → text per auditories i kit d'Oferta. Ús clau: `engine='onnxruntime'` (no cal el pesat paddlepaddle nadiu). Provat OK (llegí peu de correu). **Millora** el rapidocr que tenim a `/tmp/ocr_env`. Env per baixar models: `PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK=True`.

## Eines web RESERVADES (no urgents, instal·lar quan toqui)
- **Firecrawl** — search/scrape→Markdown; AGPL (self-host o núvol); recerca de competidors/sector d'auditories + monitors. Quan calgui més pressa, valorar self-host vs núvol.
- **browser-use** — agent que controla un navegador real (MIT); per a ACCIONS en portals de clients sense API (login, formularis, clics). Últim recurs quan no hi ha integració.
- **Remotion** — vídeo per codi (React); llicència COMERCIAL (paga); només si oferim "vídeos automàtics" com a servei per a clients.
- **cobalt** — baixar vídeo/àudio de URLs públiques; AGPL; per quan calgui un vídeo concret (no és part del sistema).

## MarkItDown (INSTAL·LAT 2026-10-09)
- Venv: /opt/data/tools/markitdown-env · llançador: markitdown.sh → ~/.local/bin/markitdown
- Converteix PDF/DOCX/office → Markdown. Usar `convert_local` (només fitxers locals, mai URIs).
- Rol: adaptador d'entrada del kit "Oferta de Soluciones" (PDF/DOCX → MD quan no hi ha fitxes JSON/BPMN).

## trycompai/crm — REFERÈNCIA d'arquitectura (NO instal·lar)
- CRM "agentic-first" (MIT), single-tenant per disseny (autorització "tothom ho veu tot") → no encaixa com a producte (nosaltres volem multi-tenant).
- **Idees a incorporar al nostre erpsp/crmsp:**
  1. **Ledger d'evidència** — no confiar en el "confidence score" del model; separar fet observat / suggerència / decisió humana. "Un fet equivocat sobre un client és pitjor que un camp buit."
  2. **API sense intel·ligència + cua d'esdeveniments** — l'agent lloga una fila de la cua i decideix què significa (observació ≠ acció). Trucar a una API d'enriquiment des del servei es considera un bug.
- Alineat amb la filosofia del nostre /operator (l'agent proposa, el supervisor aprova abans d'executar).

## 13/10 — Integracions noves a Hermes (del feed "For you" d'IA)
- **`book-to-skill`** (virgiliojr94, MIT, 34.6k★) → **skill Hermes** `research/book-to-skill` +
  CLI instal·lat a `tools/book-to-skill-env`. Converteix llibre/PDF → skill de coneixement.
  Proveït amb l'oferta de 54 pàgines (extreia 6.989 paraules). Path CLI:
  `/opt/data/tools/book-to-skill-env/bin/book-to-skill`.
- **`claude-ads`** (AgriciDaniel, MIT) → **skill Hermes** `marketing/claude-ads` (índex) + core
  instal·lat a `tools/claude-ads-core-env` (claude-ads-core: validate/score/portfolio/status/
  next/render/report/ingest-export). Sistema complet de paid media: 35 sub-skills de plataforma
  + core determinista → SERVEI d'auditoria/gestió de paid media per a clients. Read-only per
  defecte; canvis amb aprovació. Path CLI:
  `/opt/data/tools/claude-ads-core-env/bin/claude-ads-core`.
- Els 6 repos del feed (AutoHedge, Vibe-Trading, FinceptTerminal, Open-Generative-AI,
  book-to-skill, claude-ads) → **cloned a `claude-code-kit/` pel Claude de programació** (README
  actualitzat, total 40). Escanejats NET (instal·ladors whitelistim targets, sense injecció).

## 13/10 — REFERÈNCIES DE FLUXES D'EXEMPLE n8n (per a implementació)
Fonts de plantilles/fluxos n8n reals per consultar quan construïm les automatitzacions d'un client:
- **https://n8nworkflow.net/es** — directori de fluxos n8n amb botons d'importació i etiquetes (#manual/#complex, integracions, #gmailtrigger...). Útil per veure el PATRÓ VISUAL dels nodes n8n (nodes horitzontals amb ports d'entrada/sortida connectats pels punts — el format que hem adoptat als diagrames del dossier).
- **https://n8n.io/workflows/** — 12.404 plantilles oficials de la comunitat n8n, amb `/llms.txt` per llegir-les màquina. Inclou casos rellevants per a clients SPAI: facturació electrònica (EN 16931 / Factur-X / XRechnung), RAG sobre documents (Google Drive + Gemini), gestió de leads dental (Apify Google Maps → HighLevel CRM), enquestes CSAT per WhatsApp/Gmail. Format URL: `/workflows/<id>-<slug>/`.
- _Ús_: cercar una plantilla per part (ex. de facturació) abans de dissenyar un flux des de zero, i rescatar-ne el patró/orquestració. Les VENDREM com a disseny propi SPAI (mai copiades literalment).

## 13/10 — DISSENY D'IMPLEMENTACIÓ AL DOSSIER (el dossier passa a ser la GUIA TÈCNICA SUPREMA)
- **Nou `02-kit-oferta-soluciones/herramientas/genera-implementacion.mjs`**: llegeix
  `modelo/automatizaciones.json` → `modelo/implementacion.json` amb per automat: sistemes (tots
  `pendente_confirmar`), `disseny_flux` (disparador→passos→resultat), i `json_n8n` (workflow n8n
  exportable, format estàndard). Ús previ a generar: `node herramientas/genera-implementacion.mjs <cliente>`.
- **`dossier.mjs`**: nova secció **5bis** al dossier intern → taula sistemes client + disseny flux +
  JSON n8n incrustat (bloc `pre`; `@media print` per no tallar el JSON al PDF).
- **`oferta-html.mjs` + `plantillas/oferta.html`**: cada solució inclosa ara mostra una cadena visual
  **«Cómo funcionará»** en llenguatge de negoci (`PAS_NEGOCI`), des del `disseny_flux`. Pitfall: usar
  `fs.readFileSync` (no `readFileSync` sol, que el catch silencia i torna null sempre).
- **Formulari `diagnostic-processos-web/index.html`** (publicat commit `0acd7f4`): secció C ara
  pregunta pels SISTEMES — `sistema_principal` (ERP/CRM), `sistema_conexion`,
  `sistema_facturacion` (Verifactu), `sistema_contacto` (WhatsApp/correu), `sistema_nota`; recollits a
  `recollir()` dins `sistema`, amb datalist `dlSistemes`.
- **Versió actual clínica dental**: oferta **v8** (54 p, 7 cadenes «Cómo funcionará», cap terme intern)
  + dossier **v8** (57 p, 7 JSON n8n complets, 0 contradiccions).

## Paperclip (paperclipai/paperclip) — AVALUAT I INSTAL·LAT 2026-10-23 (OPERATIVA INTERNA)
- **Què és**: orquestradora d'agents IA (server Node + UI React). "Si OpenClaw és un
  empleat, Paperclip és l'empresa": assigna tasques, fa org chart d'agents humans+bots,
  controla pressupostos i objectius, govern amb gates d'aprovació. Bring-your-own-agents
  (OpenClaw/Claude Code/Codex/Cursor/Bash/HTTP).
- **Llicència**: MIT (paperclipai/paperclip, ~5.4k commits, actiu 2026).
- **Per a què ens serveix**: coordinar els NOSTRES agents (Hermes+Claude Code+Codex) en
  projectes de clients amb control de costos → operativa interna, NO servei a client PIME
  (els clients volen automatismes senzills, no 20 agents). Possible component del Business
  AI OS per clients que si creixin en agents.
- **Seguretat**: escaneig NET (0 credencials incrustades; executó de codi = regex String.exec
  benignes). **Telemetria opt-out per defecte → DESACTIVAR SEMPRE**: `PAPERCLIP_TELEMETRY_DISABLED=1`
  o `DO_NOT_TRACK=1` (packages/shared/src/telemetry/config.ts L71-76). Dades de clients només local.
- **Instal·lació provada OK al servidor (2026-10-23)**: `npx paperclipai@latest run` (telemetria OFF),
  mode `local_trusted`+`private` (no exposat), health OK (`localhost:3100/api/health`, v2026.1012.0),
  UI 200. Onboarding complert: companyia "SolutionPartner", agent "Cap d'operacions", dashboard
  `/api/companies/:id/dashboard` amb agents(active/running/paused/error), tasks(open/inProgress/blocked/done),
  costs(monthSpendCents/monthBudgetCents/utilization), runActivity. LLM: demana clau (Conecta un modelo) —
  treballa amb la nostra key OpenRouter com a model `openrouter/...`, posada a Configuració (no al codi).
- **Estat**: RESERVADA (instal·lada i provada, sense configurar agent real → activar quan vulguem
  orquestrar els nostres agents). Repo d'avaluació: /opt/data/cache/paperclip-eval. Servei de prova aturat.

## NOU 2026-10-29: builder-crm (diegovasquez-ai/builder-crm) — RESERVAT per a servei de clients
- CRM multicanal (WhatsApp + Instagram DM + Messenger en una bandeja) amb AGENT D'IA
  (OpenRouter) que califica leads, mou pipeline, registra activitats i deriva a persona.
  Una instància per client, adaptable amb l'arnés de Claude Code (spec → codi → deploy).
- Clonat a /opt/data/tools/builder-crm — PROVAT: mode local funcionant (Postgres embebit,
  health ok, pipeline operatiu). Llicència MIT (lliure per cobrar). Escaneig seguretat NET
  (sense telemetria, sense claus incrustades; crides només oficials: Zernio/Supabase).
- Per a instància real: Supabase (gratuït) + VPS/Coolify + Zernio (canals) + OpenRouter.
- PRODUCTE POTENCIAL (pendent de decidir): extreure l'agent de xat (WhatsApp + web) com a
  producte independent = "agent IA que respon, captura dades i deriva" (nucli src/lib/agent
  portable; cal buidar les tools del CRM i posar memòria lleugera).
- PENDENT quan hi tornem: (1) validar l'arnés amb una adaptació real (plantilla inmobiliària),
  (2) decidir l'extracció de l'agent com a producte.
