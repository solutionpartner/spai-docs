# Compliment del Reglament Europeu d'IA (RIA / EU AI Act) a SolutionPartner.AI

**Llenguatge planer, per a clients no tècnics. Ús: secció "Compliment / RGPD i IA" de les
webs (Business AI OS, auditories, diagnostico-procesos) i bloc final dels entregables.**

---

## PART A — Explicació de la RIA com si expliqués la RGPD

### Què és la RIA?
Igual que la RGPD va posar ordre al tractament de dades personals a Europa, el **Reglament
Europeu d'Intel·ligència Artificial (RIA)** — conegut com *EU AI Act* — posa ordre a l'ús de la
intel·ligència artificial. És la primera llei del món que regula la IA de manera completa i
transversal. Es va aprovar l'agost del 2024 i **s'aplica directament a tots els països de la UE**
(sense necessitat de cap llei espanyola que la tradueixi), igual que passava amb la RGPD.

### A qui obliga?
A **tothom que fa negoci amb la IA i la lliura a tercers**:
- els qui la **creen** (proveïdors),
- els qui la **instal·len o l'usen dins del seu negoci** (qui la desplega),
- i les **empreses que la reben** com a client final (pimes, autònoms).

Inclou des d'una **assessoria** que contracta una eina d'IA, fins a una **agència** que construeix
apps, webs, automatitzacions o RAGs per als seus clients, passant per qui ven la solució.

### Com funciona? Per nivell de risc (la idea clau)
La llei no regula la tecnologia en si, sinó **el dany que l'ús d'una IA pot causar a una persona**.
Com més risc, més obligacions. Hi ha quatre escales:

1. **Risc inacceptable** (prohibit): usos que manipulen, avaluen socialment o vulneren drets. **Prohibits des de febrer de 2025.**
2. **Risc alt**: IA que pren decisions rellevants sobre persones (selecció de personal, crèdit, educació, sanitat...). Aquí hi ha les obligacions més estrictes: gestió del risc, supervisió humana, documentació, registre. (Apliquen a partir de des. 2027 / ago. 2028).
3. **Risc limitat / transparència**: xatbots, assistents i contingut generat per IA. Obliga a **dir a la persona que està parlant amb una IA** i a **marcar el contingut sintètic**. **Ja és d'aplicació des del 2 d'agost de 2026.**
4. **Risc mínim**: la resta d'usos (l'immensa majoria de les eines de productivitat). Sense obligacions específiques, però amb la norma general: ús ètic i transparent.

### Què obliga concretament, per a una empresa com la nostra?
Tres coses ja en vigor que afecten qualsevol que usi IA amb clients:

- **Transparència (art. 50, des del 2/8/2026):** si una persona interactua amb un xatbot o una IA, cal **dir-li-ho** de manera clara abans o al primer contacte. Si generem **contingut sintètic** (textos, imatges, vídeos, veu amb IA), cal **marcar-lo** com a generat per IA.
- **Alfabetització en IA (art. 4, des del 2/2/2025):** qui construeix o fa servir IA ha de garantir que el seu equip té la **formació mínima** per usar-la de manera responsable.
- **No usar pràctiques prohibides (art. 5, des del 2/2/2025):** res de manipulació, «social scoring» ni usos que perjudiquin drets fonamentals.

### Sancions?
Igual que la RGPD té multes, la RIA també: fins a **35 M€ o el 7% de la facturació mundial**
anual per a les pràctiques prohibides; fins a 15 M€ o 3% per a la resta d'infraccions;
i 7,5 M€ o 1,5% per donar informació incorrecta. Per a pimes i autònoms, els imports
s'apliquen de manera proporcional i el règim és més lleuger (declaració simplificada i
taxes reduïdes), justament per no ofegar el teixit empresarial.

---

## PART B — Declaració de compliment de SolutionPartner.AI

> (**Text per a les webs i els entregables. Llenguatge planer, adhesionar com un tot.**)

### La nostra IA és ètica i responsable, i ho complim amb la normativa europea

A SolutionPartner.AI sabem que la confiança és la base de qualsevol relació amb els nostres
clients i els seus clients. Per això, tots els nostres productes i serveis —apps i RAGs,
automatitzacions, webs, auditories i consultories— es desenvolupen i lliuren **d'acord amb el
Reglament Europeu d'Intel·ligència Artificial (RIA / EU AI Act)** i, de retruc, amb la **RGPD**
en tot el que fa referència al tractament de dades personals.

**Som coneixedors de la normativa i la seguim a rajatabla.** En concret:

- **Transparència:** qualsevol sistema d'IA que interactua amb persones (xatbots, assistents,
  agents) **informa clarament que estàs parlant amb una IA** abans del primer contacte, i el
  contingut que generem **es marca com a generat per IA** quan cal.
- **Ús ètic i prohibit:** no desenvolupem ni despleguem cap ús de la IA que sigui manipulador,
  enganyós o que vulneri drets fonamentals (pràctiques prohibides de l'article 5). Tot el nostre
  treball està dissenyat per ajudar, mai per perjudicar.
- **Formació i alfabetització:** el nostre equip està format de manera contínua en ús
  responsable de la IA (article 4), perquè cada projecte es construeix amb criteri i
  responsabilitat.
- **Supervisió humana:** cap sistema que lliurem pren decisions automàtiques que afectin
  persones sense supervisió i control humà. La IA és una eina de suport; la decisió final i la
  responsabilitat professional sempre són humanes.
- **Proporcionalitat i documentació:** classifiquem cada sistema pel seu nivell de risc,
  documentem la solució i apliquem les obligacions que li corresponen, amb el règim més lleuger
  i adequat quan es tracta de pimes i autònoms (com preveu la pròpia llei).
- **Protecció de dades (RGPD):** complim la RGPD en tot moment: dades mínimes, finalitat
  clara, no entrenem models amb les dades dels clients sense consentiment, i posem la
  privacitat per disseny a cada solució.

**En resum:** construïm i lliurem intel·ligència artificial de manera **ètica, responsable i
completa amb la llei europea**, tant la RIA com la RGPD. Perquè no només volem que la nostra IA
funcioni: volem que ho faci bé, amb transparència i amb la confiança de qui la fa servir.

---

## PART C — Fitxa tècnica ràpida (data de referència: octubre de 2026)

| Concepte | Detall |
|---|---|
| Nom oficial | Reglament (UE) 2024/1689, el «Reglamento de Inteligencia Artificial» (RIA / EU AI Act) |
| Entrada en vigor | 1 d'agost de 2024 |
| Pràctiques prohibides + alfabetització | Des del 2 de febrer de 2025 |
| Obligacions models d'ús general (GPAI) | Des del 2 d'agost de 2025 |
| Transparència (art. 50) + potestats d'execució | Des del 2 d'agost de 2026 |
| Marcatge contingut generatiu (sistemes pre-existents) | 2 de desembre de 2026 |
| Alt risc Annex III (autònoms) | 2 de desembre de 2027 (reforma Ómnibus) |
| Alt risc Annex I (productes regulats) | 2 d'agost de 2028 |
| Multes | 35 M€ / 7% · 15 M€ / 3% · 7,5 M€ / 1,5% (facturació mundial anual) |
| Reforma Ómnibus Digital | Regl. (UE) 2026/1744, en vigor 27/7/2026 (posposa l'alt risc) |

**Implicació per a SPAI:** els nostres productes (RAGs, automatitzacions, webs, consultories)
se situen majoritàriament en **risc mínim / transparència**, per la qual cosa les obligacions
que ja ens afecten i complim són la **transparència (art. 50)**, l'**alfabetització (art. 4)** i
**no usar pràctiques prohibides (art. 5)**. El nostre propi assistent/chatbot de les webs ha de
declarar que és una IA (ja ho fa), i hem de marcar el contingut sintètic quan el generem.