# MEGA-PROMPT — Crea el kit «Oferta de Automatizaciones» (SolutionPartner.AI)

Pega tot aquest bloc al teu kit creador de kits de Claude (el que et genera un kit de
Claude Code complet i executable). L'objectiu és que generis un KIT NOU de Claude Code,
des del zero, amb tota la seva estructura (`CLAUDE.md`, `.claude/skills`, `herramientas/`,
`plantillas/`, `marca/`, `config/`, `entrada/`, `workspace/`), seguint exactament la mateixa
filosofia i ossos d'un kit de diagnòstic de processos que ja tenim (BPMN + SOP), però per a
**la fase comercial posterior**: convertir les sortides de l'auditor de processos en DOS
entregables — un **Document d'Oferta de Solucions** (per al client, sense informació tècnica,
amb preus) i un **document intern tècnic** (per a l'agència, amb les eines de cada
automatització, per guardar al repositori del client).

Llegeix primer el bloc «Filosofia del kit» i no et saltis cap norma de «No fer».

---

## FILOSOFIA DEL KIT (obligatori)

1. **És un kit de Claude Code, marca blanca i reutilitzable.** El consultor (usuari del kit)
   el fa servir per a cada client nou. El que veu EL CLIENT porta la marca de l'agència
   (nom, logo, colors blau nit #0B1D32 + daurat #E7C47D + tinta #14243A). El document intern
   és només de l'agència i pot anar sense marca o amb marca interna.
2. **Entrada = sortides de l'auditor de processos BPMN.** El kit rep (en `entrada/<cliente>/`,
   o enganxats al chat, o com a PDF/Word/Markdown) els documents que genera l'auditor de
   processos: el mapa de processos en BPMN (informe de diagnòstic, `diagnostico-fase1.json`,
   els SOP, els diagrames `.bpmn`, o el PDF/Word/HTML de l'informe de processos). El kit ha de
   saber llegir qualsevol d'aquests formats i extreure'n: client, àrees, processos, passos,
   **punts vermells** (on el propi equip va dir que falla o s'atasca), temps, freqüències,
   hores/mes, i la narrativa de cada procés.
3. **Sortida = DOS documents separats que es generen a la mateixa execució:**

   **A) DOCUMENT D'OFERTA DE SOLUCIONS** (deliverable O, `workspace/<cliente>/oferta/`):
   - Aquest és el que es lliura AL CLIENT. **NO pot contenir informació tècnica interna**:
     no es menciona MAI n8n, Make, Zapier, Cloudflare, Tailscale, MCP, dockers, tenants,
     API keys, llibreries ni cap eina de l'agència. Es parla en llenguatge de negoci.
   - Per a CADA procés de l'entrada hi ha UN bloc/sessió amb **dues sub-seccions**:
     (1) **«Problemas encontrados»** — recull els punts vermells / colls d'ampolla / malbaratament
     que va detectar l'auditor, en llenguatge planer i amb les hores/diners que costen.
     (2) **«Soluciones propuestas»** — quines automatitzacions es poden aplicar a aquell procés,
     amb un **dibuix/diagrama de la solució** (com quedaria el flux amb l'automatització) i una
     **explicació curta de quin serà el flux correcte de dades** (d'on surt la dada, com es
     processa, què passaria automàtic, què quedarà per a una persona).
   - A més, cada procés porta un **mini-diagrama resum** del procés BPMN actual (més petit) i un
     **llistat de les automatitzacions «futuribles»** que s'hi podrien aplicar.
   - **Oferta econòmica**: una secció final de preus amb 3 blocs:
       1. **Business AI OS** (la base): implementació/posada en marxa (preu fixe).
       2. **Cada automatització** (o paquet d'automatitzacions): preu d'implementació individual.
       3. **Servei mensual**: preu fixe mensual que depèn del **nombre d'automatitzacions
          implementades** (graella per trams, que el consultor configura).
   - **Format**: PDF professional acabat. S'ha de fer seguint els estàndards dels entregables
     professionals de l'agència: portada amb fons de color ple (blau nit) + marges interiors
     oberts (aire ~2,3 cm a tots els costats, contingut centrat), paràgrafs de to consultoria
     (estil KPMG/Deloitte) a TOTES les seccions, enllaços clicables quan apliquen, i un format
     semblant al de l'entrada (com l'exemple PorcoFarma: portada, resum en xifres, mapa, i per
     procés dues seccions, problemes + solucions amb diagrama). El PDF es genera des d'una
     plantilla HTML + conversió a PDF (WeasyPrint o Chrome headless). També es deixen els
     fonts (`.md` / `.html`) per si es vol retocar.
   - L'idioma del document d'oferta és el del client i del consultant (català o castellà),
     configurable, i sempre net i sense argot.

   **B) DOCUMENT INTERN TÈCNIC** (deliverable I, `workspace/<cliente>/intern/`):
   - Aquest és **només per a l'agència** i es desa a un **repositori del client** (carpeta
     `clientes/<cliente>/` o similar, segons el que configuri el consultor).
   - **SÍ que inclou la informació tècnica**: per a cada procés i cada automatització que es
     proposa, quina eina tecnològica (per exemple n8n, n8n+IA, i en general quina IA —model,
     proveïdor—, connexions amb MCP, bases de dades, webhooks, taules de cron, connectors de
     tercers, etc.), i amb quins passos tècnics es muntaria.
   - Resumen del client: dades bàsiques (nom, sector, àrees, nº de processos, nº de punts
     vermells, hores/mes estimades), quins processos té, quins punts vermells i quines
     automatitzacions se li poden fer, amb les eines.
   - Aquest document és la **fitxa tècnica** que permet a l'agència pressupostar, planificar i
     executar, i que es guarda per a futures fases (seguretat, hoja de ruta, manteniment).

4. **Reproduïbilitat i no inventar.** El kit NO inventa processos, ni passos, ni hores, ni
   problemes que no surtin de l'entrada. Tot el que proposa una automatització es basa en un
   punt vermell o un malbaratament detectable a l'entrada. Tot el que no està clar es marca
   com «per confirmar». Els preus els posa el consultor en config, mai el kit.

---

## ARQUITECTURA DE L'EXECUCIÓ (flux pas a pas)

El kit ha de treballar en passos amb el consultant, un cada vegada, i confirmar abans
d'avançar (com el kit de diagnòstic):

- **PAS 0 — Privacitat i entrada.** Llegir `entrada/<cliente>/` (fitxers .bpmn, .json,
  .md, .html, .pdf, .docx). Comprovar que no hi hagi dades personals de tercers ni secrets
  (el kit es para i avisa, com fa el kit de diagnòstic). Extraure l'estructura: client,
  àrees, processos, passos, punts vermells, temps, freqüències, hores/mes i narratives.
- **PAS 1 — Diagnòstic d'automatitzabilitat.** Per a cada procés, enumerar per a cada punt
  vermell / tasca manual / malbaratament: quina automatització (regla, integració, IA,
  agent) la resol, quina dada ha de circular, on s'origina i on acaba. **No es genera res
  tècnic encara** en aquest pas; només la llista d'oportunitats per procés.
- **PAS 2 — Revisió amb el consultant.** Abans de generar els documents, el kit presenta al
  consultant les oportunitats detectades (per procés: problema → solució proposada en una
  frase) perquè les validi, afini o descarti. El consultant pot editar la llista
  (`workspace/<cliente>/oportunidades.json`). No es genera res definitiu fins que el
  consultant dona OK.
- **PAS 3 — Generar els DOS documents.** Amb les oportunitats validades, el kit construeix:
  (a) el document d'oferta (deliverable O, en PDF+HTML+MD) i (b) el document intern tècnic
  (deliverable I, en MD i opcionalment HTML/PDF). Incorpora els mini-diagrames BPMN dels
  processos i els diagrames de les solucions.
- **PAS 4 — Entrega.** El kit explica al consultant què s'ha generat, on és cada cosa, i què
  ha de revisar abans d'enviar-ho al client. Si falta confirmar alguna cosa, ho marca com a
  «per confirmar» a la sessió de validació.
- **PAS 5 — Desar al repositori.** El document intern (I) es copia a la carpeta del client
  dins del repositori de l'agència, seguint la convenció que configuri el consultor.

---

## QUÈ HA DE CONTENIR CADA DOCUMENT (concret)

### A) Document d'Oferta de Solucions (deliverable O)

Estructura de seccions (ordre recomanat, seguint l'esperit de l'exemple PorcoFarma):

1. **Portada**: nom de l'agència, «Oferta de Solucions de Automatización», nom del client,
   data, estat («Propuesta para revisión»).
2. **Resum executiu en xifres**: nº de processos analitzats, nº de problemes trobats,
   hores/mes que s'hi poden estalviar (si surten de l'entrada), nº de solucions proposades.
3. **Resum dels problemes de fons**: què passa avui (malbaratament comú), en llenguatge
   de negoci, sense noms d'eines.
4. **Per a cada procés** (un capítol/bloc per procés), amb `Codi · Nom del procés`:
   - Mini-diagrama BPMN actual (el procés de l'entrada, reproduït a mida petita).
   - Sub-secció **«Problemas encontrados»**: els punts vermells del procés, en planer,
     amb les hores o diners que costen si l'entrada ho porta.
   - Sub-secció **«Soluciones propuestas»**: una o més solucions. Per a cadascuna:
     un **diagrama de la solució** (com quedaria el flux amb l'automatització, dibuix
     senzill i net) i una **explicació del flux correcte de dades** (d'on surt, cap a on
     va, què fa automàtic, què revisa una persona).
   - Llistat **«Automatizaciones futuribles»** (curtes, tipus llista de punts).
5. **Oferta econòmica**: els 3 blocs (Business AI OS base + automatitzacions + servei
   mensual per trams). Xifres que venen de `config/precios.json` (mai inventades).
6. **Condicions i següents passos**: com es desplega (en planer), garanties, próxims passos.
7. **Peu de marca** de l'agència.

Normes del document O:
- Zero informació tècnica. Prohibit: n8n, Make, Zapier, Cloudflare, Tailscale, MCP, Docker,
  terminis, API, etc. Si cal dir que «una màquina automàtica» ho fa, es diu així.
- Llenguatge consultora, net, sense argot, idioma configurable (ca/es/en).
- Càlcul d'estalvi només amb dades de l'entrada i operació a la vista; mai inventar.

### B) Document Intern Tècnic (deliverable I)

Estructura:
1. Fitxa del client: nom, sector, àrees, data, contacte (si el consultant el posa).
2. Resum de processos i problemes (d'on surten les automatitzacions).
3. **Taula de solucions tècniques**: per a cada procés → automatització proposada →
   **eina/es** (per exemple n8n, n8n+IA amb model X, gegant via node APIs, MCP, cron,
   webhooks, connectors, base de dades, etc.) → grau d'esforç (b/M/A) → valor.
4. **Fitxa per automatització**: què fa, quina dada consumeix, quina genera, amb quines
   eines es connecta, quins passos tècnics de muntatge, quins permisos/accés calen, si
   necessita IA i de quin tipus (extracció, text, classificació, agent), si toca un ERP i
   com, si hi ha MCP implicat i amb què.
5. **Consideracions de seguiment/manteniment** i «per confirmar» (el que l'entrada no deixa clar).
6. Ubicació al repositori: `clientes/<cliente>/` (o el que configuri el consultor).

Normes del document I:
- Aquest SÍ porta la informació tècnica. És la font per pressupostar i executar.
- No s'inventen eines ni integracions: el consultor les valida al PAS 2 - PAS 3, i el kit pot
  oferir un catàleg de solucions tipus (a `data/automatizaciones-tipo.md`) **que el consultant
  edita**, no que el kit assumeixi a cegues.

---

## CATÀLEG DE SOLUCIONS TIPUS (el kit l'ofereix, el consultant l'edita)

El kit inclou un fitxer editable `data/automatizaciones-tipo.md` amb un recull de solucions
recurrents per a pime (a tall de catàleg, mai automàtic): per exemple —

- «Registro de pedidos en ERP desde múltiples canales (WhatsApp, email, web)» → n8n + conector
  API del ERP + (opcional) IA d'extracció dels camps → document O parla de «registro
  automático desde cualquier canal»; document I detalla n8n + API + model d'extracció.
- «Confirmación de existencias y precios al momento» → n8n + consulta a l'ERP + resposta per
  WhatsApp/email amb IA que redacta → O parla de «respuesta al instante»; I detalla n8n,
  la missatgeria i la IA de redacció.
- «Avisos y recordatorios de cobro» → programador (cron) + n8n + email/WhatsApp + seguiment →
  O parla de «recordatorios automáticos»; I detalla la rutina programada i els connectors.
- «Preparación de pedidos: validación de lotes y albaranes» → n8n + escaneig/ocr de documents
  + cruce amb l'ERP → O parla de «validación automática»; I detalla l'OCR/n8n/ERP.
- «Compras a proveedores: consulta de disponibilidad y pedido automático» → n8n + correu/portal
  del proveïdor + IA de propostes → O parla de «pedido a tiempo»; I detalla els connectors.
- «Facturación: generar y enviar la factura» → n8n + plantilles PDF + confirmació per email →
  O parla de «factura preparada y enviada»; I detalla l'eina de PDF i el correu.
- «Agente / asistent de IA per atendre consultes» → agent IA amb accés a unes eines concretes i
  supervisió humana → O parla de «asistente que responde y deriva»; I detalla l'agent, el
  proveïdor de model, les eines (MCP si aplica) i les regles de supervisió.
- I els que el consultant afegeixi.

Regla: el catàleg és un **recull per inspiració**, mai una resposta automàtica. El consultant
tria i edita per a cada client; res no es proposa a un client sense passar pel PAS 2.

---

## MARCA I CONFIG (obligatori)

- `marca/marca.json` amb: nom de l'agència, telèfon/web/email, colors (primary #0B1D32,
  accent #E7C47D, tint #14243A), logo optional (data-URI), idioma per defecte per al client.
- `config/precios.json` editable amb els 3 blocs d'oferta econòmica:
  - `business_ai_os_base` (preu d'implementació del Business AI OS),
  - `automatizacion` (preu per automatització o una llista per complexitat b/M/A),
  - `mensual` (trams: preu mensual segons el nº d'automatitzacions, per exemple
    «1-3 → X €/mes», «4-6 → Y €/mes», «7+ → Z €/mes»).
  - `moneda` i `impuestos` (per si s'han d'indicar).
- El document d'oferta usa la marca i els preus de config. Mai un altre número.

---

## GENERACIÓ DEL PDF / VISUALS (obligatori)

- El kit genera el document d'oferta (O) des d'una **plantilla HTML** (`plantillas/oferta.html`)
  on injecta els continguts amb marca, i després el converteix a **PDF** amb WeasyPrint o
  Chrome headless (el que funcioni a l'entorn i sense depender d'internet).
- Els **diagrames BPMN** (mini-del-procés i diagrama-de-solució) es poden generar com a SVG
  integrat al HTML (millor per al PDF) o reproduir amb bpmn-js al HTML interactiu. Per al PDF
  final, el que ha de quedar és el dibuix vectorial o una captura en bona resolució.
- El document intern (I) es genera en **Markdown** (i opcional HTML). Es deixa com a fitxers
  `.md` perquè és la font d'execució.
- Qualitat: el PDF ha de ser professional — portada blava, marges oberts, paràgrafs de
  consultora, enllaços clicables si apliquen, taules netes, cap element tallat.

---

## STRUCTURA DE FITXERS QUE HA DE GENERAR EL KIT

```
kit-oferta-automatizaciones/
├── EMPIEZA-AQUI.md · README.md · CLAUDE.md
├── .claude/
│   ├── commands/         setup · marca · oferta · intern
│   └── skills/oferta-automatizaciones/
│       ├── SKILL.md      el mètode pas a pas (el teu cos)
│       └── referencias/  llegir-entrada.md · oportunitats.md · doc-oferta.md ·
│                          doc-intern.md · preus.md · automatizar-tipo.md
├── herramientas/          llegir-entrada · oportunitats · generar-oferta · generar-intern ·
│                          diagrames · pdf · (i els seus motors: model, sop, comun)
├── plantillas/            oferta.html · intern.html · visor-bpmn (si aplica) · estils pdf
├── data/                  automatizaciones-tipo.md · catalogo-soluciones.json
├── config/                precios.json
├── marca/                 marca.json i logo
├── entrada/               sortides de l'auditor per client (una carpeta per client)
├── ejemplos/              un client de pràctica (sortides d'exemple d'un auditor)
└── workspace/             una carpeta per client amb oferta/ i intern/
```

## REGLES DE COMPORTAMENT DEL KIT (com el kit de diagnòstic)

- Un pas a la vegada, espera la confirmació, explica en cristiano, sense jerga.
- No assumeix que una comanda ha funcionat: llegeix la sortida i confirma o arregla.
- Si hi ha un error, calma i solució concreta; no fa sentir ximple el consultant.
- Parlar en l'idioma configurat (per defecte català o castellà del consultant).
- **No inventar res**: ni processos, ni problemes, ni hores, ni preus, ni eines que no
  surtin de l'entrada o de la configuració consultor.
- Privacitat: entrada/ i workspace/ no es comparteixen; res es puja a cap lloc.
- Seguretat: si apareixen secrets o dades personals a l'entrada, aturar-se i avisar.
- Els preus només des de `config/precios.json`; el document d'oferta no inventa xifres.
- El document d'oferta NO porta informació tècnica. El document intern SÍ.
- Cada client = carpeta pròpia a `entrada/` i `workspace/`. El document intern (I) es desa
  al repositori de clients de l'agència segons convenció configurada.

## QUÈ HA DE VERIFICAR EL KIT EN ACABAR (checklist)

- [ ] Ha llegit l'entrada real del client (no inventada).
- [ ] Els problemes de cada procés provenen dels punts vermells de l'entrada.
- [ ] Cada solució té diagrama + explicació del flux de dades.
- [ ] L'oferta econòmica surt íntegrament de `config/precios.json`.
- [ ] El document d'oferta NO conté cap nom d'eina interna (n8n, Make, Cloudflare,
      Tailscale, MCP, Docker, API…). Comprova-ho amb un escaneig abans de lliurar.
- [ ] El document intern SÍ conté l'arquitectura tècnica de cada automatització.
- [ ] El PDF s'ha generat i s'obre bé; cap element tallat; enllaços clicables si calen.
- [ ] El document intern s'ha desat al repositori del client.

---

## EXEMPLE DE REFERÈNCIA (per entendre el format del que volem emular)

L'exemple és un informe de diagnòstic de processos (com el que genera l'auditor de
processos que tens, estil PorcoFarma): portada amb marca, resum en xifres, mapa general,
i per a cada procés: el diagrama BPMN, «lo que dice el mapa» (senyals i hores/mes), el
procediment (SOP) i «por confirmar». El nostre kit d'oferta ha de mantenir aquesta
família visual i d'estructura (portada, resum, per-procés amb sub-seccions) però per al
propòsit comercial: en comptes de «lo que dice el mapa» → «Problemas encontrados», i en
comptes de només el mapa → afegeix «Soluciones propuestas» amb diagrama de solució i flux
de dades, i l'oferta econòmica al final.

---

## NOTA FINAL

Genera el kit complet i funcional, amb un `README.md` curt i clar que expliqui com fer-lo
servir de principi a fi, i amb un **client d'exemple** a `ejemplos/` (unes sortides d'un
auditor d'exemple, potser les de PorcoFarma si caldrà, o un cas fictici net) perquè el
consultor pugui practicar abans de fer servir el kit amb un client real.