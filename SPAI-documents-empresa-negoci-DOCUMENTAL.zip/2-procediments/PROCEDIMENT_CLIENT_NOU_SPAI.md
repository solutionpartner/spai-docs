# PROCEDIMENT SPAI — Client nou de cap a cap
## De l'auditoria global a l'oferta d'automatitzacions (guia pas a pas)

**Versió:** 1.0 · 26/10/2026 · Provat amb CL-MAT-001 (Mataró, real) i CL-PROVA-001
(Forneria del Barri, prova). Aquest document és la guia operativa; el detall tècnic
fons viu a les skills d'Hermes (`diagnostic-processos-pipeline`,
`diagnostic-processos-a-oferta`, `auditoria-empreses`).

---

## 0. Visió general (els 4 entregables i 3 circuits)

Per a cada client es generen **4 entregables**:

| # | Entregable | Circuit | On es genera |
|---|-----------|---------|--------------|
| 1 | **PDF Auditoria Global** (47 pàg, DAFO+findings+roadmap) | A · Auditoria global | `audit-system/audita.py --tot` |
| 2 | **Web Auditoria Global** (25 seccions, autocontinguda) | A · Auditoria global | `audit-system/` + `empaquetar.py` |
| 3 | **PDF Radiografia BPMN** (processos amb diagrames bpmn-js) | B · Processos BPMN | `deliverables/kits/` (kit01) |
| 4 | **PDF Oferta Automatitzacions** (resultat kit02) | C · Oferta | `02-kit-oferta-soluciones/` (kit02) |

Ordre recomanat: **A → B → C** (l'auditoria global dona el perfil; el BPMN dona
els processos; l'oferta es construeix sobre els dos).

**Regla transversal:** dades REALS, mai inventades. Els preus surten «pendiente»
fins que `config/tarifas.json` i `config/prestador.json` tinguin valors (decidits
per Josep, no pel sistema).

---

## 1. Requisits previs (una sola vegada)

Entorn operatiu (host Linux, `/opt/data`):

```bash
# Motor d'auditoria global
cd /opt/data/.claude/audit-system
.venv/bin/python --version        # venv amb tots els paquets (pypdfium2, PIL...)

# Kit 01: diagrames BPMN + radiografia (necessita chrome-headless del kit)
cd /opt/data/deliverables/kits
node genera-diagramas.mjs --help  # Node, bpmn-js del kit

# Kit 02: oferta
cd /opt/data/deliverables/kits/02-kit-oferta-soluciones
node herramientas/importar.mjs --help

# Chromium headless (PLAYWRIGHT_BROWSERS_PATH) per imprimir PDFs
ls /opt/data/tools/.pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell
```

Verificació ràpida que tot funciona: generar un client de PROVA (sector qualsevol,
3-4 processos) seguint els passos d'aquesta guia — si surt amb 0 contradiccions i
`✓ Análisis coherente`, l'entorn està bé.

---

## 2. CIRCUIT A — Auditoria global (PDF + Web)

### A.1. Crear el JSON bàsic del client

Fitxer: `templates/<acronim>.json` (ex. `forneria_barri.json`, `perruqueria_mataro.json`).

Contingut mínim (dades reals del client):
- `client`: `nom`, `acronim`, `sector_kb` (ha d'existir a `sector_kb.db`), `pais`,
  `sector_desc`, `adreca`, `empleats`, `facturacio_any`, `marge`, `volum`,
  `pressupost`, `diferencial`, `subtitle`
- `dolors` (llista de frases reals), `objectius`, `eines`, `competidors`
  (tuples de 4: nom, descripció, presència digital, puntuació 1-10)

Si el sector no està a `sector_kb.db`, afegir-lo amb
`sector_kb.save_sector(sector, kpis, art=..., fonts=..., pais='es')`.

### A.2. Completar amb el judici (el JSON final)

Fitxer: `templates/<acronim>_complet.json` — còpia del bàsic + les 36 claus
d'anàlisi (dafo, findings, matriu_prioritzacio, roadmap, xifres, beneficis,
nomes_beneficis, maduresa_d1d6, maduresa_sector, opcions, kpis_seguiment,
dashboards, riscos, impacte_arees, resum_final, estat_art, gartner_lead,
ranking_lead, digital, governanca, impacte_social, governanca_corporativa,
proximes_passes, annex_c_arees, recomanacio_annex_e, faq...).

> ⚠️ **FORMATS EXACTES OBLIGATORIS** (el motor PETA silenciosament si no hi són):
> - `maduresa_d1d6` → **tuples de 3**: `["D1 Estratègia i lideratge", 1, "desc"]`
> - `opcions` → **tuples de 5**: `["A", "Títol", "cost", "desc", "pro/con"]`
> - `proximes_passes` → **tuples de 3**: `["Acció", "Responsable", "criteri"]`
> - `nomes_beneficis` → **tuples de 3**: `["8.000 €/any", "Benefici", "Cost actual"]`
> - `dashboards` → **dict**: `{"avui": [...], "demà": [...]}`
> - `annex_c_arees` → **dict** àrea → `[text_abans, text_després]`
> - `impacte_arees` → **tuples de 3**: `["Àrea", "Acció", "Impacte"]`
> - `kpis_seguiment` → **tuples de 3**: `["KPI", valor_num, "augmentar|reduir"]`
> - `gartner_lead` i `ranking_lead` → **strings** (paràgrafs), NO nombres
> - `findings` → **8 elements**: `[id, títol, TIPUS, et1, et2, et3, desc, termini]`
> - `matriu_prioritzacio` → **5 elements**; `riscos` → **2**; `roadmap` → **4**;
>   `competidors` → **4**
>
> Patró de referència que VALIDA: `templates/perruqueria_mataro_complet.json`.
> Error típic: `ValueError: too many values to unpack` → un camp és una llista de
> tuples amb un nombre d'elements diferent del que espera el motor.

La generació del judici es pot fer amb l'agent expert (skill `auditoria-empreses`):
`templates/expert_judici_prompt.md` + `brief.py`. Per a una prova, el judici es pot
derivar directament dels dolors/objectius/eines (judici mecànic).

### A.3. Generar els 4 entregables analítics + web + PDF

```bash
cd /opt/data/.claude/audit-system
./.venv/bin/python audita.py --from templates/<acronim>_complet.json --tot --lang ca
```

Sortida esperada:
- `deliverables/<acronim>.xlsx` (7 fulles) i `deliverables/<acronim>-impacto.xlsx`
- `deliverables/<acronim>-informe.html` (web 25 seccions)
- `deliverables/<acronim>-informe.pdf` (PDF, ~47 pàg quan el JSON és complet)

> El camí OFICIAL és `audita.py --from ... --tot`, que usa `gen_web_full` (25
> seccions). NO usar `gen_informe2.py` directe.

### A.4. (Opcional, premium) Imatges de secció + logo + gràfics rics

```bash
cd /opt/data/.claude/audit-system
./.venv/bin/python gen_images.py "<Nom Empresa>" "<sector>"   # imatges d'IA per secció
./.venv/bin/python stamp_logo.py                               # logo SolutionPartner
./.venv/bin/python gen_gartner_chart.py
./.venv/bin/python gen_kpis_chart.py templates/<acronim>_complet.json
./.venv/bin/python post_html.py <acronim>
```

(cadascun idempotent; si ja les té, no es regeneren)

### A.5. Empaquetar la versió AUTOCONTINGUDA (la que es lliura)

```bash
./.venv/bin/python empaquetar.py <acronim> --web
# → deliverables/paquets/<acronim>/informe-web-autocontingut.html (logo + imatges en base64)
#   els altres entregables (pdf, xlsx...) dins la mateixa carpeta
```

La versió autocontinguda és la única que es veu bé en moure el fitxer (la relativa
`informe-web.html` té paths a `charts/` que es trenquen).

**Verificació:** obrir l'HTML autocontingut → totes les imatges carreguen; el PDF
s'imprimeix bé (render de portada i de 2-3 pàgines interiors).

---

## 3. CIRCUIT B — Radiografia BPMN (PDF de processos)

### B.1. Crear el JSON BPMN del client

Fitxer: `templates/<acronim>_bpmn.json` — format `processos_bpmn`:

```json
{
  "client_id": "CL-XXXX-001",
  "client_nom": "Nom del Client",
  "data_auditoria": "26/10/2026",
  "processos_bpmn": [
    {
      "id": "PR-001",
      "nom": "Nom del procés",
      "frecuencia": "N cops/dia",
      "tiempo_ciclo": "X min",
      "actors": ["Rol intern", "Client"],
      "pasos": [
        {"num": 1, "desc": "Descripció del pas", "tipo": "manual", "actor": "Rol",
         "problema": "Dolor/ineficiència en aquest pas (opcional)"},
        ...
        {"num": 5, "desc": "Fi del procés", "tipo": "fin"}
      ],
      "ineficiencias": ["Resum de les ineficiències del procés"]
    }
  ]
}
```

Regles: cada pas té `tipo` (manual/decision/envio/rebre/fin + actor), i els passos
amb `problema` generen els dolors (hallazgos) més endavant. Si cap pas és `fin`,
l'adaptador hi afegeix un automàticament.

### B.2. Generar el config del client (la part intel·lectual)

Fitxer: `02-kit-oferta-soluciones/configs-clientes/<id>.json` (ex. `cl-mat-001.json`,
`cl-prova-forneria.json` — patrons de referència).

Conté (TOTA la part que és judici de consultor):
- `client_nom`, `activitat`, `sector`, `equipo` (rols+persones), `herramientas`
- `area_de`: mapa `PR-### → àrea` (ventas/administracion/fulfillment/marketing)
- `categoria_hallazgo`: per procés (enum vàlid: transcripcion, duplicados,
  notificaciones, conciliacion, seguimiento, dependencia_persona...)
- `area_negoci`: per procés → `{"primary": "VEN|OPE|CLI|FAC|...", "related": [...], "just": "..."}`
- `automatitzaciones` (o `automatizaciones` — accepta les dues claus): llista d'AUT
  amb `id`, `procs`, `prio` (1-5), `fase`, `pattern`, `systems`, `incluida`,
  `title`, `benefit`, `desc`, `team`, `crit`, `journey`
- `aut_per_proces`: `{"VEN-01": "AUT-RES-01", ...}`
- `despres_per_node`: per procés → `{"p2": "Nom del pas al TO BE", ...}`
- `escandallo`: per AUT → `{"horas": {...}, "contingencia_pct", "justificacion_contingencia"}`
- `oferta`: `titulo`, `referencia`, `resumen_ejecutivo` (objectius+propuesta),
  `fases`, `responsabilidades_cliente`, `requisitos_cliente`, `limites_servicio`

> El config es crea UNA vegada per client. És la peça que canvia entre clients.

### B.3. Adaptar el JSON BPMN a fitxes + generar diagrames + radiografia

```bash
cd /opt/data/deliverables/kits/02-kit-oferta-soluciones

# PAS 1 — fitxes ficha-proceso/1 + diagnostico-fase1.json (a una carpeta temporal)
/opt/data/.claude/audit-system/.venv/bin/python genera-diagnostic-oferta.py \
  --client <id> --bpmn /opt/data/.claude/audit-system/templates/<acronim>_bpmn.json \
  --config configs-clientes/<id>.json --kit01-dir /tmp/<acronim>_kit01

# Diagrames BPMN amb el MOTOR del kit (bpmn-js) — MAI a mà
cd /opt/data/deliverables/kits
node genera-diagramas.mjs /tmp/<acronim>_kit01
# esperat: "N fichas válidas → dibujando con bpmn-js… ✓ <CODI>.bpmn + <CODI>.svg" per CADA procés

# Radiografia HTML (incrusta els SVG)
/opt/data/.claude/audit-system/.venv/bin/python genera-radiografia-v2.py \
  /tmp/<acronim>_kit01 --sortida /tmp/<acronim>_kit01/radiografia-procesos.html

# PDF de la radiografia (impressió headless)
export PLAYWRIGHT_BROWSERS_PATH=/opt/data/tools/.pw-browsers
/opt/data/tools/scrapling-env/bin/python genera-radiografia-pdf.py \
  /tmp/<acronim>_kit01/radiografia-procesos.html --sortida <ENTREGA>/..._Processos_BPMN.pdf
```

**Pitfalls coneguts (tots documentats a la skill `diagnostic-processos-pipeline`):**
- Si `genera-diagramas.mjs` diu «3 fichas válidas» quan n'hi ha 7 → falta l'event
  `fin` en alguns processos (comprovar amb `comprobarFicha`).
- `equipo` i `herramientas` (arrel) al diagnostico han de ser LLISTES DE DICTS
  (no strings) — l'adaptador ja ho fa.
- Mai entregar diagrames fets amb Mermaid/weasyprint: el client vol bpmn-js.

**Verificació:** el PDF de la radiografia té 1 làmina per procés amb el diagrama
BPMN (es veuen pages de 50-100 dibuixos vectorials per làmina amb PyMuPDF).

---

## 4. CIRCUIT C — Oferta d'automatitzacions (kit02)

### C.1. Importar l'expedient al kit02

```bash
cd /opt/data/deliverables/kits/02-kit-oferta-soluciones
node herramientas/importar.mjs /tmp/<acronim>_kit01 --cliente <id> --nombre "Nom del Client"
# esperat: "N processos ✓ completa · Pendientes: 0 · Contradicciones abiertas: 0"
# (els svg/*.svg es bloquegen per DOCTYPE — normal, els diagrames es regeneren)
```

### C.2. Generar l'anàlisi (hallazgos, areas, AUT, to-be, escandallo, oferta)

```bash
# PAS 2-5 (SENSE --kit01-dir: treballa sobre l'expedient importat)
/opt/data/.claude/audit-system/.venv/bin/python genera-diagnostic-oferta.py \
  --client <id> --bpmn templates/<acronim>_bpmn.json --config configs-clientes/<id>.json
# esperat: hallazgos.json (N) · areas.json (N) · automatizaciones.json (N AUT)
#          to-be/ generats · escandallo.json + oferta.json
```

### C.3. Validar

```bash
node herramientas/validar.mjs <id>
# esperat: "✓ Análisis coherente" (els avisos "!" d'estil NO bloquegen)
```

Si hi ha errors ✗, revisar (els més freqüents):
- `AUT apunta al proceso X, que no existe` → el config i l'`area_de` no quadren
  (els codis de procés del config han de coincidir amb els generats a B.2)
- `cita AUT-XXX, que no existe` → to-be antics (neteges a C.2) o `aut_per_proces`
  apuntant a una AUT que no està a `automatitzacions`
- `evidencia fuente: SRC-XXX no sigue el formato` → usar sempre `SRC-###` numèric

### C.4. 🛑 PAUSA OBLIGATÒRIA — la cartera

**Mostrar a Josep la cartera d'automatitzacions** (taula: ID, títol, processos que
resol, prioritat) i **preguntar què entra** a l'oferta (`incluidas`) i què queda per
a més endavant (`futuras`). És decisió d'SPAI, no del sistema. Editar si cal:
`configs-clientes/<id>.json` → `"incluida": true/false` a cada AUT + les fases de
l'oferta, i reexecutar C.2-C.3.

### C.5. Implementació + càlcul + generació

```bash
# PRIMER implementacion (generar.mjs NO el regenera)
node herramientas/genera-implementacion.mjs <id>
# després càlcul i generació
node herramientas/calcular.mjs <id>
node herramientas/generar.mjs <id>
```

Sortida esperada:
- `workspace/clientes/<id>/comercial/oferta-<id>-vN.pdf` ← **oferta comercial**
- `workspace/clientes/<id>/interno/dossier-interno-<id>-vN.pdf` ← **dossier intern (no surt de SPAI)**

**Estats per disseny:**
- `BORRADOR NO VINCULANTE` + tots els imports «pendiente» → correcte fins que
  `config/tarifas.json` (precios) i `config/prestador.json` (raó social+NIF)
  tinguin valors. Són decisions de Josep; el sistema no inventa preus.
- `calcular.mjs` diu «sin coste/hora configurado» → esperat, fins a les tarifes.

**Verificació:** el PDF té ~30-60 pàgines, cada procés amb el diagrama AS IS (vermell)
+ TO BE (blau) + descripcions; el dossier porta la guia tècnica amb JSON n8n i els
diagrames de flux.

---

## 5. Convenció de noms dels entregables (OBLIGATÒRIA)

```
<CLIENT_ID>_<NomClient_Sense_Accents_i_Espais_Amb_CamelCase>_<TipusDocument>.<ext>
```

Exemples reals:
- `CL-MAT-001_Salo_Estetica_i_Perruqueria_L_Arc_de_Mataro_Auditoria_Global.pdf`
- `CL-MAT-001_Salo_Estetica_i_Perruqueria_L_Arc_de_Mataro_Auditoria_Global_Web.html`
- `CL-MAT-001_Salo_Estetica_i_Perruqueria_L_Arc_de_Mataro_Processos_BPMN.pdf`
- `CL-MAT-001_Salo_Estetica_i_Perruqueria_L_Arc_de_Mataro_Oferta_Automatitzacions.pdf`

S'aplica a TOTS els documents (`client_documents_manager.py` ja el força per les
funcions `guardar_*`). Quan una comanda surt amb el nom intern del kit
(ex. `oferta-cl-mat-001-v1.pdf`), copiar-la a la carpeta d'entrega amb el nom correcte.

**Estructura d'entrega final** (per client):

```
/opt/data/clients/CL-XXXX-<nom>/
├── auditoria/report-pdf/CL-XXXX_..._Auditoria_Global.pdf
├── auditoria/report-web/CL-XXXX_..._Auditoria_Global_Web.html
├── kit02-optimizacio/sindicaciones-procesos/*.md        (sindicacions dels processos)
├── kit02-optimizacio/bpmn-radiografia/                   (fitxes + radiografia + svg)
├── implementacio/automatismes-ofertats/*.md             (automatismes proposats)
└── deliverables/pdfs/CL-XXXX_..._{Processos_BPMN,Oferta_Automatitzacions}.pdf
```

---

## 6. Llista de verificació final (abans de lliurar)

- [ ] Els 4 entregables existeixen i tenen el nom de la convenció
- [ ] PDF Auditoria Global: portada 1 pàgina, badge d'idioma a dalt-dreta, TOC gran,
      capítols en pàgina nova, caixes didàctiques a les seccions curtes
- [ ] Web Auditoria Global: versió AUTOCONTINGUDA (base64), 25 seccions, sense
      `loading="lazy"`, container max-width 960px
- [ ] PDF Processos BPMN: diagrames bpmn-js amb pools/carrils (NO Mermaid/weasyprint)
- [ ] PDF Oferta: `✓ Análisis coherente`, 0 contradiccions, imports «pendiente»
      si les tarifes no estan aprovades (així ha de ser)
- [ ] Dades reals: cap xifra inventada; les estimacions marcades com a tals
- [ ] El client de prova s'ha netejat de les bases i el workspace (si era prova)

---

## 7. Solució de problemes (errades freqüents i el seu fix)

| Error | Causa | Fix |
|-------|-------|-----|
| `ValueError: too many values to unpack` (auditoria global) | El JSON complet té un camp amb el nombre d'elements erroni | Veure §A.2 (formats) — comparar amb `perruqueria_mataro_complet.json` |
| `AREA no existe` / client no importat | S'ha generat abans de `importar.mjs` | Orden correcte: PAS 1 → importar → PAS 2-5 |
| `3 fichas válidas` quan n'hi ha 7 | Falta event `fin` en alguns processos | Mirar §B.3 (PAS 1 afegeix `fin` automàtic si no hi és; si encara falla, comprovar amb `comprobarFicha`) |
| `AUT apunta al proceso X, que no existe` | Config i `area_de` desalineats | Revisar `automatitzaciones[].procs` vs codis generats; reexecutar net |
| `TO BE ... cita AUT-XXX, que no existe` | to-be antics d'un config anterior | C.2 neteja `to-be/` automàticament; si persisteix, borrar `modelo/to-be/` a mà i reexecutar |
| `AttributeError: 'str' object has no attribute 'get'` (radiografia) | `equipo`/`herramientas` com a strings | L'adaptador ja els fa dicts; si es toca a mà, fer-los llistes de dicts |
| PDF oferta surt «BORRADOR NO VINCULANTE» amb preus pendent | `config/tarifas.json` / `prestador.json` buits | NO és un error: és el comportament correcte fins que Josep hi posa tarifes i dades legals |
| Els SVG de la importació es bloquegen | DOCTYPE/ENTITY (protecció del kit) | Normal: els diagrames es regeneren des del `.bpmn` |
| Imatges de la web trencades en moure el fitxer | S'ha lliurat la versió relativa | Lliurar sempre la versió AUTOCONTINGUDA (`empaquetar.py --web`) |

---

## 8. Prova de circuit ràpida (client de prova)

Per validar que tot l'entorn funciona (com la Forneria del Barri):

1. Crear `templates/prova_<sector>_bpmn.json` amb 3-4 processos reals (sector diferent
   dels clients anteriors per detectar hardcoded)
2. Crear `configs-clientes/cl-prova-<sector>.json` (patró: `cl-prova-forneria.json`)
3. Executar B.3 (fitxes + diagrames + radiografia)
4. Executar C.1-C.3 (importar + anàlisi + validar) → esperar `✓ Análisis coherente`
5. Executar C.5 (implementacion + calcular + generar) → PDF oferta
6. **Esborrar l'expedient de prova** al final:
   `rm -rf workspace/clientes/cl-prova-*` i la carpeta kit01 temporal

> Regla: per a una prova NET, esborrar l'expedient anterior del kit02 i la carpeta
> kit01 abans de reimportar (els fitxers vells no es sobreescriuen sols).
