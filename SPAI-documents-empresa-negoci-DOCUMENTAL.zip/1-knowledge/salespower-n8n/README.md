# SalesPower · Fluxos n8n (notificacions + resum)

Fluxos que reben el payload del **dashboard SalesPower** (`salespower-dashboard.html`)
i el connecten amb el món real (email), seguint el contracte definit al dashboard:

- Webhook d'n8n configurable a **Configuració → Notificacions**.
- Payload: `{ subject, html, to, type, tenant }` (POST).
- Dashboard tolerant: sense webhook configurat no envia res i no trenca.

## Fluxos

### 1. `salespower-buzon-alertas.json` — rep el payload i envia email
- **Webhook** (POST, `responseMode: onReceived` + `respondToWebhook` per respondre OK al dashboard).
- **Code node** (`Extreure payload`): normalitza `body`/`bodyString` → `{subject, html, to, type, tenant}`.
- **Send Email (SMTP)**: envia l'HTML amb `fromName = SalesPower · <tenant>`.
- **Respond to Webhook**: torna `{ok:true}` perquè el dashboard sàpiga que ha anat bé.

**Configuració:**
- Credencial SMTP al node `Enviar email` (fer servir el correu de marca `salespower@solutionpartner.ai`).
- **Header Auth** al webhook (només el dashboard — que ja guarda el token del tenant — ha de poder cridar-lo).
- Variable d'entorn `SALESPOWER_TENANT` (slug del tenant) per al path: `/salespower/<tenant>`.

### 2. `salespower-resumen-semanal.json` — resum setmanal automàtic
- **Schedule Trigger** (cada dilluns 08:00).
- **HTTP Request** x2 → `GET /api/v2/invoices` i `GET /api/deals` (Business Pulse, Bearer token).
- **Merge** (mode append) → **Code node** (`Calcular resumen`): calcula facturació, pendent i pipeline obert.
- **Send Email (SMTP)**: envia el resum amb els KPI principals.

**Variables d'entorn requerides:**
- `SALESPOWER_API_HOST` — host del tenant (ex. `tenant.solutionpartner.ai`).
- `BUSINESS_PULSE_TOKEN` — token del connector del tenant.
- `SALESPOWER_REPORT_TO` — destinatari del resum.

> Nota: el node `Calcular resumen` normalitza el `response.items` segons el contracte
> real (`{items, has_more, cursor}`). Verificar el format al primer test amb dades
> reals; si el connector respon `{body:{items}}` cal afinjar el Code node.

## Com desplegar
1. Importar cada `.json` a n8n (Import from File).
2. Configurar credencials i variables d'entorn.
3. Activar el workflow.
4. Al dashboard: Configuració → Notificacions → posar la URL del webhook (`/salespower/<tenant>`)
   + destinatari.