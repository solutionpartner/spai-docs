# Dashboards de producte per mòdul (BusinessPower / SalesPower)

Per a desplegar el dashboard correcte segons el que contracta cada tenant.

## El servei dels dashboards (autodeployable)

Els dashboards són HTML **standalone** a `erpsp/public/`, servits directament per
l'app (Next serveix `public/`). Cada un és una SPA sencera amb ECharts, RAG,
alertes, temps real i recomanacions — no depèn de cap build ni import:

- **`erpsp/public/salespower-dashboard.html`** — SalesPower = **CRM** (relacions comercials: vendes, pipeline, retenció).
- **`erpsp/public/businesspower-dashboard.html`** — BusinessPower = **ERP** (operacions: estoc, facturació, compres, proveïdors, saldo operatiu).

Com que el gate d'entitlement de l'ERP ja existeix als **endpoints** (`requireModul`),
el dashboard només pot carregar dades dels mòduls que el tenant té. El dashboard
és la capa de presentació; la seguretat es resolt al backend, no al fitxer.

### Separació real de KPIs i NAV (Crm ≠ ERP, no es trepitgen)

Cada producte té els seus KPI del header i el seu NAV, amb objectius diferents:

| | **SalesPower (CRM)** | **BusinessPower (ERP)** |
|---|---|---|
| Objectiu | vendre + retenir | operació + estalvi |
| KPI header | Pipeline obert · Guanyat · Contactes · Tendència | Pendent · Cobrat · Valor en estoc · Tendència |
| NAV | Dashboard · CRM&Vendes · Facturació · Clients · Insights · Config | Dashboard · Facturació · Stock · Clients · Proveïdors · Insights · Config |
| Recomanacions | vendre_mes / no_perdre / satisfaccio | operativa (estoc / OC / cash / proveïdors) |

Els KPIs s'omplen per `id` (`kpiPipe/kpiWon/kpiCli` al CRM; `kpiPen/kpiCob/kpiStock`
al ERP) des de la funció `cards()`. Valors reals validats: CRM pipeline 94.200€/guanyat
43.900€; ERP pendent 44.866€/valor estoc 31.780€.

## Com es lliga per mòdul

| Mòdul contractat | Dashboard que li toca | Endpoints que veu (per gate) |
|---|---|---|
| `crm` (SalesPower) | `salespower-dashboard.html` | `/api/deals`, `/api/activities` |
| `erp` (BusinessPower) | `businesspower-dashboard.html` | `/api/invoices`, `/api/products` |
| `crm,erp` (ambdós) | els dos | tots els del modul |
| `cap` (només baios) | cap (només el menú `baios`) | cap |

## Com es desplega automàticament

No cal cap pas: si `erpsp` està en marxa i té el tenant, el dashboard del mòdul
ja s'hi serveix. La decisió de QUIN mòdul té cada client es pren al **PAS 5b**
del desplegament guiat (`deploy-tenant-guia`), que escriu `Tenant.moduls` i
`TenantRegistry.moduls`. El gate fa la resta.

## Verificació de desplegament

- `http://<erpsp>/businesspower-dashboard.html` retorna la SPA (200).
- Amb un tenant `erp`, els endpoints `/api/invoices` i `/api/products` responen >200; amb un tenant `cap`, responen 403 del gate.