# SalesPower · Connector + provisionament central (PAS 5b)

Aquest directori conté els fluxos n8n de producte (buzón + resum setmanal) que es
despleguen a TOTS els tenants. Però el producte **SalesPower (CRM/ERP) central** és
un servei a part (multitenant), i **no tots els clients el pagen**: només es
provisiona el tenant central quan `producte.salespower:true`.

## El que cal recordar sobre el connector

- El connector Business Pulse del client (`erpsp_v2_readonly`) apunta al **tenant
  CENTRAL del client** (no a un generic) — el `base_url` + `BUSINESS_PULSE_TOKEN`
  propi. És així com el dashboard llegeix les DADES REALS del client (Gap 7).
- Modalitats: `crm` | `erp` | `ambdos` → `moduls` del TenantRegistry (`crm`/`erp`/`crm,erp`).
- Si el client NO té salespower (`cap`), **no es provisiona res**: baios + fluxos VPS només.

## Script del PAS 5b (des del kit)

`kit02/herramientas/provisionar-salespower-central.sh <client> [crm|erp|ambdos|cap]`
- Sense arg, llegeix `producte`/`espai_producte` del model del tenant.
- `cap` → surt net, no crida res (cas per defecte).
- `crm/erp/ambdos` → crida `POST /api/onboarding/tenant` (upsert `TenantRegistry`) +
  guarda el mapeig + emet la config del connector.
- Requereix `ONBOARDING_TOKEN` i (opcional) `ONBOARDING_URL`.

## Com s'aplica a l'arquitectura de venda
| Client | Baios + automatitzacions | SalesPower central |
|--------|--------------------------|--------------------|
| Majoria | ✅ (sempre) | ❌ (no paga) |
| Premium (crm/erp/ambdos) | ✅ | ✅ provisiona tenant central |

Això fa que SalesPower sigui un **add-on premium**, no un requisit — que és el model
que permet vendre a molts clients, no només als grans.