# Conservació dels paquets de coneixement SPAI (referent)

Aquest directori conserva els documents generats per SPAI com a **referència de coneixement**.
No són skills executables ni configuracions desplegades; són guies operatives i procediments
reutilitzables (marcats amb el seu `SPAI-KP-<ÀREA>-<NUM>` i versió). La seva substància
metodològica ja viu a les skills de l'agència; aquí queden com a origen consultable.

## Documents conservats

| ID | Document | Tema | Font |
|---|---|---|---|
| SPAI-KP-DEV-DATA-001 | apps CRM i anàlisi de dades | Construcció d'aplicacions, CRM a mida, anàlisi empresarial reproduïble | 3 vídeos de formació |
| SPAI-KP-AGENTS-001 | agents i automatitzacions | Equip d'agents, Kanban, pilars (documents, suport, informe diari), governança | 6 vídeos |
| SPAI-KP-PDF-OCR-001 | PDF / OCR / factures n8n | Generació de PDF professional, extracció de factures, validació, idempotència | 3 vídeos |
| SPAI-KP-DEPLOY-001 | encaix kit → Business AI OS | Mapa d'encaix entre el kit d'oferta i el Build Pack (deploy governat per tenant) | kit + Build Pack v1.1 |

### SPAI-KP-DEPLOY-001 · encaix kit → Business AI OS

Ubicació: `spai-knowledge/kit-deploy-encaix/`

- `README.md` — el mapa d'encaix complet (5 capes, flux de deploy, decisions preses, què falta).
- `mapa-encaix-kit-buildpack.d2` — font editable del diagrama (D2, layout ELK).
- `mapa-encaix-kit-buildpack.svg` / `mapa-encaix.png` — el diagrama visual.

Resum: el kit d'oferta (kit01 + kit02) produeix **el model del tenant** (automatismes →
skills de l'Hermes, MCPs, JSON n8n, ordre de desplegament). El Build Pack descriu **com es
desplega un tenant** (Control Plane/Optimus, signer, Action Gateway, tenant aïllat amb
business-os + n8n + Hermes del client). El **pont** que els uneix (onboarding del tenant
alimentat pel model del kit) és el que falta construir.

## Notes de vigència

- Cada document indica el **grau d'evidència** (DOC verificat / VÍDEO resum / PROPOSTA SPAI).
- Les xifres comercials dels autors NO són benchmarks de SPAI.
- Abans d'usar-ne parts com a procediment, contrastar amb les skills vigents i l'estat real
  de l'entorn; els documents ho demanen explícitament (no "incorporar" per haver-los llegit).
- Aquesta col·lecció no autoritza cap desplegament ni acció a producció.
