# Encaix · Kit d'oferta SPAI ➜ Business AI OS (deploy governat)

**ID document:** SPAI-KP-DEPLOY-001 · **Versió:** 1.0 · **Data:** 2026-10-16
**Autor:** SolutionPartner.AI · **Estat:** proposta d'encaix (no acredita desplegament)
**Fonts:** `spai-build-pack/SPAI_Hermes_Build_Pack_v1_1/` (Build Pack v1.1) + fases 1–21 a `spai-fases-historic/` + kit `deliverables/kits/` (kit01 + kit02).

> **Grau d'evidència.** Aquest mapa connecta dues coses que existeixen per separat:
> el **kit d'oferta** (producció real, provat) i el **Build Pack** (paquet documental de
> construcció, *no una release desplegada*). El "pont" (secció 3) és **a construir**.

---

## 1. Resum en una frase

El kit produeix **el model del tenant** (què automatitzar i com). El Build Pack descriu
**com es desplega un tenant**. Falta el **pont** que faci que el model del kit alimenti
l'onboarding del tenant de manera guiada/automàtica.

---

## 2. Les 5 capes (veure diagrama `mapa-encaix-kit-buildpack.svg`)

### Capa 1 · Cicle comercial (FET — kit01 + kit02)
- **kit01** → diagnòstic BPMN (radiografia / `auditoria-procesos-bpmn-<client>`).
- **kit02** → oferta comercial (client) + **dossier intern** (SPAI).

### Capa 2 · Model del tenant (FET — sortida del kit)
El dossier intern porta, per client:
- `implementacion.json` — el model complet.
- **Automatismes → Skills de l'Hermes** del client (threads d'execució).
- **MCPs** cap als sistemes del client (Programa de gestión, correu, WhatsApp…).
- **JSON n8n nets** (importables) a `modelo/implementacio/`.
- **Prompt "Implementa això"** + **ordre de desplegament + checklist**.

### Capa 3 · Pont (FET 2026-10-16 · eina `onboarding.mjs`) · VALIDAT CONTRA EL CODI REAL
- **`herramientas/onboarding.mjs <cliente>`** llegeix `implementacion.json` i genera 3 fitxers a
  `modelo/`: `onboarding-manifest.json` (document intern), **`onboarding-template.json`** i
  **`onboarding-request.json`** (format exacte del Control Plane).
- **Validat contra la baseline real** (`Business_AI_OS_Production_Milestone_1`, desempaquetada a
  `/opt/data/spai-baseline-milestone/`):
  - `onboarding-template.json` → **REGISTRATION_OK** (27 components: 10 workflow n8n, 9 skill
    Hermes, 4 runtime, 2 agent, 2 connector).
  - El **flux e2e** (registrar components → template → `preview` → `request`) →
    **PREVIEW_OK eligible=True** + **REQUEST_OK** (job `pending_approval`).
  - **Confirma els punts clau del codi real**: `COMPONENT_TYPES={agent,skill,connector,runtime,
    workflow}` (exactament els que el kit genera) i tots els `secret_ref_name` han de tenir un
    `secret_requirements` parell (validació que només es veu executant, no llegint la doc).

### Capa 4 · SPAI central (DISSENYAT — Control Plane)
- **OPTIMUS** — governa, ordena canvis i actualitzacions als clients.
- **Signer (Ed25519)** — releases signades (build immutable + manifest signat).
- **Action Gateway** — única frontera de mutació model-facing; denegació per defecte.
- **Aprovació humana** — obligatòria segons política, independent de l'onboarding.

### Capa 5 · Tenant del client (DISSENYAT — aïllat per client)
- **Hermes del client (Argon)** — raonament + operació governada; les seves **skills són
  els automatismes** del client.
- **n8n** — fluxos importats.
- **Business OS** — runtime + Approval Engine.
- **runtime-sync · heartbeat** — estat i senyal de vida.
- **deploy worker** — fa pull del que està aprovat i aplica via handler local.

---

## 3. Flux de desplegament (el que ja està dissenyat al Build Pack)

```
CI construeix → signer signa (Ed25519) → Control Plane registra
→ aprovador humà autoritza → deploy worker del tenant fa pull i valida
→ handler local aplica → health + estat "applied" verificats
```

- **Rollback:** `POST /deployments/{id}/rollback` (validar esquema de l'API instal·lada).
- **Backup/restore:** RPO/RTO per client; un rollback de codi NO desfà un efecte extern
  (una factura enviada), això és anàlisi separada.
- **Govern:** Optimus ↔ Hermes per **MCP** amb compte `supervisor_operator` limitat.
  Mutacions via `propose_action` → aprovació → `execute_approved_action`. Mai root/SSH.

---

## 4. Decisions preses (no re-obrir sense motiu)

| Tema | Decisió | Font |
|---|---|---|
| Orquestració de contenidors | **Docker Compose. NO Kubernetes.** | Build Pack 03 |
| Autoritat de seguretat | Hermes **no** és l'autoritat ni té root | Phase 14 |
| Credencial ERP/CRM | Al domini del **tenant**, només `secret_ref` central | Build Pack 03 |
| Accés a producció | `SP_CLIENT_AUTH_MODE=key+mtls` després d'enrolament | Runbook 04 |
| Topologia (host únic vs separat) | **A confirmar** — no canviar-la en silenci | Build Pack 03 |

---

## 5. Què falta per tenir desplegament automàtic (llista honesta)

1. ✅ **Pont kit → onboarding** **FET i VALIDAT contra el codi real** (`onboarding.mjs` +
   `onboarding-template.json`/`request.json`; `REGISTRATION_OK` + `PREVIEW_OK` +
   `REQUEST_OK`).
2. ✅ **Artefactes reproduïbles** — a `spai-build-pack/tenant-images/`: **5 imatges** del
   tenant (base, **business-os servei** (feta ara, provada e2e), runtime-sync,
   deploy-worker, license-sync) + **perfil Hermes del client** (`hermes-client/`, l'«Argon»
   del tenant). `n8n` = oficial `n8nio/n8n`. Falta run `build.sh` al VPS (aquest host no té
   daemon de Docker).
3. ✅ **Claus i CA generades (custòdia = OPTIMUS, decisió 2026-10-17)** — veure secció 8:
   release, license, break-glass, installation a `secrets/` (privades 0600) + CA i cert
   mTLS del tenant de prova a `secrets/pki/`. Falta: decidir rotació/HSM opcional i
   distribuir només les públiques als components.
4. **Staging**: aixecar-ho en entorn net i provar reinici, persistència i absència de
   secrets a imatges/logs. **Requereix daemon Docker** (no disponible en aquest host).
5. **Primer tenant real** (Fase de `05_RUNBOOK_TENANT_DEPLOY`): enrolament mTLS,
   desplegament de components signats, secrets locals, health i prova read-only amb ERP.

> **Validesa de la baseline (2026-10-17):** la suite sencera de tests del Control Plane
> passa — **262/262 tests, 35/35 fitxers, 0 errors** (inclou controls_plane, API 7-21,
> onboarding, catalog, releases/rollouts, billing/licensing, local agents, AI runtime,
> finops, contracts, governance, security, milestone). La baseline és **funcional i
> estable**.

---

## 8. Claus i CA — mapeig complet (resultat de revisar el codi real)

La baseline té **5 sistemes de claus** separats. Cada un té un script de generació (a
`scripts/`) i una política de custòdia clara: **la clau privada no entra mai al Control
Plane ni als VPS dels clients**, només les públiques/verificadors.

| # | Sistema (script) | Algoritme | Ús | On viu la clau privada |
|---|---|---|---|---|
| 1 | **Release signing** (`generate_release_keys.py` + `sign_release_manifest.py`) | Ed25519 | Signa els manifests de release (digest `sha256:`). El Control Plane els verifica amb **SP_RELEASE_PUBLIC_KEY_PEM/PATH** abans d'acceptar. | Offline / CI-secret-manager. Només la clau pública es munta al Control Plane i als clients. |
| 2 | **License leases** (`generate_license_keys.py` + `license_signer_worker.py`) | Ed25519 | Signa les llicències (`verify_lease`) — governa `package_allowed`, `allow_ai`, `allow_write`, `allow_deploy`. | Fora del Control Plane; només la pública hi va i als `tenant_runtime`. |
| 3 | **Break-glass** (`generate_break_glass_keys.py` + `issue_break_glass.py`) | Ed25519 | Accés d'emergència independent de l'onboarding. | **Offline**, custodiada; només pública muntada al Control Plane. |
| 4 | **Client PKI / mTLS** (`generate_client_pki.sh` + `cert_fingerprint.py`) | ED25519 CA + client | Identitat de cada **tenant** a l'edge (Caddy requereix mTLS a `clients.*`). La CA emet un cert per tenant; l'enrolament registra el sha-256 al Control Plane i activa `SP_CLIENT_AUTH_MODE=key+mtls`. | **`client-ca.key` offline**; només `client-ca.pem` al gateway. Única clau *privada per tenant* al seu VPS (el seu cert). |
| 5 | **Installation identity** (`generate_installation_identity.py`) | Ed25519 | Anti-clone del tenant (bindings a `runtime`); recomanació: TPM/HSM per anti-clone fort. | Al tenant, no exportable idealment. |

**Custòdia — DECISIÓ PRESA (2026-10-17): la clau privada viu a OPTIMUS** (el central SPAI,
`/opt/data/spai-build-pack/secrets/`). Els scripts s'han executat de veritat i les claus
reals són a:
- `secrets/offline/` — `release-private.pem`, `license-private.pem`,
  `break-glass-private.pem`, `installation-master-private.pem` (**0600**).
- `secrets/` — les públiques parelles (**0644**): `release-public.pem`, `license-public.pem`,
  `break-glass-public.pem`, `installation-master-public.pem`.
- `secrets/pki/` — CA del client + cert mTLS del tenant de prova Vertex Mantenimientos:
  `client-ca.key` (**0600**, offline), `client-ca.pem` (edge), `vertex-mantenimientos.key`/
  `.pem` (tenant), `client-ca.srl`, `.csr`. Fingerprint sha-256 del cert de Vertex:
  `b5ca6219eb8a9771fef3facb16febc0625c8add8cd602b3909909035c3f27a9b`.

**Política en aquesta decisió**: la clau privada **no es copia mai** al Control Plane ni als
VPS dels clients — només les públiques/verificadors es munten als components (com diu cada
runbook). Rotació/HSM i multi-firma per a alta producció segueixen **pendents** (opcionals).

**Prova feta**: els scripts de generació s'han revisat contra el codi (`control_plane.releases.
generate_ed25519_keypair`, `licensing.generate_keypair`, `x509`/`ed25519` de cryptography).
No s'han **generat claus reals** en aquest entorn (és una acció sensible de custòdia — cal
decidir on es generen i qui les guarda abans de fer-ho).

**Prova descartable de signatura (feta 2026-10-17, sense custòdia compromesa):**
- `generate_release_keys.py` → genera clau Ed25519 **0600**. OK.
- `sign_release_manifest.py` → signa el manifest real de l'exemple; genera `manifest_id` +
  `signature`. OK.
- `control_plane.releases.verify_manifest` → **VERIFY_OK** amb la clau pública.
- Contra-prova (manifest alterat a v9.9.9) → **VERIFY_FAILED** (rebuja correctament):
  la signatura va unida al contingut canònic, no només present.
- **Resum:** el mecanisme de releases signades *funciona realment* contra el codi del
  Control Plane. Totes les claus temporals s'han **esborrat** (cap resta `rel-*.pem`).
- Decisió pendent (no codificable): on viu la custòdia definitiva (signing node/HSM/CI).

---

## 6. Fitxers d'aquest paquet

| Fitxer | Què és |
|---|---|
| `mapa-encaix-kit-buildpack.d2` | Font editable del diagrama (D2, layout ELK). |
| `mapa-encaix-kit-buildpack.svg` | Diagrama vectorial. |
| `mapa-encaix.png` | Captura PNG (per veure'l ràpid). |
| `docker-compose.tenant.esbós.yml` | Esbós del Compose del tenant (7 serveis: business-os, n8n, hermes-client, runtime-sync, heartbeat, deploy-worker, licensing). Basat en estructures reals de la baseline. Punt de partida, no desplegat. |
| `tenant-images/` | **Build Pack del tenant**: 5 Dockerfiles (base, **business-os servei**, runtime-sync, deploy-worker, license-sync) + `build.sh` + `requirements-tenant.txt` + **perfil Hermes del client** (`hermes-client/`). Business-os provat e2e contra la baseline; la resta contrastat. Per construir al VPS destí. |
| `secrets/` | **Custòdia de claus d'SPAI (Optimus)** — decision 2026-10-17. `offline/` (privades 0600: release/license/break-glass/installation), públiques (0644), `pki/` (CA + cert mTLS tenant de prova). Mai es copien privades als components. |
| `validate_tpl.py` / `e2e_onboarding.py` | Scripts de prova que validen el template del kit contra el Control Plane real (`REGISTRATION_OK` / `PREVIEW_OK`+`REQUEST_OK`). |
| `RUNBOOK-staging.md` | Runbook d'una pàgina **genèric** (parametritzat per `<TENANT>`) per aixecar el staging: Control Plane (un cop) + onboarding/release/tenant en VPS per a qualsevol client. Executar al VPS amb Docker. |
| `README.md` | Aquest document. |

**Regenerar el diagrama:**
```bash
/opt/data/tools/d2/bin/d2 --layout elk --pad 24 --theme 0 \
  --font-regular <kit>/assets/fonts/Roboto-Regular.ttf \
  --font-bold    <kit>/assets/fonts/Roboto-Bold.ttf \
  mapa-encaix-kit-buildpack.d2 mapa-encaix-kit-buildpack.svg
```

---

## 7. Creuament amb el Build Pack (on encaixa cada peça)

| Peça del kit | Paper al Build Pack |
|---|---|
| `implementacion.json` (automatismes, skills, MCPs) | Contingut del **tenant**: defineix què executa el Business OS i l'n8n del client. |
| Skills de l'Hermes (per automatisme) | **Hermes del client (Argon)** — skills d'operació del tenant. |
| MCPs | **Connectors** del tenant cap als sistemes (egress explícit). |
| JSON n8n nets | **n8n** del tenant (import directe). |
| Ordre + checklist del dossier | Base del **runbook d'onboarding** (`05_RUNBOOK_TENANT_DEPLOY`). |
| Optimus (central) | **Control Plane** — govern, releases signades, Action Gateway. |

---

## 8. Catàleg de mòduls del producte (venda i instal·lació governada)

> **Decisió (2026-10-17).** SalesPower/BusinessPower es ven **per separat del** Business AI OS
> + automatitzacions IA. Els mòduls no s'implementen tots de cop (no construeixis tot Odoo):
> s'activen **a la carta**, des de la Configuració del dashboard, i el desplegament és governat.

### Flux (activació en un clic)
1. **Dashboard (Configuració → Mòduls)** llista el catàleg: cada mòdul té `id`, `àrea` (CRM/ERP/IA),
   `inclòs` (a la llicència bàsica) o `preu` (extensió de pagament).
2. L'usuari fa clic a **Activa**:
   - si el mòdul és **de pagament** i el tenant no el té → es mostra el **pagament**.
   - en tot cas s'encarrega l'**Argon** (l'Hermes del tenant).
3. **Argon** demana a **Optimus** (orquestrador central) per API.
4. **Optimus** retorna el **codi desplegable** (manifests, imatges/artifacts, workflows n8n,
   skills, MCPs, secrets refs) **+ rails/instruccions** d'implementació.
5. **Argon ho instal·la** al tenant (pull, model governat — mai pujar des del central).

### Regles
- **`inclòs`**: mòdul que ve amb la subscripció bàsica del tenant (activació immediata).
- **`preu`**: extensió addicional; l'activació requereix pagament si no està coberta.
- Un mòdul GUIAT per l'operació es registra com a component (`agent|skill|connector|runtime|workflow`)
  al template d'onboarding — el mateix mecanisme que el kit ja genera.
- **Argon mai s'autoaprovacà** un mòdul de pagament: la facturació i l'aprovació passen per Optimus.
- El codi desplegable viatja signat; el handler local valida digest/URI (model pull establert).

### Enllaç amb les capes anteriors
| Peça | Paper |
|---|---|
| Catàleg (`MODULES`) | Backing del dashboard (Configuració → Mòduls) |
| `inclòs`/`preu` | Decisió comercial abans del deploy |
| Argon | Executor de la instal·lació al tenant |
| Optimus | Orquestrador central: retorna codi + rails, aprova |
| Control Plane | Registra components i releases signades |

---

*Aquest document no autoritza cap desplegament ni acció a producció. És un mapa de
referència per a la construcció del pont kit → tenant.*
