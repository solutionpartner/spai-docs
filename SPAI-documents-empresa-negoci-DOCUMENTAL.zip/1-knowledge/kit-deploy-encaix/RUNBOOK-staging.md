# RUNBOOK · Staging del Business AI OS (una pàgina · genèric)

**Objectiu:** aixecar el Control Plane + **un tenant qualsevol** en un VPS amb Docker,
end-to-end governat i estàndard. Executar EN EL VPS (requereix daemon Docker). Les claus
SPAI viuen a Optimus (`spai-build-pack/secrets/`) i **no es copien mai** als components.

**Genericitat:** tòt això funciona per a QUALSEVOL client produït pel kit (el pipeline és
CL-XXXX → import → anàlisi → oferta → dossier → `onboarding.mjs` → desplegament). A cada
passa se substitueix `<TENANT>` (l'slug del client) i `<SLUG>`. Vertex Mantenimientos és
només el primer cas de prova (exemple entre parèntesis).

Prerequisits: `docker`, `docker compose`, baseline (`SPAI_BASELINE`), claus públiques i
certs ja generats a Optimus.

---

## FASE A · Control Plane (central — es fa UNA vegada, val per tots els tenants)

```bash
export BASELINE=/ruta/a/business_ai_os_production_milestone_1
cd "$BASELINE"

# 0. secrets: copiar NOMÉS les PÚBLIQUES des d'Optimus (mai les privades)
mkdir -p secrets && cp /opt/data/spai-build-pack/secrets/release-public.pem secrets/
cp /opt/data/spai-build-pack/secrets/break-glass-public.pem secrets/
cp /opt/data/spai-build-pack/secrets/pki/client-ca.pem secrets/   # edge mTLS

# 1. config mínima
cp config/control-plane.env.example .env   # editar creds admin, SP_RELEASE_PUBLIC_KEY_PATH
export SP_AUTH_MODE=${SP_AUTH_MODE:-key}   # provisional; key+mtls després d'enrolar

# 2. aixecar (INICIALMENT el compose normal; secure requereix TLS en producció)
docker compose up -d --build
curl -s http://127.0.0.1:8080/health && echo " → Control Plane OK"
```

## FASE B · Onboarding del tenant (per a CADA client)

```bash
TENANT=<TENANT>                          # ex: vertex-mantenimientos
KIT=/opt/data/deliverables/kits/02-kit-oferta-soluciones

# 1. Generar el template del kit (format Control Plane validat: REGISTRATION_OK)
cd "$KIT" && node herramientas/onboarding.mjs "$TENANT"
# → genera modelo/onboarding-template.json + onboarding-request.json (per a aquest client)
# 2. Registrar components + template + request (split genèric, reutilitza els scripts)
python $BASELINE/scripts/seed_onboarding_template.py --template "$KIT"/workspace/clientes/$TENANT/modelo/onboarding-template.json
python $BASELINE/scripts/onboard_client.py --request "$KIT"/workspace/clientes/$TENANT/modelo/onboarding-request.json --admin "$ADMIN_TOKEN"
# → job status: pending_approval
# 3. APROVACIÓ HUMANA (OP = Optimus, rol aprovador)
curl -X POST http://127.0.0.1:8080/onboarding/jobs/<id>/approve -H "Authorization: Bearer $ADMIN_TOKEN"
```

## FASE C · Signar + registrar una release (per a cada versió d'un component)

```bash
# 1. signar des d'Optimus (offline)
cd /opt/data/spai-build-pack/secrets/offline
PYTHONPATH=$BASELINE python $BASELINE/scripts/sign_release_manifest.py \
  <manifest.json> --private-key release-private.pem --output signed-release.json
# 2. registrar al Control Plane (verifica la signatura amb la pública)
curl -X POST http://127.0.0.1:8080/releases/manifests \
  -H "Authorization: Bearer $ADMIN_TOKEN" -H "Content-Type: application/json" -d @signed-release.json
```

## FASE D · Instal·lar el tenant al seu VPS (per a CADA client)

```bash
TENANT=<TENANT>
# 1. build de les imatges del tenant (UNA vegada, a cada VPS)
bash /opt/data/spai-build-pack/tenant-images/build.sh   # SPAI_BASELINE apunta a la baseline

# 2. cert mTLS del tenant — emetre des d'Optimus per a AQUEST client i copiar la seva parella
#    (generar_client_pki.sh CA client; els .key/.pem RESULTANTS són els UNICS privats del VPS)
cp /opt/data/spai-build-pack/secrets/pki/$TENANT.{key,pem} /srv/$TENANT/secrets/

# 3. desplegar (el compose del tenant és GENÈRIC — no porta cap client hardcoded)
cd /srv/$TENANT && docker compose -f /opt/data/spai-knowledge/kit-deploy-encaix/docker-compose.tenant.esbós.yml up -d
# → el deploy-worker fa pull de la release aprovada i el handler local l'aplica
```

## FASE E · Verificació final (per a CADA tenant)

- `curl` al `/health` del Control Plane → viu · localhost:8080.
- El tenant reporta `heartbeat` OK al Control Plane.
- `runtime-sync` diu `status: applied` (estat desitjat aplicat atòmicament).
- `verify_manifest` sobre la release → OK (signatura vàlida amb la pública).
- **Secret check:** cap clau privada a les imatges ni logs (`grep` a `docker inspect` + logs).

---

## Genericitat (què és fix i què canvia per client)

| Fix (UNA vegada) | Per client |
|---|---|
| Control Plane + seves claus públiques | template + components + job d'onboarding |
| Imatges del tenant (base/workers) | cert mTLS (parella .key/.pem al seu VPS) |
| Compose del tenant (esbós, sense client) | secrets locals i releases signades |
| CA del client (ca.key, offline a Optimus) | stdout del model de cada client |

## Blocs coneguts (quan facis staging)

- **`hermes-client`** NO és una imatge Docker: és el **perfil Hermes** del tenant
  (`spai-build-pack/tenant-images/hermes-client/`), que s'injecta com a configuració al
  runtime Hermes — no com a contenidor propi.
- **`business-os servei`** ja el construïm (frontera deny-by-default portada a servei, a
  `spai-build-pack/tenant-images/business-os/`); els 3 workers one-shot
  (runtime-sync/deploy-worker/license-sync) es posen en timer/cron, o s'empaqueten com a
  dimonis.
- L'ordre d'onboarding és **aprovació humana obligatòria** → ningú desplega sense OP.
- Rotació i HSM (= multi-firma) queden per alta producció; no bloquegen staging.

*Fi. Aquest runbook no autoritza cap desplegament de producció — és per staging/prova.*