#!/usr/bin/env python3
"""Servidor web del QÜESTIONARI DE DADES (1B) — capta lead AL PRINCIPI i respostes després."""
import json, os, time, datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from openpyxl import Workbook, load_workbook
import validacio

BASE = os.path.dirname(os.path.abspath(__file__))
WEBROOT = BASE
XLSX = os.path.join(BASE, "respostes-questionari.xlsx")

LEAD_HEADERS = ["Data", "lead_id", "Nom", "Empresa", "Email", "Telèfon", "WhatsApp", "Idioma"]
QUESTION_FIELDS = [
    # A. Identificació
    ("A1_Nom empresa", "A1. Nom de l'empresa"),
    ("A2_Sector", "A2. Sector / activitat"),
    ("A3_Any fundació", "A3. Any de fundació"),
    ("A4_Empleats i rols", "A4. Nombre d'empleats i rols principals"),
    ("A5_Ubicació", "A5. Ubicació (adreça / ciutat)"),
    ("A6_Diferencial", "A6. Què us fa diferents de la competència?"),
    # B. Què i a qui
    ("B1_Productes i preus", "B1. Productes/serveis principals (amb preu aproximat)"),
    ("B2_Client ideal", "B2. Qui és el vostre client ideal?"),
    ("B3_Canals captació", "B3. Com arriben els clients a vosaltres (canals)?"),
    # C. Processos
    ("C1_Dia a dia", "C1. Com és el dia a dia en cada àrea?"),
    ("C2_Feines manuals", "C2. Quines feines són manuals i repetitives?"),
    ("C3_Errors i colls", "C3. On sorgeixen més errors o colls d'ampolla?"),
    # Checklist de processos (sí/no)
    ("CK_Comandes", "CK. Comandes / vendes — el teniu?"),
    ("CK_Comandes_manual", "CK. Comandes / vendes — es fa a mà?"),
    ("CK_Factura", "CK. Facturació i cobraments — el teniu?"),
    ("CK_Factura_manual", "CK. Facturació i cobraments — es fa a mà?"),
    ("CK_Compres", "CK. Compres a proveïdors — el teniu?"),
    ("CK_Compres_manual", "CK. Compres a proveïdors — es fa a mà?"),
    ("CK_Produccio", "CK. Producció / elaboració — el teniu?"),
    ("CK_Produccio_manual", "CK. Producció / elaboració — es fa a mà?"),
    ("CK_Estocs", "CK. Estocs / inventari — el teniu?"),
    ("CK_Estocs_manual", "CK. Estocs / inventari — es fa a mà?"),
    ("CK_Logistica", "CK. Logística / entrega — el teniu?"),
    ("CK_Logistica_manual", "CK. Logística / entrega — es fa a mà?"),
    ("CK_Atencio", "CK. Atenció al client / reclamacions — el teniu?"),
    ("CK_Atencio_manual", "CK. Atenció al client — es fa a mà?"),
    ("CK_Marketing", "CK. Màrqueting / xarxes / leads — el teniu?"),
    ("CK_Marketing_manual", "CK. Màrqueting / xarxes — es fa a mà?"),
    ("CK_Comptabilitat", "CK. Comptabilitat / tresoreria — el teniu?"),
    ("CK_Comptabilitat_manual", "CK. Comptabilitat — es fa a mà?"),
    ("CK_Informes", "CK. Informes / reports periòdics — el teniu?"),
    ("CK_Informes_manual", "CK. Informes / reports — es fa a mà?"),
    # Hores/setmana per procés manual (càlcul real d'impacte)
    ("CK_Comandes_hores", "CK. Comandes — hores/setmana"),
    ("CK_Factura_hores", "CK. Facturació — hores/setmana"),
    ("CK_Compres_hores", "CK. Compres — hores/setmana"),
    ("CK_Produccio_hores", "CK. Producció — hores/setmana"),
    ("CK_Estocs_hores", "CK. Estocs — hores/setmana"),
    ("CK_Logistica_hores", "CK. Logística — hores/setmana"),
    ("CK_Atencio_hores", "CK. Atenció al client — hores/setmana"),
    ("CK_Marketing_hores", "CK. Màrqueting — hores/setmana"),
    ("CK_Comptabilitat_hores", "CK. Comptabilitat — hores/setmana"),
    ("CK_Informes_hores", "CK. Informes — hores/setmana"),
    # D. Punts de dolor
    ("D1_Problema principal", "D1. Quin és el problema principal que us preocupa ara?"),
    ("D2_Pèrdua diners/clients", "D2. Què us fa perdre diners o clients?"),
    # E. Tecnologies
    ("E1_Eines actuals", "E1. Quines eines/programes feu servir actualment?"),
    ("E2_Web i botiga online", "E2. Teniu web, reserva/compra online o botiga digital?"),
    ("E3_Xarxes i freqüència", "E3. Quines xarxes socials feu servir i amb quina freqüència?"),
    # F. Finances
    ("F1_Ingressos", "F1. Ingressos anuals aproximats"),
    ("F2_Marge", "F2. Marge aproximat (%)"),
    ("F3_Volum i ticket", "F3. Volum de vendes i valor mitjà (ticket)"),
    ("F4_Costos principals", "F4. Els 3 costos principals"),
    ("F5_Estacionalitat", "F5. Estacionalitat (quan pugen/baixen les vendes)"),
    # G. Competidors
    ("G1_Competidors", "G1. Els vostres 5 principals competidors (noms i web)"),
    ("G2_On us guanyen", "G2. On us guanyen?"),
    ("G3_On els guanyeu", "G3. On els guanyeu vosaltres?"),
    ("G4_Adreces competidors", "G4. Adreça o barri de cadascun (per geolocalització)"),
    # H. Objectius
    ("H1_Metes", "H1. Quines metes concretes voleu assolir?"),
    ("H2_Canvi en 6 mesos", "H2. Què hauria canviat d'aquí a 6 mesos?"),
    ("H3_Pressupost", "H3. Quin pressupost teniu per a aquestes millores?"),
    # I. Tancament
    ("I1_Altres", "I1. Hi ha res més que vulgueu afegir?"),
    ("I2_Contacte", "I2. Canal i dades de contacte preferit"),
    # A7 País (afegit al final per no desordenar columnes existents)
    ("A7_Pais", "A7. País"),
]
ALL_HEADERS = LEAD_HEADERS + [name for name, _ in QUESTION_FIELDS]

def ensure_xlsx():
    if not os.path.exists(XLSX):
        wb = Workbook(); ws = wb.active; ws.title = "Respostes"
        ws.append(ALL_HEADERS)
        wb.save(XLSX)

def append_lead(lead):
    ensure_xlsx()
    wb = load_workbook(XLSX); ws = wb["Respostes"]
    row = [lead.get("data",""), lead.get("lead_id",""),
           lead.get("nom",""), lead.get("empresa",""),
           lead.get("email",""), lead.get("telefon",""), lead.get("whatsapp",""),
           lead.get("idioma","ca")]
    row += [""] * len(QUESTION_FIELDS)
    ws.append(row)
    wb.save(XLSX)

def update_respostes(lead_id, respostes):
    ensure_xlsx()
    wb = load_workbook(XLSX); ws = wb["Respostes"]
    found = False
    for r in range(2, ws.max_row + 1):
        if ws.cell(row=r, column=2).value == lead_id:  # columna lead_id
            for name, _label in QUESTION_FIELDS:
                col = ALL_HEADERS.index(name) + 1
                ws.cell(row=r, column=col, value=respostes.get(name, ""))
            found = True
            break
    wb.save(XLSX)
    return found

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html"):
            self._serve(os.path.join(WEBROOT, "index.html"), "text/html; charset=utf-8")
        elif path == "/respostes-questionari.xlsx":
            self._serve(XLSX, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", download=True)
        else:
            p = os.path.join(WEBROOT, path.lstrip("/"))
            if os.path.isfile(p):
                self._serve(p, "text/html; charset=utf-8" if p.endswith(".html") else "application/octet-stream")
            else:
                self.send_error(404)

    def _serve(self, path, ctype, download=False):
        if not os.path.isfile(path): self.send_error(404); return
        data = open(path, "rb").read()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        if download: self.send_header("Content-Disposition", 'attachment; filename="respostes-questionari.xlsx"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        path = self.path.split("?")[0]
        length = int(self.headers.get("Content-Length", 0))
        try:
            body = json.loads(self.rfile.read(length))
        except Exception:
            return self._json(400, {"ok": False, "error": "json invàlid"})
        if path == "/lead":
            lead_id = str(int(time.time() * 1000))
            body["lead_id"] = lead_id
            body["data"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            errors = validacio.validate_lead(
                body.get("email", ""),
                body.get("telefon", ""),
                body.get("whatsapp", "")
            )
            if errors:
                self._json(422, {"ok": False, "errors": errors})
                return
            try:
                append_lead(body)
                self._trigger_email(body)
                self._notify_agencia(body)
                self._json(200, {"ok": True, "lead_id": lead_id})
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)})
        elif path == "/respostes":
            lead_id = body.get("lead_id")
            respostes = body.get("respostes", {})
            # validació: mínim d'informació enviada
            filled = sum(1 for v in respostes.values() if isinstance(v, str) and v.strip())
            if filled < 15:
                self._json(422, {"ok": False, "error": f"Cal omplir com a mínim 15 camps (només n'hi ha {filled})."})
                return
            try:
                ok = update_respostes(lead_id, respostes)
                self._json(200 if ok else 404, {"ok": ok})
            except Exception as e:
                self._json(500, {"ok": False, "error": str(e)})
        else:
            self._json(404, {"ok": False, "error": "not found"})

    def _trigger_email(self, lead):
        email = (lead or {}).get("email", "") if isinstance(lead, dict) else ""
        if not email:
            return
        try:
            import subprocess
            subprocess.Popen([
                "/opt/data/.claude/audit-system/.venv/bin/python",
                "/opt/data/.claude/audit-system/email_envio.py", "lead",
                "--tipus", "quest",
                "--to", email,
                "--nom", str((lead or {}).get("nom", "")),
                "--empresa", str((lead or {}).get("empresa", "")),
                "--lang", str((lead or {}).get("idioma", "ca") or "ca"),
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def _notify_agencia(self, lead):
        """Notificació INTERNA a l'agència quan es capta un lead (1B): resum a josepmanel@."""
        if not (isinstance(lead, dict) and lead.get("nom")):
            return
        try:
            import subprocess
            subprocess.Popen([
                "/opt/data/.claude/audit-system/.venv/bin/python",
                "/opt/data/.claude/audit-system/email_envio.py", "avis",
                "--nom", str(lead.get("nom", "")),
                "--empresa", str(lead.get("empresa", "")),
                "--email", str(lead.get("email", "")),
                "--telefon", str(lead.get("telefon", "")),
                "--whatsapp", str(lead.get("whatsapp", "")),
                "--idioma", str(lead.get("idioma", "ca") or "ca"),
                "--data", str(lead.get("data", "")),
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def _json(self, code, obj):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        pass

if __name__ == "__main__":
    ensure_xlsx()
    port = int(os.environ.get("PORT", 8171))
    print(f"Serving on :{port} — XLSX: {XLSX}")
    HTTPServer(("0.0.0.0", port), Handler).serve_forever()