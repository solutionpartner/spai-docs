#!/usr/bin/env python3
"""Validació de dades de lead compartida (server-side)."""
import re

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
PHONE_RE = re.compile(r"^\+?[0-9][0-9 .\-()]{6,}$")

def valid_email(email: str) -> bool:
    """Format vàlid + domini que no sigui clarament inexistent."""
    if not email or not EMAIL_RE.match(email):
        return False
    domain = email.rsplit("@", 1)[-1]
    return domain_ok(domain)

def valid_phone(phone: str) -> bool:
    """Telèfon numèric (amb + inicial, espais, guions i parèntesis permesos)."""
    if not phone:
        return True  # opcional
    return bool(PHONE_RE.match(phone))

def domain_ok(domain: str) -> bool:
    """Retorna True si el domini accepta correu o no es pot verificar (best-effort).

    Només rebutja quan és CLAR que el domini no existeix (NXDOMAIN). En cas de
    timeout o error de xarxa temporal, permet passar per no rebutjar emails vàlids.
    """
    try:
        import dns.resolver
        r = dns.resolver.resolve(domain, "MX", lifetime=3.0)
        return len(list(r)) > 0
    except dns.resolver.NXDOMAIN:
        return False  # domini clarament inexistent
    except dns.resolver.NoAnswer:
        # el domini existeix però no té MX: pot ser un domini de correu propi
        # o un servei que no publica MX de la forma habitual. Permet-ho.
        return True
    except Exception:
        # timeout, error de xarxa, DNS no disponible... no rebutjar emails vàlids
        return True

def validate_lead(email: str, phone: str = "", whatsapp: str = "") -> list:
    """Retorna llista d'errors; buida si tot és correcte."""
    errors = []
    if not email:
        errors.append("L'email és obligatori.")
    elif not EMAIL_RE.match(email):
        errors.append("El format de l'email no és vàlid.")
    elif not domain_ok(email.rsplit("@", 1)[-1]):
        errors.append("El domini de l'email no existeix. Revisa que l'has escrit bé.")
    if phone and not PHONE_RE.match(phone):
        errors.append("El telèfon ha de ser numèric.")
    if whatsapp and not PHONE_RE.match(whatsapp):
        errors.append("El WhatsApp ha de ser numèric.")
    return errors