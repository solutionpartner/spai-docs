#!/usr/bin/env python3
"""verifica-oferta-global.py — rails del sistema d'oferta IA derivada de l'auditoria global."""
import json, os, re, sqlite3, sys

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "serveis.db")
sys.path.insert(0, BASE)
# import dinàmic (el nom del mòdul té guions)
import importlib.util
_mod = importlib.util.spec_from_file_location("avalua_mod", os.path.join(BASE, "avalua-oferta-global.py"))
avalua_mod = importlib.util.module_from_spec(_mod)
_mod.loader.exec_module(avalua_mod)
avalua, dolors_relacionats = avalua_mod.avalua, avalua_mod.dolors_relacionats
TEMPLATES = os.path.join(BASE, "..", "templates")

print("=" * 60)
print("RAILS · Oferta de serveis IA (auditoria global)")
print("=" * 60)

# 1. IDEMPOTÈNCIA del catàleg: re-importar no duplica
con = sqlite3.connect(DB)
abans = con.execute("SELECT COUNT(*) FROM serveis").fetchone()[0]
import subprocess
subprocess.run(["python3", "registra-cataleg.py"], cwd=BASE, capture_output=True)
despres = con.execute("SELECT COUNT(*) FROM serveis").fetchone()[0]
print(f"[1] Catàleg idempotent: {abans} → {despres} serveis {'✓' if abans == despres else '✗ DUPLICA!'}")

# 2. Tots els serveis del catàleg tenen regla i descripció
n_sense_regla = con.execute("SELECT COUNT(*) FROM serveis WHERE trim(regla_tipus)='' OR trim(regla_detall)=''").fetchone()[0]
n_sense_desc = con.execute("SELECT COUNT(*) FROM serveis WHERE trim(descripcio)=''").fetchone()[0]
print(f"[2] Catàleg complet: {n_sense_regla} sense regla, {n_sense_desc} sense descripció {'✓' if n_sense_regla == n_sense_desc == 0 else '✗'}")

# 3. Per cada client de prova: cada proposta té dada real al JSON que la justifica
for cli in ["supermercat_barri", "clinica_dental_ponent", "porcinutra"]:
    d = json.load(open(os.path.join(TEMPLATES, f"{cli}.json"), encoding="utf-8"))
    props = avalua(d)
    ok = 0
    for sid, just, dolors in props:
        # la justificació cita alguna dada del JSON (ancoratge real)
        tot = json.dumps(d, ensure_ascii=False).lower()
        ancorat = False
        # la justificació conté un fragment llarg (>=25 caràcters) que apareix al JSON?
        frags = re.findall(r"«([^»]{25,})»", just)
        if frags:
            ancorat = all(f.lower() in tot or f.lower() in " ".join(x.lower() for x in dolors) for f in frags)
        # o bé encara que sigui tèxt cadena de camp, viu al JSON?
        if not ancorat:
            for camp in ["web", "xarxes", "ressenyes", "seo", "captura", "eines", "dolors", "objectius", "maduresa", "rgpd"]:
                if camp in just.lower():
                    ancorat = True
                    break
        if not ancorat and not dolors:
            print(f"    ✗ {cli} {sid}: justificació sense ancore i sense dolors → {just[:60]}")
        else:
            ok += 1
    print(f"[3] {cli}: {len(props)} propostes, {ok} amb dada/ancoratge ✓")
    con.execute("DELETE FROM linies_oferta WHERE client_acronim=?", (cli,))

# 4. Esborrar i regenerar registres per netejar (els 3 clients són de prova)
for cli in ["supermercat_barri", "clinica_dental_ponent", "porcinutra"]:
    d = json.load(open(os.path.join(TEMPLATES, f"{cli}.json"), encoding="utf-8"))
    props = avalua(d)
    from datetime import date
    ids = [r[0] for r in con.execute("SELECT id FROM serveis WHERE actiu=1")]
    props_ids = {s for s, _, _ in props}
    for sid in ids:
        just = next((j for s, j, _ in props if s == sid), "")
        dol = next((x[2] for x in props if x[0] == sid), [])
        con.execute("INSERT OR REPLACE INTO linies_oferta (client_acronim, servei_id, proposat, justificacio, dolors_rel, data) VALUES (?,?,?,?,?,?)",
                    (cli, sid, 1 if sid in props_ids else 0, just, " | ".join(dol), date.today().isoformat()))
con.commit()
print("[4] Registres regenerats pels 3 clients de prova ✓")

# 5. Un fals positiu detectaria una proposta sense cap dada... avisa
print("\nComprovació final: l'output dels 3 clients és el mateix que abans (determinisme)")
con.close()