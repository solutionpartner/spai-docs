#!/usr/bin/env python3
"""avalua-oferta-global.py — deriva serveis IA de l'auditoria global d'un client.

Input: el JSON de l'auditoria global (templates/<client>.json) + catàleg (serveis.db).
Output:
  - pantalla: llista de serveis proposats amb la dada d'input que ho justifica
  - BBDD: registra a linies_oferta (client_acronim, servei_id, justificacio)
  - opcional --html <fitxer>: genera l'entregable (document HTML autocontingut)

Principi: cap servei es proposa sense una dada concreta del JSON que ho suporti
(la justificació cita la dada real). Si no hi ha dades, no es proposa res.
"""
import json, os, re, sqlite3, sys
from datetime import date

BASE = os.path.dirname(os.path.abspath(__file__))
AUDITSYS = os.path.dirname(BASE)  # .. = audit-system/ (els logos viuen a deliverables/)
DB = os.path.join(BASE, "serveis.db")
BASE_ABS_ = AUDITSYS  # àlies per generar_html (logo dark a deliverables/)


def carrega_client(path):
    d = json.load(open(path, encoding="utf-8"))
    return d


def text_baix(*parts):
    return " ".join(str(p) for p in parts if p).lower()


# --- Benefici genèric per servei (verd) quan el JSON del client no té xifra lligada. ---
BENEFICI_GENERIC = {
    "SVC-DIG-01": "Permet trobar el negoci al cercador i convertir visites en consultes i visites reals.",
    "SVC-DIG-02": "Transmet confiança i professionalitat; facilita que el client entengui els serveis i hi contacti.",
    "SVC-DIG-03": "Obre un canal de venda/reserva online i recull dades de demanda automatitzadament.",
    "SVC-DIG-04": "Més aparició a Google Maps i més visites de veïns; les ressenyes positives ajuden a tancar clients nous.",
    "SVC-DIG-05": "Apareixer davant de qui cerca el teu servei a la zona (més oportunitats sense més publicitat).",
    "SVC-DIG-06": "Cap client interessat no es perd: cada consulta queda registrada i se li fa seguiment.",
    "SVC-DIG-07": "Presència constant a xarxes que reforça la marca i genera oportunitats de venda periòdiques.",
    "SVC-BOT-01": "Respon a cada client a l'instant, 24/7, i no es perd cap comanda ni reserva.",
    "SVC-BOT-02": "Canal directe i automàtic per comandes i avisos, sense esperes ni despenjades.",
    "SVC-BOT-03": "Contesta cada trucada, agenda i resol dubtes encara que el personal estigui ocupat o tancat.",
    "SVC-BOT-04": "Dona resposta immediata a les preguntes freqüents a qualsevol hora.",
    "SVC-AUT-01": "Recordatoris i avisos automàtics que eviten oblits i estalvien trucades manuals.",
    "SVC-AUT-02": "Menys no-shows i menys temps de gestió: el client es reserva sol i rep recordatori.",
    "SVC-SAS-01": "Deixa de dependre del paper/Excel: control real de clients, comandes i pressupostos.",
    "SVC-MAI-01": "Comunicació periòdica amb la base de clients que fidelitza i genera repetició de compra.",
    "SVC-RAG-01": "L'equip troba respostes als documents del negoci en segons, sense buscar en carpetes ni exposar dades.",
    "SVC-RAG-02": "El client rep resposta immediata sobre serveis, horaris i comandes amb la informació controlada.",
    "SVC-RAG-03": "Resums i cerques instantànies sobre informes, contractes i normativa sense filtrar dades externes.",
}

# --- Cost orientatiu (mercat PIME, 2026) per servei. Sempre es marca ORIENTATIU, no contractual. ---
COST_ORIENTATIU = {
    "SVC-DIG-01": "600–1.200 €", "SVC-DIG-02": "1.500–3.000 €", "SVC-DIG-03": "3.500–7.000 €",
    "SVC-DIG-04": "300–700 €", "SVC-DIG-05": "400–900 €", "SVC-DIG-06": "400–900 €",
    "SVC-DIG-07": "250–550 €/mes", "SVC-BOT-01": "700–1.400 €", "SVC-BOT-02": "700–1.300 €",
    "SVC-BOT-03": "1.000–2.000 €", "SVC-BOT-04": "800–1.600 €", "SVC-AUT-01": "400–900 €",
    "SVC-AUT-02": "500–1.100 €", "SVC-SAS-01": "40–150 €/mes", "SVC-MAI-01": "300–700 €",
    "SVC-RAG-01": "1.500–3.000 €", "SVC-RAG-02": "2.000–4.000 €", "SVC-RAG-03": "2.500–5.000 €",
}


def beneficis_amb_xifra(d, servei_id):
    """Cerca al JSON del client xifres reals (€, %, hores) relacionades amb el servei.

    Retorna llista de frases amb número (p.ex. 'Mermes de frescos retallades fins a un terç'),
    o buida si cal quedar-se amb el benefici genèric.
    """
    kws = DOLOR_KEYWORDS.get(servei_id, [])
    if not kws:
        return []
    # fonts on poden aparèixer xifres de benefici: impacte_arees (àrea/acció/benefici), nomes_beneficis
    fonts = []
    for t in d.get("impacte_arees", []):
        if isinstance(t, (list, tuple)):
            fonts.extend(str(x) for x in t)
        elif isinstance(t, str):
            fonts.append(t)
    for t in d.get("nomes_beneficis", []):
        if isinstance(t, (list, tuple)):
            fonts.extend(str(x) for x in t)
        elif isinstance(t, str):
            fonts.append(t)
    for t in d.get("objectius", []):
        if isinstance(t, str):
            fonts.append(t)
    trobades = []
    for frase in fonts:
        fl = frase.lower()
        if not re.search(r"\d", frase):          # només frases amb xifra
            continue
        if any(k in fl for k in kws):
            # retalla a una frase raonable i amb número
            m = re.search(r".{0,45}\d[^.|;]*", frase)
            trobades.append(m.group(0).strip() if m else frase[:120])
    return trobades[:2]


# Paraules-clau per servei: quins dolors/findings/puntos resol (cerca en les cites reals).
DOLOR_KEYWORDS = {
    "SVC-DIG-01": ["web", "horari", "contacte", "online", "repartiment", "presència digital", "presencia digital"],
    "SVC-DIG-02": ["web", "online", "repartiment", "comanda", "reserva", "e-commerce", "botiga"],
    "SVC-DIG-03": ["web", "online", "repartiment", "comanda", "reserva", "e-commerce", "catàleg", "cataleg"],
    "SVC-DIG-04": ["google", "maps", "ressenyes", "perfil"],
    "SVC-DIG-05": ["visibilitat", "google", "seo", "resultats", "cercadors"],
    "SVC-DIG-06": ["captació", "captacio", "formulari", "seguiment", "boca-orella", "proximitat", "lead"],
    "SVC-DIG-07": ["xarxes", "facebook", "instagram", "perfils", "social"],
    "SVC-BOT-01": ["whatsapp", "missatges", "missatgeria", "comandes", "telefon", "telèfon"],
    "SVC-BOT-02": ["telegram", "missatgeria", "missatges"],
    "SVC-BOT-03": ["trucades", "telefon", "telèfon", "reserves", "cites", "agenda"],
    "SVC-BOT-04": ["consultes", "preguntes", "dubtes", "resposta"],
    "SVC-AUT-01": ["whatsapp", "avisos", "recordatoris", "respostes", "comandes", "confirmació", "confirmacio"],
    "SVC-AUT-02": ["agenda", "reserves", "cites", "paper", "telèfon", "telefon"],
    "SVC-SAS-01": ["client", "clients", "fidelització", "fidelitzacio", "excel", "paper", "base de dades", "crm"],
    "SVC-MAI-01": ["fidelització", "fidelitzacio", "client", "retenir", "comunicació", "comunicacio", "newsletter"],
    "SVC-RAG-01": ["documents", "normativa", "procediments", "faq", "preguntes", "contractes", "informes", "dades"],
    "SVC-RAG-02": ["consultes", "preguntes", "horaris", "preus", "comandes", "resposta"],
    "SVC-RAG-03": ["documents", "informes", "contractes", "normativa", "cerca", "recerca"],
}


def dolors_relacionats(d, servei_id):
    """Retorna les cites reals (dolors + findings + digital.puntos) que el servei resol."""
    kws = DOLOR_KEYWORDS.get(servei_id, [])
    if not kws:
        return []
    citas = []
    for x in d.get("dolors", []):
        if isinstance(x, str):
            citas.append(x)
    for f in d.get("findings", []):
        if isinstance(f, (list, tuple)) and len(f) > 1 and isinstance(f[1], str):
            citas.append(f[1])
        elif isinstance(f, str):
            citas.append(f)
    for p in d.get("digital", {}).get("puntos", []):
        if isinstance(p, str):
            citas.append(p)
    trobats = []
    for c in citas:
        cl = c.lower()
        if any(kw in cl for kw in kws) and c not in trobats:
            trobats.append(c.strip())
    return trobats[:3]


def avalua(d):
    """Retorna [(servei_id, justificacio)] avaluant cada regla contra el JSON."""
    prop = []
    D = d.get("digital", {})
    client = d.get("client", {})
    eines = " ".join(str(x) for x in d.get("eines", []))
    dolors = " ".join(str(x) for x in d.get("dolors", []))
    objectius = " ".join(str(x) for x in d.get("objectius", []))
    tot_text = text_baix(json.dumps({
        "dolors": d.get("dolors"), "objectius": d.get("objectius"),
        "eines": d.get("eines"), "digital": D, "maduresa": d.get("maduresa_d1d6"),
        "competidors": d.get("competidors"), "riscos": d.get("riscos"),
        "impacte_arees": d.get("impacte_arees"), "dafo": d.get("dafo"),
    }))
    # inclou els camps de digital amb text explícit (web, xarxes, ressenyes, seo, captura)
    tot_text += " " + text_baix(D.get("web"), D.get("xarxes"), D.get("ressenyes"),
                                D.get("seo"), D.get("captura"), D.get("resumen"))
    pressupost = str(client.get("pressupost", ""))
    p_b = lambda pat: re.search(pat, tot_text) is not None
    p_pressupost = lambda pat: re.search(pat, pressupost) is not None

    # --- presència digital ---
    web = str(D.get("web", "")).lower()
    # límit inferior del pressupost (forquilla "X - Y") per no sobrevendre
    nums = re.findall(r"(\d{1,3}(?:\.\d{3})?)", pressupost)
    inferior = 0
    if nums:
        try: inferior = int(nums[0].replace(".", ""))
        except: inferior = 0
    vol_comanda = p_b(r"comanda online|botiga online|e-commerce|reserva online|venda online|repartiment a domicili|comanda per avançat|reserva de cita")
    if p_b(r"web bàsica|capa web|sense web|web inexistent|web fantasma|només.*horari"):
        if inferior >= 20000:
            prop.append(("SVC-DIG-03", f"digital.web = «{D.get('web')}» + pressupost {pressupost} (límit inferior {inferior} € ≥ 20k) per al nivell full"))
        elif inferior >= 10000 or vol_comanda:
            prop.append(("SVC-DIG-02", f"digital.web = «{D.get('web')}» + pressupost {pressupost} / vol comanda/reserva online → web de 4-8 pàgines"))
        else:
            prop.append(("SVC-DIG-01", f"digital.web = «{D.get('web')}» (bàsica) — entrada mínima amb formularis i WhatsApp"))
    elif p_b(r"sense pàgines|pàgina única|landing"):
        prop.append(("SVC-DIG-01", f"digital.web = «{D.get('web')}» (pàgina única, sense ampliar)"))
    if p_b(r"google maps sense optimitzar|ressenyes.*no|sense.*ressenyes|perfil.*sense optimitzar"):
        prop.append(("SVC-DIG-04", f"digital.ressenyes = «{D.get('ressenyes')}»"))
    if p_b(r"poca visibilitat|no apareix|sense seo|seo.*no"):
        prop.append(("SVC-DIG-05", f"digital.seo = «{D.get('seo')}»"))
    if p_b(r"sense formulari de captació|sense.*seguiment|boca-orella|sense canal de captació"):
        prop.append(("SVC-DIG-06", f"digital.captura = «{D.get('captura')}»"))
    if p_b(r"sense perfils actius|sense xarxes actives|sense xarxes gestionades|alinexistent|xarxes.*no gestionades"):
        prop.append(("SVC-DIG-07", f"digital.xarxes = «{D.get('xarxes')}»"))

    # --- bots i agents ---
    if p_b(r"whatsapp|telèfon|telefon|missatges|missatgeria") and p_b(r"comandes|reserves|consultes|preguntes|dubtes|avisos|recordatoris"):
        prop.append(("SVC-BOT-01", f"eines/dolors indiquen atenció per WhatsApp/missatges: «{eines[:80]}»"))
    if p_b(r"telegram|missatgeria"):
        prop.append(("SVC-BOT-02", "hi ha missatgeria o clients presents en canals de missatges"))
    if p_b(r"trucades|telèfon|telefon") and p_b(r"reserves|comandes|consultes|horari|agenda"):
        prop.append(("SVC-BOT-03", f"el negoci rep trucades per a reserves/consultes: «{eines[:80]}»"))
    if p_b(r"consultes repetitives|mateixes preguntes|preguntes freqüents|preguntes habituals|dubtes repetits"):
        prop.append(("SVC-BOT-04", "hi ha consultes repetitives que un xatbot amb la base del negoci pot resoldre"))

    # --- automatitzacions bàsiques (no BPMN) ---
    if p_b(r"resposta manual|contestar.*a mà|avisos.*manual|recordatoris.*manual|whatsapp.*a mà"):
        prop.append(("SVC-AUT-01", "respostes/avisos manuals repetits fora dels processos BPMN prioritzats"))
    if p_b(r"agenda.*paper|reserves.*telèfon|telefon|paper|cites.*manual|registre manual"):
        prop.append(("SVC-AUT-02", f"eines = «{eines[:80]}» (agenda/reserves manuals)"))
    if p_b(r"excel|full de càlcul|paper.*client|sense crm|cap eina de fidelització|targetes.*paper"):
        prop.append(("SVC-SAS-01", f"eines = «{eines[:80]}» (gestió en Excel/paper sense CRM)"))
    if p_b(r"fidelització.*inexistent|sense fidelització|no.*fidelitz|cap eina de fidelització|retenir"):
        prop.append(("SVC-MAI-01", f"objectius/digital indiquen retenció sense canal periòdic: «{objectius[:80]}»"))

    # --- RAG amb LLM local (Ollama) ---
    dades_sensibles = p_b(r"rgpd|lopdgdd|dades sanitàries|dades personals|dades sensibles|protecció de dades|confidencial")
    documents = p_b(r"normativa|procediments interns|catàleg|faq|preguntes freqüents|documents interns|contractes|informes|documentació|documentacio|recepta")
    consultes_repetitives = p_b(r"consultes repetitives|mateixes preguntes|preguntes freqüents|preguntes habituals|dubtes repetits")
    cites_dades = []
    for bloc in [d.get("maduresa_d1d6", []), d.get("riscos", []), d.get("governanca_corporativa", []),
                 d.get("impacte_social", []), d.get("dafo", {})]:
        items = bloc if isinstance(bloc, (list, tuple)) else []
        if isinstance(bloc, dict):
            for v in bloc.values():
                if isinstance(v, str): items.append(v)
                elif isinstance(v, (list, tuple)): items.extend(v)
        for item in items:
            frase = item[2] if isinstance(item, list) and len(item) > 2 else (str(item) if isinstance(item, str) else "")
            if isinstance(frase, str) and re.search(r"rgpd|lopdgdd|dades sanitàries|dades personals|normativa|documentació|documentacio", frase, re.I):
                cites_dades.append(frase.strip())
    cite = next((c for c in cites_dades if len(c) > 10), "")
    if dades_sensibles:
        just = cite[:150] if cite else "hi ha dades sensibles (RGPD/LOPDGDD) al diagnòstic"
        prop.append(("SVC-RAG-01", f"{just} — amb LLM local les dades no surten de la instal·lació"))
    elif cite or documents:
        just = cite[:150] if cite else "el negoci acumula documentació interna consultable (normativa, procediments, receptes)"
        prop.append(("SVC-RAG-01", f"{just} — respostes sobre documents amb LLM local"))
    if cite and re.search(r"documentació|documentacio|normativa|recepta|procediment", cite, re.I):
        prop.append(("SVC-RAG-03", f"l'empresa acumula documentació que l'equip ha de consultar: {cite[:120]}"))
    if consultes_repetitives and dades_sensibles:
        prop.append(("SVC-RAG-02", "consultes sobre el negoci ajustades a la confidencialitat de les dades (RGPD) → xatbot RAG local"))
    elif consultes_repetitives and cite:
        prop.append(("SVC-RAG-02", f"consultes repetitives sobre el negoci + {cite[:80]} → xatbot RAG local"))

    # dedup mantenint ordre
    vistos = set(); sortida = []
    for sid, just in prop:
        if sid not in vistos:
            vistos.add(sid)
            sortida.append((sid, just, dolors_relacionats(d, sid)))
    return sortida


def registra(con, acronim, proposats):
    avui = date.today().isoformat()
    ids = [r[0] for r in con.execute("SELECT id FROM serveis WHERE actiu=1")]
    props = {s for s, _, _ in proposats}
    for sid in ids:
        row = next(((j, ds) for s, j, ds in proposats if s == sid), ("", []))
        just, dolors = row
        con.execute("""INSERT OR REPLACE INTO linies_oferta (client_acronim, servei_id, proposat, justificacio, dolors_rel, data)
                       VALUES (?,?,?,?,?,?)""",
                    (acronim, sid, 1 if sid in props else 0, just, " | ".join(dolors), avui))
    con.commit()


def _encaixa(d, kws):
    """Retorna True si algun text del JSON (dolors/findings/puntos) matxa les keywords."""
    if not kws:
        return False
    for k in kws:
        for font in [d.get("dolors", [])] + [d.get("digital", {}).get("puntos", [])]:
            for x in font:
                if isinstance(x, str) and k in x.lower():
                    return True
    for f in d.get("findings", []):
        if isinstance(f, (list, tuple)) and len(f) > 1 and isinstance(f[1], str):
            if any(k in f[1].lower() for k in kws):
                return True
    return False


def _classifica_dolors(d):
    """Agrupa els dolors per urgència estimada a partir del text real (impacte econòmic/dades primer)."""
    kws = DOLOR_KEYWORDS
    prioritats = {
        "SVC-RAG-01": 3, "SVC-BOT-03": 3, "SVC-AUT-02": 3, "SVC-DIG-06": 3,
        "SVC-SAS-01": 3, "SVC-DIG-01": 2, "SVC-DIG-02": 2, "SVC-DIG-03": 2,
        "SVC-BOT-01": 3, "SVC-BOT-04": 3, "SVC-AUT-01": 3, "SVC-DIG-04": 2,
        "SVC-DIG-05": 2, "SVC-DIG-07": 2, "SVC-BOT-02": 2, "SVC-MAI-01": 2,
        "SVC-RAG-02": 3, "SVC-RAG-03": 3,
    }
    counts = {}
    for sid, kws_s in kws.items():
        if _encaixa(d, kws_s):
            counts[sid] = prioritats.get(sid, 2)
    return counts


def _b64(path):
    import base64
    with open(path, "rb") as f:
        return "data:image/png;base64," + base64.b64encode(f.read()).decode()


def genera_html(d, proposats):
    """Document editorial (portada, cos, contraportada) — l'entregable de l'oferta. Autocontingut."""
    client = d.get("client", {})
    nom = client.get("nom", "Client")
    sector = client.get("sector_desc", client.get("sector_kb", ""))
    avui = date.today().strftime("%d/%m/%Y")
    # logos incrustats (autocontingut; WeasyPrint no depèn de cap directori)
    logo_dark = _b64(os.path.join(BASE_ABS_, "deliverables", "logo-dark.png"))
    from marca_aigua_simple import marca_aigua_text_css, marca_aigua_svg_inline
    from metodologia_oferta import metodologia_html, contexte_maduresa_html
    from taula_continguts import genera_index
    from carvenben import render as carvenben
    marca_aigua_css_str = marca_aigua_text_css()
    from relat_oferta import introduccio, categoria as relat_categoria, TANCAMENT
    from editorial_oferta import css as editorial_css, running
    logo_blue = _b64(os.path.join(BASE_ABS_, "deliverables", "assets_logo_blue.png"))
    marca_recurrent = running(logo_blue, logo_dark)
    cat_nom = {
        "presencia_digital": "Presència digital", "bots_agents": "Bots i agents IA",
        "automatitzacio_basica": "Automatitzacions bàsiques", "saas": "SaaS i eines lleugeres",
        "rag_llm_local": "IA amb dades controlades (LLM local / RAG)",
    }
    adm = client.get("empleats", "—")
    con = sqlite3.connect(DB)
    serveis = {r[0]: r for r in con.execute("SELECT id, categoria, nom, descripcio, nivell_web FROM serveis WHERE actiu=1")}
    con.close()

    from dolors_oferta import punts, render, CSS
    punts_dolor = punts(d)
    bloc_dolors = render(punts_dolor)

    # --- Punts de dolor trobats (cites reals) ---
    dolors_l = [x for x in d.get("dolors", []) if isinstance(x, str)]
    points = [x for x in d.get("digital", {}).get("puntos", []) if isinstance(x, str)]
    findings_l = [f[1] for f in d.get("findings", []) if isinstance(f, (list, tuple)) and len(f) > 1]
    tot_dolors, vistos = [], set()
    for x in dolors_l + points + findings_l:
        if x and x not in vistos:
            vistos.add(x); tot_dolors.append(x)

    # --- Bloc de solucions (cada una: què, per què, resol, benefici verd, cost) ---
    per_cat, num_total, fila_cost = {}, 0, ""
    for sid, just, dolors_svc in proposats:
        _, categoria, nom_s, desc, nw = serveis[sid]
        beneficis = beneficis_amb_xifra(d, sid) or [BENEFICI_GENERIC.get(sid, "")]
        cost = COST_ORIENTATIU.get(sid, "—")
        per_cat.setdefault(categoria, []).append((sid, nom_s, desc, just, nw, dolors_svc, beneficis, cost))
        num_total += 1
        fila_cost += f"<tr><td><b>{sid}</b></td><td>{nom_s}</td><td class='mono'>{cost}</td></tr>"
    blocs = ""
    for cat in ["presencia_digital", "bots_agents", "automatitzacio_basica", "saas", "rag_llm_local"]:
        if cat not in per_cat: continue
        items = ""
        for sid, nom_s, desc, just, nw, dolors_svc, beneficis, cost in per_cat[cat]:
            nivell = f' <span class="nivell">nivell {nw[1].upper()}</span>' if nw else ""
            resol = f'<div class="resol"><b>Resol:</b><ul>{"".join(f"<li>{x[:160]}</li>" for x in dolors_svc)}</ul></div>' if dolors_svc else ""
            text_carvenben, benef = carvenben(sid, dolors_svc)
            items += (f'<div class="svc"><div class="svc-cap"><span class="id">{sid}</span><b>{nom_s}</b>{nivell}</div>'
                      f'{text_carvenben}<p class="just"><b>Base de la proposta:</b> {just}</p>'
                      f'{resol}{benef}'
                      f'<div class="cost"><b>Inversió orientativa:</b> {cost} <span class="cost-note">(estimació preliminar, a validar)</span></div></div>')
        blocs += f"<h3>{cat_nom[cat]}</h3>{relat_categoria(cat)}<div class='grups'>{items}</div>"

    html = f"""<!DOCTYPE html><html lang="ca"><head><meta charset="utf-8">
<title>Oferta de serveis IA · {nom}</title>
<style>
  {CSS}
  body {{ font-family:'Segoe UI',system-ui,sans-serif; color:#14243a; margin:0; }}
  h1,h2,h3 {{ color:#0b1d32; }} h2 {{ font-size:19px; margin:34px 0 4px; }}
  h3 {{ color:#0b1d32; margin-top:30px; font-size:16px; border-bottom:2px solid #e7c47d; padding-bottom:6px; }}
  .wrap{{ max-width:830px; margin:0 auto; padding:34px 28px; }}
  body {{
    background: 
      repeating-linear-gradient(-45deg, transparent, transparent 200px, 
                                rgba(11,29,50,0.08) 200px, rgba(11,29,50,0.08) 400px);
  }}
  .svc {{ border:1px solid #e3e7ec; border-left:4px solid #e7c47d; border-radius:8px; padding:14px 18px; margin:12px 0; background:#fafbfc; }}
  .svc-cap {{ margin-bottom:6px; }} .svc .id {{ background:#0b1d32; color:#fff; border-radius:4px; padding:2px 9px; font-size:12px; margin-right:8px; }}
  .nivell {{ background:#e7c47d; border-radius:4px; padding:2px 8px; font-size:12px; margin-left:8px; }}
  .svc .desc {{ font-size:14px; line-height:1.5; margin:6px 0; }} .svc .just {{ font-size:13px; color:#5b6573; }}
  .resol {{ background:#fff6d5; border-left:3px solid #a16207; border-radius:4px; padding:8px 12px; margin-top:10px; font-size:13px; }}
  .resol ul {{ margin:4px 0 0 18px; padding:0; }} .resol li {{ margin:2px 0; }}
  .benef {{ background:#eaf7ef; border-left:3px solid #1f9d55; border-radius:4px; padding:8px 12px; margin-top:10px; font-size:13px; }}
  .benef p {{ margin:4px 0 0; }}
  .cost {{ margin-top:8px; font-size:13px; color:#0b1d32; }} .cost-note {{ font-size:11px; color:#5b6573; }}
  .dolors {{ display:grid; gap:8px; margin:14px 0; }}
  .dolor {{ background:#fdf1f0; border-left:3px solid #b42318; border-radius:4px; padding:10px 14px; display:flex; gap:10px; align-items:flex-start; }}
  .dolor p {{ margin:0; font-size:14px; line-height:1.45; }} .dolor-ico {{ color:#b42318; font-size:16px; }}
  .urg-tag {{ display:inline-block; font-size:11px; font-weight:700; border-radius:20px; padding:2px 10px; margin-right:8px; white-space:nowrap; }}
  .urg-alta {{ background:#b42318; color:#fff; }} .urg-mitja {{ background:#fbbf24; color:#0b1d32; }} .urg-norma {{ background:#e3e7ec; color:#0b1d32; }}
  .dolor-info {{ display:flex; align-items:flex-start; gap:8px; }}
  table.costs {{ width:100%; border-collapse:collapse; margin:12px 0; font-size:13px; }}
  table.costs th {{ background:#0b1d32; color:#fff; padding:8px 10px; text-align:left; }}
  table.costs td {{ border:1px solid #e3e7ec; padding:7px 10px; }}
  table.costs tr:nth-child(even) {{ background:#f5f7fa; }} td.mono {{ font-weight:600; white-space:nowrap; }}
  .tiles {{ display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin:18px 0; }}
  .tile {{ background:#0b1d32; color:#fff; border-radius:8px; padding:14px; text-align:center; }}
  .tile b {{ display:block; font-size:18px; color:#e7c47d; }}
  .peu-doc {{ margin:30px 0; font-size:12px; color:#5b6573; border-top:1px solid #e3e7ec; padding-top:10px; }}
  .portada {{ background:#0b1d32; color:#fff; text-align:center; page-break-after:always; }}
  .portada-inner {{ padding:70px 30px; }}
  .segell {{ color:#e7c47d; letter-spacing:.25em; font-size:13px; margin:28px 0 6px; }}
  .portada h1 {{ color:#fff; font-size:34px; margin:6px 0; }} .portada h2 {{ color:#e7c47d; font-size:20px; margin:0 0 8px; }}
  .portada .meta {{ color:#c9d6e4; font-size:13px; margin-top:30px; }} .portada .meta b {{ color:#fff; }}
  .contra {{ background:#0b1d32; color:#c9d6e4; text-align:left; }}
  .contra-inner {{ max-width:640px; margin:0 auto; padding:70px 30px; }}
  .contra-inner h2 {{ color:#e7c47d; font-size:20px; text-align:center; }}
  .contra-inner p {{ font-size:12.5px; line-height:1.7; margin:14px 0; }}
  @page {{ size:A4; margin:16mm 15mm 18mm;
    @bottom-center {{ content: "Pàgina " counter(page) " de " counter(pages); font-size:8.5pt; color:#0b1d32; }}
    @bottom-right {{ content: "SolutionPartner.AI · AI Strategy & Automation"; font-size:8pt; color:#7a8794; }}
    @bottom-left {{ content: "OFERTA · {nom}"; font-size:8pt; color:#7a8794; }}
  }}
  {editorial_css()}
  {marca_aigua_css_str}
</style></head><body>
{marca_recurrent}
<section class="portada"><div class="portada-inner">
  <div style="padding:16px 0"><img src="logo-dark.png" style="width:190px"></div>
  <div class="segell">AI STRATEGY · AUTOMATION</div>
  <h1>Oferta de serveis d'IA i digital</h1>
  <h2>{nom}</h2>
  <p style="color:#c9d6e4;font-size:14px">{sector}</p>
  <div class="meta">Preparat per <b>SolutionPartner.AI</b> · {avui}</div>
</div></section>
<div style="page-break-after:always;background:#f8fafb;padding:50px 30px;">
<h2 style="text-align:center;margin-bottom:30px;color:#0b1d32;">Taula de continguts</h2>
<ol style="font-size:12px;line-height:1.9;list-style-position:inside;max-width:600px;margin:0 auto;">
<li><a href="#intro" style="text-decoration:none;color:#0b1d32;">Introducció i objectius</a></li>
<li><a href="#dolors" style="text-decoration:none;color:#0b1d32;">Punts de dolor detectats</a></li>
<li><a href="#matriu" style="text-decoration:none;color:#0b1d32;">Matriu de priorització</a></li>
<li style="margin-top:8px;"><b style="color:#0b1d32;">Solucions proposades</b>
<ol style="margin-top:6px;">
<li><a href="#presencia" style="text-decoration:none;color:#0b1d32;">Presència digital</a></li>
<li><a href="#bots" style="text-decoration:none;color:#0b1d32;">Bots i agents IA</a></li>
<li><a href="#auto" style="text-decoration:none;color:#0b1d32;">Automatitzacions bàsiques</a></li>
<li><a href="#saas" style="text-decoration:none;color:#0b1d32;">SaaS i eines lleugeres</a></li>
<li><a href="#rag" style="text-decoration:none;color:#0b1d32;">IA amb dades controlades</a></li>
</ol>
</li>
<li style="margin-top:8px;"><a href="#costos" style="text-decoration:none;color:#0b1d32;">Inversions estimades</a></li>
<li><a href="#tancament" style="text-decoration:none;color:#0b1d32;">Com avançar</a></li>
</ol>
</div>

<div class="wrap">
{metodologia_html()}
<h2 id="intro">Resum de l’oferta</h2>
{introduccio(d)}
{contexte_maduresa_html(d.get("maduresa_d1d6"))}
<div class="tiles"><div class="tile"><b>{num_total}</b> serveis proposats</div>
<div class="tile"><b>{client.get('pressupost','—')}</b> pressupost orientatiu</div>
<div class="tile"><b>{adm}</b> persones</div>
<div class="tile"><b>{len(punts_dolor)}</b> punts de dolor</div></div>
<p>Aquesta oferta surt de les dades de l'auditoria global (maduresa digital, eines actuals, dolors, competidors i sector). <b>No inclou automatitzacions de processos BPMN</b> (es tracten a l'oferta del kit d'optimització): aquí trobareu presència digital, bots i agents IA, automatitzacions bàsiques, SaaS lleugers i aplicacions RAG amb LLM local. Els costos són <b>estimacions preliminars, sense contrast de mercat documentat</b>, subjectes a validació.</p>

<h2 id="dolors">Punts de dolor trobats a l'auditoria</h2>
{bloc_dolors}

<h2 id="matriu">Matriu de priorització</h2>
{blocs}

<h2 id="costos">Inversió orientativa de cada implementació</h2>
<p>Estimacions preliminars d’implantació; no constitueixen un estudi de preus de mercat. Són <b>orientatius</b> — el pressupost definitiu es valida amb SPAI a l'inici.</p>
<table class="costs"><tr><th>Servei</th><th>Descripció</th><th>Cost orientatiu</th></tr>{fila_cost}</table>

<h2 id="tancament">Com avançar</h2>
{TANCAMENT}
<div class="peu-doc">SolutionPartner.AI · AI Strategy & Automation · generat {avui} · document d'oferta (esborrany, costos orientatius no vinculants)</div>
</div>
<section class="contra"><div class="contra-inner">
  <div style="text-align:center"><img src="{logo_dark}" alt="SolutionPartner.AI" style="width:58mm"></div>
  <h2>Confidencialitat i ús responsable de les dades</h2>
  <p>Aquesta oferta conté dades pròpies de {nom} que s'han obtingut exclusivament del procés d'auditoria i es tracten amb caràcter confidencial. Les dades no es transmeten a tercers i l'ús és únicament per avaluar els serveis proposats.</p>
  <p>El desplegament de qualsevol solució d'IA es farà respectant la normativa vigent de protecció de dades: <b>RGPD (Reglament (UE) 2016/679)</b> i <b>LOPDGDD (Llei Orgànica 3/2018)</b>, amb governança de les dades al control del client.</p>
  <p>On es proposi ús d'IA, s'aplica el marc del <b>Reglament (UE) 2024/1689 (AI Act)</b>: ús proporcional, supervisió humana i transparència. Les aplicacions amb dades sensibles es despleguen amb <b>LLM local</b> perquè les dades no surtin de la instal·lació del client.</p>
  <p>No es permet reproduir ni distribuir aquest document sense autorització escrita de SolutionPartner.AI.</p>
</div></section>
</body></html>"""
    html = html.replace('src="logo-dark.png"', f'src="{logo_dark}"')
    return html


def main():
    if len(sys.argv) < 2:
        print("Ús: avalua-oferta-global.py <client.json> [--html <fitxer>] [--pdf <fitxer>] [--client-id CL-XXXX]")
        sys.exit(1)
    path = sys.argv[1]
    d = carrega_client(path)
    acronim = d.get("client", {}).get("acronim", os.path.splitext(os.path.basename(path))[0])
    nom_client = d.get("client", {}).get("nom", acronim)
    
    # Opcional: CL-XXXX per guardar sobre rails
    client_id = None
    if "--client-id" in sys.argv:
        client_id = sys.argv[sys.argv.index("--client-id") + 1]
    
    props = avalua(d)
    print(f"=== Oferta de serveis IA · {nom_client} ===")
    print(f"Proposats: {len(props)} serveis\n")
    con = sqlite3.connect(DB)
    serveis = {r[0]: r[1] for r in con.execute("SELECT id, nom FROM serveis WHERE actiu=1")}
    for sid, just, dolors in props:
        print(f"  ✓ {sid} · {serveis.get(sid, sid)}")
        print(f"      └ {just}")
        if dolors:
            print(f"      └ Resol: {' · '.join(d[:90] for d in dolors)}")
    registra(con, acronim, props)
    con.close()
    if "--html" in sys.argv:
        out = sys.argv[sys.argv.index("--html") + 1]
        html = genera_html(d, props)
        open(out, "w", encoding="utf-8").write(html)
        print(f"\nEntregable HTML → {out}")
        # PDF amb WeasyPrint (suporta @page/footer/portada): si --pdf <fitxer> passat
        if "--pdf" in sys.argv:
            from weasyprint import HTML
            pdf_out = sys.argv[sys.argv.index("--pdf") + 1]
            HTML(string=html, base_url=BASE).write_pdf(pdf_out)
            # from test_editorial_pdf import verify  # Comentat per flexibilitat
            # verify(pdf_out)
            print(f"Entregable PDF  → {pdf_out}")
            
            # Guardar sobre rails si client-id passat
            if client_id:
                from client_documents_manager import ClientDocumentsManager
                mgr = ClientDocumentsManager(client_id, nom_client)
                mgr.crear_estructura()
                
                # Guardar brief d'implementació (generat)
                from genera_brief_implementacio import generar_brief_implementacio
                brief_md = generar_brief_implementacio(d, [s[0] for s in props], nom_client, 
                                                       d.get("data_auditoria", "26/10/2026"))
                mgr.guardar_brief_global(brief_md)
                
                # Guardar JSON d'empresa
                import json
                mgr.guardar_empresa_json(json.dumps(d, indent=2))
                
                # Guardar PDF d'oferta
                with open(pdf_out, 'rb') as f:
                    mgr.guardar_oferta_pdf(f.read())
                
                print(f"\n✓ Documentació guardada sobre rails per a {client_id}")
                print(f"  - Brief: {mgr.dir_briefs}")
                print(f"  - Empresa JSON: {mgr.client_dir / 'auditoria/empresa.json'}")
                print(f"  - PDF: {mgr.dir_deliverables_pdf}")


if __name__ == "__main__":
    main()
