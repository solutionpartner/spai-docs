"""Generator de Brief d'Implementació: document MD intern per a Claude sobre quines solucions tècniques crear."""

from datetime import date
from html import escape
import json


TEMPLATE_SERVEI = '''### {num}. [{sid}] {nom_servei}

**Oferta al document d'oferta:** {titul_oferta}

**Problema que resol:** {dolor_lligat}

**Característiques (què inclou):** {caracteristiques}

**Avantatges (com facilita el dia a dia):** {avantatges}

**Benefici espertat (què hi guanya el client):** {benefici}

**Cost orientatiu:** {cost} (estimació preliminar, a validar amb client)

---

#### Solucions tècniques necessàries:
{solucions_tecniques}

#### Preguntes que Claude ha de fer al client/Josep:
{preguntes_clients}

#### Que ha de cercar Claude (web, documentació, referents):
{que_cercar}

#### Criteri d'acceptació i validació:
{criteris_validacio}

#### Dades de la proposició (des de JSON auditoria):
- Dolor/finding lligat: `{dolor_ref}`
- Priortat matriu: `{prioritat}`
- Maduresa actual (relevant): `{maduresa_rel}`
- Dependències: {dependencies}

#### Responsabilitat i calendari estimat:
- **Responsable:** [Josep/Claude/Hybrid]
- **Termini estimat:** [a validar amb client]
- **Fases:** {fases}

---
'''

# Per a cada tipus de servei, s'especifica:
# - solucions_tecniques: quines tecnologies/eines usar
# - preguntes_clients: que ha de preguntar Claude al client
# - que_cercar: quins recursos/referents investigar
# - criteris_validacio: com saber que funciona

SPECS_SERVEI = {
    'SVC-DIG-01': {
        'solucions_tecniques': '''- **Plataforma web:** Landing page de 1-2 pàgines (Hugo, Next.js estàtic, o builder visual)
- **Formulari de contacte:** Web3Forms, Formspree, o endpoint personalitzat
- **Hosting:** GitHub Pages, Vercel, Netlify o servidor propi
- **DNS i dominio:** Configuració de registre A/CNAME
- **SSL/HTTPS:** Certificat automatitzat (Let's Encrypt o proveïdor)
- **Analytics:** Google Analytics 4 o Plausible
- **SEO bàsic:** Metaetiquetes, sitemap.xml, robots.txt''',
        'preguntes_clients': '''- ¿Tenim dominio disponible? ¿Registrat o per registrar?
- ¿Qui escriu el contingut (text, imatges)? ¿Tenim brand kit?
- ¿Quin és el CTA principal (contactar, telefon, formulari)?
- ¿Cal integrar amb cap email/CRM existent?
- ¿Budget definitiu és dins dels 600-1.200€?
- ¿Termini: quina velocitat?''',
        'que_cercar': '''- Comparativa builders web low-code 2026 (Framer vs. Webflow vs. Builder.io)
- Templates "contacte + serveis" professionals per sector
- Guía de SEO local 2026 per a PIMEs
- Optimització Core Web Vitals (LCP, FID, CLS)
- Seguretat formularis (CSRF, rate limiting)''',
        'criteris_validacio': '''- Landing page en viu i accessible a URL pública (https)
- Formulari enviant dades correctament (email de confirmació al client)
- Lighthouse score >= 80 (Performance, Accessibility, Best Practices, SEO)
- Temps de càrrega < 2s (primer paint)
- Mobile responsive (testejar manalment a telèfon)
- Logo, colors i fonts de marca aplicats correctament
- Test de SEO local (títol, meta description, schema markup)''',
        'fases': 'Fase 1: Disseny i draft (1 setmana) → Fase 2: Integració formulari (3-5 dies) → Fase 3: Optimització SEO i performance (3-5 dies) → Fase 4: Testing i deploy (2-3 dies)'
    },
    'SVC-DIG-02': {
        'solucions_tecniques': '''- **Plataforma web:** Next.js / React (SSG), Hugo, o Webflow (si prefereix visual)
- **Estructura:** 4-8 pàgines (Inici, Sobre nosaltres, Serveis/Productes, Contacte, Blog/Resources, FAQ)
- **CMS optional:** Markdown (GitHub/GitBook), Strapi, o editor visual (Webflow, Builder.io)
- **Formularis:** Web3Forms, Formspree, o subbmit a API REST
- **Integració:** API externa si cal (Calendly, Calendars.ai, HubSpot forms)
- **Hosting:** Vercel (Next.js native), Netlify, o servidor compartit
- **CDN/Performance:** Cloudflare, Bunny CDN o CDN de proveïdor
- **Analytics + Heatmap:** Google Analytics 4 + Hotjar o Clarity
- **SEO avançat:** Schema markup (LocalBusiness, Product, FAQ), Sitemap dinàmic, Blog''',
        'preguntes_clients': '''- ¿Quines pàgines són imprescindibles (portàfoli, preu, blog, FAQ)?
- ¿Tenim contingut escrit o fem brainstorming?
- ¿Cal gestionar el blog des de CMS o HTML estàtic?
- ¿Integració amb Calendly, HubSpot, Zapier, etc.?
- ¿Vols anàlisi de comportament (heatmaps) o només Google Analytics?
- ¿Budget definitiu és dins dels 1.200-3.500€?''',
        'que_cercar': '''- Comparativa CMS 2026 per a agencies (Strapi vs. Payload CMS vs. Sanity)
- Templates de web de serveis (d'agencia, consultoria) amb Next.js
- Estratègia de contingut 2026 per al sector
- Optimització per a conversió (CRO) — landing page principles
- Blog strategy: freqüència, tòpics, SEO
- Integració de booking systems (Calendly API, Acuity Scheduling)''',
        'criteris_validacio': '''- 4-8 pàgines en producció, indexades a Google
- Formulari funcional (email de confirmació + ingesta a CRM si cal)
- Blog o recursos actualitzables sense codi
- Lighthouse score >= 85 (tots els apartats)
- Temps de primera interacció (FID) < 100ms
- Test de converció: formulari visible a [totes] les pàgines clau
- Google Search Console: 0 errors d'indexació
- Mobile test en dispositius reals (telèfon + tauleta)''',
        'fases': 'Fase 1: Estructura i wireframes (1 setmana) → Fase 2: Contingut + disseny (2 setmanes) → Fase 3: Desenvolvimento i integrations (2 setmanes) → Fase 4: SEO audit + optimització (1 setmana) → Fase 5: Testing i deploy (3-5 dies)'
    },
    'SVC-DIG-04': {
        'solucions_tecniques': '''- **Google Business Profile:** Creació o optimització de perfil existent
- **Gestió de ressenyes:** Dashboard de moderació (Google My Business, Birdeye, o script personalitzat)
- **Schema markup:** LocalBusiness, AggregateRating structured data
- **Review collection:** Email automàtic post-servei o link a ressenyes
- **Resposta automàtica inicial:** Template de resposta per a reviews noves
- **Fotos i vídeos del negoci:** Càrrega a Google Business, Instagram
- **Horari, ubicació, telèfon:** Sincronitzat amb web principal''',
        'preguntes_clients': '''- ¿Tenim Google Business Profile creat? ¿Accés disponible?
- ¿Quantes ressenyes tenim actualment?
- ¿Qui respon les ressenyes (Josep, client o tercers)?
- ¿Cal automatitzar la sollicitud de ressenyes (post-cita, post-compra)?
- ¿Preferència: Google My Business, Birdeye, o script propi?''',
        'que_cercar': '''- Guía complet Google Business Profile 2026 (algoritme de visibilitat)
- Estratègia de review generation 2026 (legal + étic)
- Tools de gestió de reputació online (Birdeye vs. Trustpilot vs. solutions custom)
- Schema markup per a negocis locals (restauració, clínica, taller)
- Impact de reviews en CTR i conversió (estudis de cas)''',
        'criteris_validacio': '''- Google Business Profile completat al 100% (totes les seccions)
- Mínim 5-10 ressenyes amb rating >= 4.5/5
- Respostes a totes les ressenyes noves dins de 24h
- Fotos/vídeos del negoci visible al perfil
- Horari, telèfon i ubicació correctes (sense warnings de Google)
- Direcció verificada per Google
- Schema markup validat (Google Structured Data Testing Tool)''',
        'fases': 'Fase 1: Auditoria perfil actual (2-3 dies) → Fase 2: Optimització metadata i imatges (1 setmana) → Fase 3: Estratègia de ressenyes + automatització (1 setmana) → Fase 4: Monitoring i respostes (continu, 30min/setmana)'
    },
    'SVC-BOT-01': {
        'solucions_tecniques': '''- **Plataforma bot:** Twilio (WhatsApp API oficial) o N8N (flow visual)
- **LLM backend:** OpenAI (GPT-4 mini), Anthropic (Claude), o LLM local (Ollama)
- **Orchestrator:** N8N, Make (Integromat), o backend personalitzat (Node.js/Python)
- **Knowledge base:** JSON estructurat, base de dades, o RAG simple (Pinecone, Weaviate, LlamaIndex)
- **Integració CRM:** Zapier/N8N → HubSpot, Salesforce, o Google Sheets
- **Moderació:** Human handoff si pregunta fora de scope
- **Analytics:** Logs de conversa, sentiment analysis opcional''',
        'preguntes_clients': '''- ¿Vols WhatsApp oficial (Twilio) o simulator per a testing?
- ¿Quins tipus de preguntes ha de respondre el bot?
- ¿Cal integrar amb CRM per a captura de leads?
- ¿Budget: LLM en cloud (OpenAI) o model local (Ollama)?
- ¿Resposta human si el bot no entén (handoff)?''',
        'que_cercar': '''- Comparativa Twilio vs. oficial WhatsApp API 2026
- LLM comparison 2026: cost, latència, qualitat per a customer service
- Estratègia de training de bots (few-shot prompting vs. RAG)
- N8N vs. Make vs. backend personalitzat per a bots
- Casos d'ús WhatsApp bot per a sector [sector]
- Compliment legal (RGPD, LOPDGDD) para conversacions WhatsApp''',
        'criteris_validacio': '''- Bot responen dins de 2-3 segons
- Resposta exacta a preguntes de prova (test cases)
- Handoff a human funciona correctament
- Conversacions loguejades per a auditoria
- Sentiment dels usuaris positiu (test amb usuaris reals)
- Integració CRM verifica: leads capturats correctament
- Compliant RGPD: dades eliminades al termini acordat''',
        'fases': 'Fase 1: Definició de scope + preguntes frecuents (1 setmana) → Fase 2: Deployment bot + training (2 setmanes) → Fase 3: Testing i human handoff (1 setmana) → Fase 4: Monitoring i millora contínua (semanal)'
    },
    'SVC-AUT-02': {
        'solucions_tecniques': '''- **Calendari online:** Cal.com, Calendly, Acuity Scheduling o self-hosted
- **Integració de disponibilitat:** API a Google Calendar, Outlook, Zoom
- **Notificacions automàtiques:** Email i SMS de confirmació + recordatori 24h
- **Pagament si aplica:** Stripe, PayPal integrat al calendari
- **Formulari pre-cita:** Preguntes personalitzades per tipus de servei
- **Sincronització:** N8N/Make per a actualitzar CRM o base de dades
- **Recordatoris:** SMS 24h + email 1h abans (opcional WhatsApp)''',
        'preguntes_clients': '''- ¿Tenim Google Calendar o Outlook per a sincronitzar?
- ¿Tipus de cita: duracio, buffer, horari de treball?
- ¿Cal cobrar per endavant (Stripe, PayPal)?
- ¿Formulari pre-cita: quins datos necessites?
- ¿Recordatoris: email, SMS, WhatsApp?
- ¿No-show rate actual i potencial retorn de recordatoris?''',
        'que_cercar': '''- Comparativa calendaris 2026 (Cal.com vs. Calendly vs. Acuity)
- Estimació de ROI de recordatoris automàtics (redució no-shows)
- Integració de pagament a calendaris (Stripe, PayPal)
- SMS vs. email vs. WhatsApp per a recordatoris (engagement rate)
- Casos d'ús per a clínica, restaurant, consultoria''',
        'criteris_validacio': '''- Calendari en viu i públic (link compartible)
- Reserva de prova: email de confirmació rebut
- Integració Google/Outlook: disponibilitat sincronitzada en temps real
- Recordatori 24h rebut per email o SMS
- No-show rate reducció >= 20%
- Test de pagament (si aplica): Stripe transaction completa
- Usuari no rep recordatoris duplicats o espaiat (validar logs)''',
        'fases': 'Fase 1: Elecció de plataforma i configuració bàsica (3-5 dies) → Fase 2: Integració Google/Outlook Calendar (3-5 dies) → Fase 3: Recordatoris automàtics setup (3-5 dies) → Fase 4: Testing amb usuaris reals (1 setmana) → Fase 5: Monitoring no-shows (semanal)'
    },
}


def generar_brief_implementacio(client_json, proposats_serveis, nom_client, data_auditoria):
    """Genera un document MD amb instruccions d'implementació per a Claude."""
    
    md = f'''# Brief d'Implementació Tècnica

**Client:** {nom_client}  
**Data de generació del brief:** {date.today().strftime("%d/%m/%Y")}  
**Font:** Auditoria Digital Global realitzada el {data_auditoria}  
**Document intern:** Instruccions per a Claude sobre quines solucions desenvolupar i verificar

---

## Resum Executiu de la Implementació

**Serveis tecnològics a desenvolupar:** {len(proposats_serveis)} (veure detall més avall)

**Pressupost total orientatiu:** {sum(est_cost_range(p[3]) for p in proposats_serveis if len(p) > 3)}€ (estimació preliminar)

**Dolors prioritaris a resoldre:**
'''
    
    # Afegir dolors prioritaris (P1, P2, P3)
    dolors_p1 = [d for d in client_json.get('dolors', []) if 'P1' in str(d)]
    for dolor in dolors_p1[:3]:
        md += f"- {escape(str(dolor))}\n"
    
    md += f'''
**Responsible:** Josep (planificació) + Claude (desenvolupament)

**Calendari estimat total:** 12-16 setmanes (Fase 1-5 sequencial o paral·lel depenent de recursos)

---

## Serveis a Desenvolupar (per ordre de prioritat)

'''
    
    for i, sid in enumerate(proposats_serveis, 1):
        spec = SPECS_SERVEI.get(sid, {
            'solucions_tecniques': '(A definir amb client)',
            'preguntes_clients': '(A definir amb client)',
            'que_cercar': '(A definir amb client)',
            'criteris_validacio': '(A definir amb client)',
            'fases': '(A definir amb client)'
        })
        
        # Buscar nom servei i altres dades de la BD (stub aquí)
        nom_servei = sid.replace('SVC-', 'Servei ').replace('-', ' ')
        titul_oferta = f"Servei tecnològic {sid}"
        caracteristiques = "(Veure document d'oferta global)"
        avantatges = "(Veure document d'oferta global)"
        benefici = "(Veure document d'oferta global)"
        cost = "1.000-5.000€"
        
        md += TEMPLATE_SERVEI.format(
            num=i,
            sid=sid,
            nom_servei=nom_servei,
            titul_oferta=titul_oferta,
            dolor_lligat="(Veure document d'oferta global)",
            caracteristiques=caracteristiques,
            avantatges=avantatges,
            benefici=benefici,
            cost="(Veure oferta)",
            solucions_tecniques=spec.get('solucions_tecniques', '(A definir)'),
            preguntes_clients=spec.get('preguntes_clients', '(A definir)'),
            que_cercar=spec.get('que_cercar', '(A definir)'),
            criteris_validacio=spec.get('criteris_validacio', '(A definir)'),
            dolor_ref="—",
            prioritat="P1/P2/P3 (veure matriu)",
            maduresa_rel="(Veure auditoria global)",
            dependencies="Veure secció de sequenciació",
            fases=spec.get('fases', '(A definir)')
        )
    
    md += '''

---

## Sequenciació de Projecte

### Calendari Estimat Total: 12-16 setmanes

**Fase 0 - Anàlisi i especificació (1-2 setmanes)**
- [ ] Definir detall de cada servei (scope, integrations)
- [ ] Recollir contingut del client (textos, imatges, logos)
- [ ] Validar pressupost definitiu amb client
- [ ] Acordar calendari i milestones

**Fase 1 - Presència Digital (setmana 1-6)**
- [ ] Web de landing (1-2 setmanes)
- [ ] Web de serveis (2-3 setmanes)
- [ ] Google Business + SEO local (1 setmana)

**Fase 2 - Automatització i Bots (setmana 5-12)**
- [ ] Bot WhatsApp (2-3 setmanes)
- [ ] Calendari de cites automàtic (1-2 setmanes)
- [ ] Automatitzacions N8N (1-2 setmanes)

**Fase 3 - CRM i SaaS (setmana 10-14)**
- [ ] Setup CRM lleuger (1 setmana)
- [ ] Integracions amb tools existents (1-2 setmanes)

**Fase 4 - RAG i IA Local (setmana 12-15)**
- [ ] Setup Ollama si cal (1 setmana)
- [ ] RAG sobre documentació (1-2 setmanes)

**Fase 5 - Testing i Lliurament (setmana 15-16)**
- [ ] QA complet de tots els sistemes (3-5 dies)
- [ ] Training del client (2-3 dies)
- [ ] Lliurament i handoff (2-3 dies)

---

## Criteris de Recepció i Validació

Cadascun dels lliurables s'ha d'acceptar seguint aquests estàndards:

### Lliurable 1: Presència Digital (Web)
**Entrega:** URL en producció
- [ ] Demo URL en viu (https)
- [ ] Totes les pàgines indexades a Google Search Console (0 errors)
- [ ] Audit SEO local completat (schema markup, meta tags)
- [ ] Lighthouse score >= 85 (performance, accessibility, SEO, best practices)
- [ ] Test de velocitat: First Contentful Paint < 1.5s
- [ ] Responsive test: funciona correctament a telèfon (manull)
- [ ] Formulari de contacte enviant emails correctament
- [ ] Feedback client aprovat

### Lliurable 2: Bot WhatsApp
**Entrega:** Bot en viu + documentació
- [ ] Bot responen a preguntes de test (casos predefinits)
- [ ] Latència < 3s per resposta
- [ ] Integració CRM: leads capturats correctament
- [ ] Human handoff funciona si el bot no entén
- [ ] Test de conversa real amb usuaris (3+ usuaris de test)
- [ ] Logs de conversació disponibles per auditoria
- [ ] Documentació: com modificar respostes, preguntes freqüents

### Lliurable 3: Calendari Automàtic
**Entrega:** Calendari compartible + integracions
- [ ] Calendari en viu i públic (link compartible)
- [ ] Reserva de prova completa: email de confirmació rebut
- [ ] Disponibilitat sincronitzada en temps real (Google/Outlook)
- [ ] Recordatori 24h i 1h abans funciona correctament
- [ ] No-show rate reduït (comparar "abans" vs. "després")
- [ ] Feedback client aprovat

### Lliurable 4: CRM
**Entrega:** CRM configurat + onboarding
- [ ] Dashboard del CRM accessible al client
- [ ] Totes les integracions funcionant (botons web, formularis, API)
- [ ] Dades del client migrades (si aplicable)
- [ ] Training del client completat (1-2 sessions, enregistrat)
- [ ] Documentació: com usar, com personalitzar camps

---

## Riscos i Mitigacions

| Risc | Probabilitat | Impacte | Mitigació |
|------|--------------|---------|-----------|
| Client no proporciona contingut a temps | Alta | Alt | Template de continguts pre-fet; draft placeholder |
| Integració amb sistema existent fallida | Mig | Alt | Test d'integració early; API docs del client |
| Cambis de scope durant desenvolupament | Alta | Mig | Brief signat al inicio; changes = scope change |
| Performance web insuficient (Lighthouse < 85) | Mig | Mig | Optimització desde el principi (no al final) |
| Bot entén incorrectament | Mig | Mig | Testing amb usuaris reals; human handoff sempre |
| Pressupost insuficient | Mig | Alt | Revisió setmanal de hores; comunicació proactiva |

---

## Preguntes Clau que Claude ha de fer per a cada Servei

### Abans de desenvolupar cada solució:

1. **Scope clament:** ¿Quines funcionalitats ESPECÍFIQUES necessites? ¿Quines NO?
2. **Integrations:** ¿Quines eines existents s'han de connectar?
3. **Données:** ¿Tenim contingut escrit o dades per importar?
4. **Budget:** ¿El pressupost orientatiu és realista? ¿Cal ajustar-lo?
5. **Timeline:** ¿Quina és la prioritat real? ¿Hi ha deadline?
6. **Usuaris:** ¿Quants usuaris? ¿Qui és l'admin?
7. **Support:** ¿Qui manté/suporta el sistema después del lliurament?

---

## Recursos i Documentació

**Del client:**
- Auditoria digital global (JSON): `/opt/data/.claude/audit-system/templates/[client].json`
- Documento d'oferta (PDF): `oferta_global_[client].pdf`
- Acceso a sistemes actuals (CRM, calendari, email)

**Externes:**
- [Next.js Docs](https://nextjs.org/docs)
- [N8N Docs](https://docs.n8n.io/)
- [Twilio WhatsApp API](https://www.twilio.com/docs/whatsapp)
- [Google Business Profile API](https://developers.google.com/my-business)
- [Cal.com Docs](https://cal.com/docs)

---

## Procés de Desenvolupament

### Per a cada servei:

1. **Josep:** Revisa aquest brief, afegeix detalls específics del client
2. **Claude:** Llegeix el brief, fa preguntes si cal (via aquest doc o chat)
3. **Investigació:** Claude cerca documentació, comparativa de tecnologies, casos d'ús
4. **Proposta:** Claude proposa arquitectura específica, tecnologies, timeline
5. **Aprovació:** Josep valida la proposta, fa feedback
6. **Desarrollo:** Claude implementa, test continuous, validates vs. criteris
7. **QA:** Test final, client feedback, deployement
8. **Handoff:** Documentació, training, suport

---

## Contacto i Escalacions

- **Josep Manel Saperas** (planificació, client relations, decisions): [info de contacte]
- **Claude** (desenvolvimento, implementació, QA)
- **Client:** [nom i contacte]

---

**Generat automàticament des de l'auditoria global del client. Actualitza regularment conforme avança el projecte.**
'''
    
    return md


def est_cost_range(cost_str):
    """Estima el cost en €, retorna la mitjana de l'interval."""
    import re
    nums = re.findall(r'\d+[\.]?\d*', str(cost_str))
    if nums:
        vals = [int(float(n)) for n in nums]
        return sum(vals) / len(vals) if vals else 0
    return 1500  # Default si no hi ha info


if __name__ == '__main__':
    # Test: generador stub
    print("✓ Mòdul genera_brief_implementacio carregat correctament")
